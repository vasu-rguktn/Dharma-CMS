import type { Timestamp } from 'firebase/firestore';

export enum CaseStatus {
  New = "New",
  UnderInvestigation = "Under Investigation",
  PendingTrial = "Pending Trial",
  Resolved = "Resolved",
  Closed = "Closed",
}

// Message structure for transcripts, consistent with save-complaint-flow.ts
export interface TranscriptMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: any; // Firestore Timestamp on fetch, converted to Date/string for display
  attachmentName?: string;
  attachmentType?: string;
}

// Structure for complaints fetched from Firestore
export interface SavedComplaint {
  id: string; // Firestore document ID
  createdAt: any; // Firestore Timestamp on fetch, converted to Date for display
  updatedAt: any; // Firestore Timestamp on fetch
  transcript?: TranscriptMessage[];
  englishSummary?: string;
  audioDownloadUrl?: string;
  videoDownloadUrl?: string;
  userId?: string;
  officerStationName?: string;
  officerDistrict?: string;
}

// --- User Profile Schema ---
export interface UserProfileAddress {
  street?: string | null;
  city?: string | null;
  state?: string | null;
  postalCode?: string | null;
  country?: string | null;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string | null;
  phoneNumber?: string | null;
  profilePhotoUrl?: string | null;

  stationName?: string | null;
  district?: string | null;
  rank?: string | null;
  badgeNumber?: string | null;
  employeeId?: string | null;
  role: 'officer' | 'supervisor' | 'admin';

  address?: UserProfileAddress | null;

  createdAt: Timestamp;
  updatedAt: Timestamp;
}


// --- FIR Schema (CaseDoc) ---

interface Address {
  houseNo?: string;
  streetVillage?: string;
  areaMandal?: string;
  cityDistrict?: string;
  state?: string;
  pin?: string;
}

interface PlaceOfOccurrence {
  streetVillage?: string;
  areaMandal?: string;
  cityDistrict?: string;
  state?: string;
  pin?: string;
  latitude?: number | null;
  longitude?: number | null;
}

interface DistanceDirectionFromPS {
  distance?: string;
  direction?: string;
}

interface OutsideJurisdiction {
  isOutside?: boolean;
  policeStationName?: string;
}

interface PhysicalFeatures {
  build?: string;
  heightCms?: string;
  complexion?: string;
  deformitiesPeculiarities?: string;
  teeth?: string;
  hair?: string;
  eyes?: string;
  habits?: string;
  dressHabits?: string;
  languagesDialect?: string;
}

interface IdentificationMarks {
  mole?: boolean;
  scar?: boolean;
  tattoo?: boolean;
  leucoderma?: boolean;
  burnMark?: boolean;
}

export interface AccusedDetail {
  serialNo?: string;
  name?: string;
  fatherHusbandName?: string;
  caste?: string;
  nationality?: string;
  occupation?: string;
  age?: string;
  gender?: string;
  address?: Address;
  phoneOffice?: string;
  phoneResidence?: string;
  cellNo?: string;
  email?: string;
  physicalFeatures?: PhysicalFeatures;
  identificationMarks?: IdentificationMarks;
}

export interface CaseDoc {
  id?: string;
  originalComplaintId?: string;
  status: CaseStatus;
  dateFiled: Timestamp;
  lastUpdated: Timestamp;
  title: string;
  userId?: string;

  // 1. District Details
  district?: string;
  policeStation?: string;
  year?: string;
  firNumber: string;
  date?: string; // YYYY-MM-DD format

  // 2. Occurrence of Offence
  occurrenceDay?: string;
  occurrenceDateTimeFrom?: string;
  occurrenceDateTimeTo?: string;
  occurrencePriorToDateTime?: string;
  occurrenceTimePeriod?: string;
  occurrenceBeatNumber?: string;
  occurrencePlace?: PlaceOfOccurrence;
  occurrenceDistanceDirectionFromPS?: DistanceDirectionFromPS;
  occurrenceOutsideJurisdiction?: OutsideJurisdiction;

  // 3. Information Received
  infoReceivedDateTime?: string;
  infoReceivedEntryNumber?: string;

  // 4. Type of Information
  typeOfInformation?: "Written" | "Oral" | "";

  // 5. Complainant/Informant
  complainantName?: string;
  complainantFatherHusbandName?: string;
  complainantGender?: string;
  complainantNationality?: string;
  complainantCaste?: string;
  complainantOccupation?: string;
  complainantDateOfBirth?: string;
  complainantAge?: string;
  complainantAddress?: Address;
  complainantMobileNumber?: string;
  complainantPassportNumber?: string;
  complainantPassportPlaceOfIssue?: string;
  complainantPassportDateOfIssue?: string;

  // 6. Accused Details (Array of Objects)
  accusedDetails?: AccusedDetail[];

  // 7. Properties Involved
  propertiesInvolvedDetails?: string;
  propertiesTotalValueStolen?: string;

  // 8. Delay in Reporting
  delayInReportingIsDelayed?: boolean;
  delayInReportingReason?: string;

  // 9. Inquest Report/UD Case Number
  inquestReportUDCaseNumber?: string;

  // 10. Complaint Statement
  complaintStatement?: string;

  // 11. Action Taken
  actionTakenType?: string;
  actionTakenOfficerName?: string;
  actionTakenOfficerRank?: string;
  actionTakenDistrict?: string;

  // 12. Dispatch To Court
  dispatchToCourtDateTime?: string;
  dispatchToCourtOfficerName?: string;
  dispatchToCourtOfficerRank?: string;

  // 13. Confirmation
  confirmationFirReadOverAndAdmitted?: boolean;
  confirmationCopyGivenToComplainant?: boolean;
  confirmationSignatureOfComplainant?: string;
  confirmationRoac?: boolean;

  victimName?: string;
  victimDob?: string;
  victimAge?: string;
  victimGender?: string;
  victimFatherHusbandName?: string;
  victimAddress?: Address;
  victimNationality?: string;
  victimReligion?: string;
  victimCaste?: string;
  victimOccupation?: string;

  actsAndSectionsInvolved?: string;
  incidentDetails?: string;
}

// --- Crime Details Schema ---
export interface Witness {
  id?: string;
  name?: string;
  address?: string;
  contactNumber?: string;
}

export interface CrimeDetails {
  id?: string;
  firNumber: string;
  crimeType?: string;
  majorHead?: string;
  minorHead?: string;
  languageDialectUsed?: string;
  specialFeatures?: string;
  conveyanceUsed?: string;
  characterAssumedByOffender?: string;
  methodUsed?: string;
  placeOfOccurrenceDescription?: string;
  dateTimeOfSceneVisit?: string;
  physicalEvidenceDescription?: string;
  witnesses?: Witness[];
  motiveOfCrime?: string;
  sketchOrMapUrl?: string;
  userId: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

// --- Case Journal Entry Schema ---
export interface CaseJournalEntry {
  id?: string;
  caseId: string;
  officerUid: string;
  officerName: string;
  officerRank: string;
  dateTime: Timestamp;
  entryText: string;
  activityType: string;
  relatedDocumentId?: string;
}

// --- Media Analysis Schema ---
export interface IdentifiedElement {
  name: string;
  category: string; // E.g., weapon, vehicle, person, document
  description: string;
  count?: number;
}

export interface MediaAnalysisOutput {
  identifiedElements: IdentifiedElement[];
  sceneNarrative: string; // Detailed description, incorporating overview and key observations
  caseFileSummary: string; // Inferences, points for further investigation, key takeaways
}

export interface MediaAnalysisRecord extends MediaAnalysisOutput {
  id?: string; // Firestore document ID
  userId: string; // UID of the user who uploaded/analyzed
  originalFileName: string;
  originalFileContentType?: string; // To store the MIME type of the original file
  storagePath?: string; // Path in Firebase Storage if uploaded
  imageDataUri: string; // Store the image as a base64 Data URI
  userContext?: string; // User-provided context for the analysis
  createdAt: Timestamp;
  updatedAt: Timestamp; // If edits are allowed and saved
  caseId?: string; // Optional: link to a specific case
}

// --- Legal Queries Chat Schema ---
export interface LegalQueryChat {
  id: string;
  userId: string;
  createdAt: Date;
  lastMessageAt: Date;
  title?: string;
  messageCount: number;
}

export interface LegalQueryMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: any;
  userId: string;
  sessionId: string;
  language?: string;
  fileUrl?: string;
  fileType?: string;
}
