"use client";

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { db } from '@/lib/firebase';
import {
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  serverTimestamp,
  Timestamp,
  getDoc,
  getDocs,
  writeBatch,
  limit
} from 'firebase/firestore';
import type { LegalQueryChat, LegalQueryMessage } from '@/types';
import SessionList from '@/components/legal-queries/SessionList';
import LegalQueriesChat from '@/components/legal-queries/LegalQueriesChat';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'; // Added Alert import

export default function LegalQueriesPage() {
  const { user, loading: authLoading, idToken } = useAuth();
  const { toast } = useToast();

  const [sessions, setSessions] = useState<LegalQueryChat[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<LegalQueryMessage[]>([]);
  const [isLoadingSessions, setIsLoadingSessions] = useState(true);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch user's chat sessions
  useEffect(() => {
    if (!user) {
      setIsLoadingSessions(false);
      setSessions([]);
      return;
    }
    setIsLoadingSessions(true);
    const q = query(
      collection(db, 'legal_queries_chats'),
      where('userId', '==', user.uid),
      orderBy('lastMessageAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const fetchedSessions: LegalQueryChat[] = [];
      querySnapshot.forEach((doc) => {
        fetchedSessions.push({ id: doc.id, ...doc.data() } as LegalQueryChat);
      });
      setSessions(fetchedSessions);
      if (!currentSessionId && fetchedSessions.length > 0) {
        // setCurrentSessionId(fetchedSessions[0].id); // Auto-select first session
      }
      setIsLoadingSessions(false);
    }, (err) => {
      console.error("Error fetching sessions:", err);
      setError("Failed to load chat sessions. " + err.message);
      setIsLoadingSessions(false);
      toast({ variant: "destructive", title: "Error", description: "Could not load chat sessions." });
    });

    return () => unsubscribe();
  }, [user, currentSessionId, toast]);

  // Fetch messages for the current session
  useEffect(() => {
    if (!currentSessionId || !user) {
      setMessages([]);
      return;
    }
    setIsLoadingMessages(true);
    const messagesQuery = query(
      collection(db, 'legal_queries_chats', currentSessionId, 'messages'),
      orderBy('timestamp', 'asc')
    );

    const unsubscribeMessages = onSnapshot(messagesQuery, (querySnapshot) => {
      const fetchedMessages: LegalQueryMessage[] = [];
      querySnapshot.forEach((doc) => {
        fetchedMessages.push({ id: doc.id, ...doc.data() } as LegalQueryMessage);
      });
      setMessages(fetchedMessages);
      setIsLoadingMessages(false);
    }, (err) => {
      console.error(`Error fetching messages for session ${currentSessionId}:`, err);
      setError(`Failed to load messages. ${err.message}`);
      setIsLoadingMessages(false);
      toast({ variant: "destructive", title: "Error", description: "Could not load messages for this chat." });
    });

    return () => unsubscribeMessages();
  }, [currentSessionId, user, toast]);

  const handleNewSession = async () => {
    if (!user) return;
    setIsLoadingSessions(true); // Indicate loading for new session creation
    try {
      const newSessionRef = await addDoc(collection(db, 'legal_queries_chats'), {
        userId: user.uid,
        title: 'New Legal Query',
        createdAt: serverTimestamp(),
        lastMessageAt: serverTimestamp(),
        messageCount: 0,
        openaiThreadId: null,
      });
      setCurrentSessionId(newSessionRef.id);
      setMessages([]); // Clear messages for new session
      toast({ title: "New Chat Started", description: "Ask your legal question." });
    } catch (err: any) {
      console.error("Error creating new session:", err);
      setError("Failed to start new chat. " + err.message);
      toast({ variant: "destructive", title: "Error", description: "Could not start a new chat session." });
    } finally {
      setIsLoadingSessions(false);
    }
  };

  const handleSelectSession = (sessionId: string) => {
    if (currentSessionId !== sessionId) {
      setCurrentSessionId(sessionId);
      setMessages([]); // Clear old messages before loading new ones
    }
  };

  const handleSendMessage = async (messageText: string) => {
    if (!currentSessionId || !user) {
      toast({ variant: "destructive", title: "Error", description: "No active session or user not logged in." });
      return;
    }
    setIsSendingMessage(true);

    const tempUserMessageId = Date.now().toString();
    const userMessageForUI: LegalQueryMessage = {
      id: tempUserMessageId,
      sessionId: currentSessionId,
      userId: user.uid,
      text: messageText,
      sender: 'user',
      timestamp: Timestamp.now(), // Client-side timestamp for immediate display
    };
    setMessages(prev => [...prev, userMessageForUI]);

    try {
      const currentSession = sessions.find(s => s.id === currentSessionId);
      const response = await fetch('/api/legal-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: currentSessionId,
          userId: user.uid,
          messageText,
          openaiThreadId: currentSession?.openaiThreadId // Pass current thread ID
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `API request failed with status ${response.status}`);
      }

      const data = await response.json();
      
      // The API route now saves both user and AI messages, and updates session.
      // So, we just need to make sure UI reflects what's in Firestore,
      // or trust the onSnapshot listener to update.
      // For faster UI, we could optimistically add AI message if API returns it.
      if (data.newMessage) {
        // If API returns the saved AI message, we can update UI (though snapshot should catch it)
        // setMessages(prev => prev.map(m => m.id === tempUserMessageId ? {...m, id: "confirmed_user_msg_id_if_needed"} : m)); // Update user msg ID if backend confirms
        // setMessages(prev => [...prev, data.newMessage]); // Add AI message
      }
      // Session title might be updated by the API if it was the first message
      const sessionDoc = await getDoc(doc(db, 'legal_queries_chats', currentSessionId));
      if (sessionDoc.exists()) {
        const updatedSession = { id: sessionDoc.id, ...sessionDoc.data() } as LegalQueryChat;
        setSessions(prevSessions => prevSessions.map(s => s.id === updatedSession.id ? updatedSession : s)
                                               .sort((a, b) => b.lastMessageAt.toMillis() - a.lastMessageAt.toMillis()));
      }


    } catch (err: any) {
      console.error("Error sending message:", err);
      toast({ variant: "destructive", title: "Message Failed", description: err.message || "Could not send message or get reply." });
      // Remove optimistic user message if send failed badly
      setMessages(prev => prev.filter(m => m.id !== tempUserMessageId));
      const errorAiMessage: LegalQueryMessage = {
        id: Date.now().toString(),
        sessionId: currentSessionId,
        userId: 'ai_assistant',
        text: "Unable to fetch reply. Please try again.",
        sender: 'ai',
        timestamp: Timestamp.now(),
      };
      setMessages(prev => [...prev, errorAiMessage]);
    } finally {
      setIsSendingMessage(false);
    }
  };
  
  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2">Loading user data...</p>
      </div>
    );
  }

  if (!user && !authLoading) {
    return (
      <Card className="m-auto mt-10 max-w-md">
        <CardHeader>
          <CardTitle>Access Denied</CardTitle>
          <CardDescription>Please log in to use the Legal Queries chat feature.</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <div className="flex h-[calc(100vh-var(--header-height)-2rem)] border rounded-lg shadow-sm bg-card">
      <SessionList
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewSession={handleNewSession}
        isLoadingSessions={isLoadingSessions}
      />
      <LegalQueriesChat
        messages={messages}
        onSendMessage={handleSendMessage}
        isLoadingReply={isSendingMessage || (isLoadingMessages && messages.length === 0)}
        currentSessionId={currentSessionId}
        idToken={idToken}
      />
      {error && (
        <div className="absolute bottom-4 right-4">
            <Alert variant="destructive" className="max-w-sm">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
            </Alert>
        </div>
      )}
    </div>
  );
}

