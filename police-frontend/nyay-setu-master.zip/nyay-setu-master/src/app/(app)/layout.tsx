
import type { ReactNode } from 'react';
import AuthGuard from '@/components/AuthGuard';
import Header from '@/components/layout/Header';
import SidebarNav from '@/components/layout/SidebarNav';
import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarInset,
  SidebarHeader,
  SidebarFooter,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import Logo from '@/components/Logo';

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <AuthGuard>
      <SidebarProvider defaultOpen={false}> {/* Sidebar starts collapsed */}
        <Sidebar variant="sidebar" collapsible="icon" className="border-r">
          <SidebarHeader className="p-4">
            {/* Content for expanded state: Logo on left, Trigger on right */}
            <div className="group-data-[state=expanded]:flex group-data-[state=expanded]:items-center group-data-[state=expanded]:justify-between hidden w-full">
              <Logo />
              <SidebarTrigger className="text-sidebar-foreground hover:text-sidebar-accent-foreground" />
            </div>

            {/* Content for collapsed state: Centered Trigger Icon */}
            <div className="group-data-[state=collapsed]:flex group-data-[state=collapsed]:justify-center hidden w-full">
              <SidebarTrigger className="text-sidebar-foreground hover:text-sidebar-accent-foreground" />
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarNav />
          </SidebarContent>
          <SidebarFooter>
            {/* Footer content if any */}
          </SidebarFooter>
        </Sidebar>
        <SidebarInset>
          <Header />
          <main className="flex-1 p-4 sm:p-6 overflow-auto">
            {children}
          </main>
        </SidebarInset>
      </SidebarProvider>
    </AuthGuard>
  );
}
