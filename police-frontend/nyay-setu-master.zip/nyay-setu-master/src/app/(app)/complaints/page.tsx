"use client";

import { useEffect, useState } from 'react';
import { collection, getDocs, orderBy, query, Timestamp }
from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { SavedComplaint } from '@/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Archive, FileSearch, AlertTriangle, FilePlus } from 'lucide-react';
import ComplaintDetailDialog from '@/components/complaints/ComplaintDetailDialog';
import { format } from 'date-fns';
import Link from 'next/link'; // Import Link
import { useAuth } from '@/hooks/useAuth';

export default function MyComplaintsPage() {
  const { user, profileLoading } = useAuth();
  const [complaints, setComplaints] = useState<SavedComplaint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedComplaint, setSelectedComplaint] = useState<SavedComplaint | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);

  useEffect(() => {
    if (profileLoading) return;
    if (!user) {
      setIsLoading(false);
      setError('User not authenticated. Please log in.');
      return;
    }
    const fetchComplaints = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const complaintsRef = collection(db, 'complaints');
        const q = query(complaintsRef, orderBy('createdAt', 'desc'));
        const querySnapshot = await getDocs(q);
        const fetchedComplaints: SavedComplaint[] = [];
        querySnapshot.forEach((doc) => {
          const data = doc.data();
          fetchedComplaints.push({
            id: doc.id,
            ...data,
            createdAt: data.createdAt,
            updatedAt: data.updatedAt,
            transcript: data.transcript?.map((msg: any) => ({
                ...msg,
                timestamp: msg.timestamp instanceof Timestamp ? msg.timestamp.toDate() : new Date(msg.timestamp)
            })) || [],
            audioDownloadUrl: data.audioDownloadUrl,
          });
        });
        // Restrict access: show all if admin, else only user's own
        if (user.profile?.role === 'admin') {
          setComplaints(fetchedComplaints);
        } else {
          setComplaints(fetchedComplaints.filter(c => c.userId === user.uid));
        }
      } catch (err: any) {
        console.error("Error fetching complaints from Firestore:", err); 
        setError(`Failed to fetch complaints. Firestore error: ${err.message || 'Unknown error'}. Code: ${err.code || 'N/A'}`);
      } finally {
        setIsLoading(false);
      }
    };
    fetchComplaints();
  }, [user, profileLoading]);

  const handleViewDetails = (complaint: SavedComplaint) => {
    setSelectedComplaint(complaint);
    setIsDetailDialogOpen(true);
  };
  
  const formatFirestoreTimestamp = (timestamp: any): string => {
    if (timestamp && typeof timestamp.toDate === 'function') {
      return format(timestamp.toDate(), 'PP p');
    }
    // Handle cases where timestamp might be an object with _seconds and _nanoseconds (e.g., from JSON stringify/parse)
    if (timestamp && typeof timestamp._seconds === 'number' && typeof timestamp._nanoseconds === 'number') { 
        try {
            return format(new Timestamp(timestamp._seconds, timestamp._nanoseconds).toDate(), 'PP p');
        } catch (e) {
            console.warn("Failed to format timestamp from _seconds/_nanoseconds:", timestamp, e);
            return 'Invalid Date';
        }
    }
    if (timestamp) { // Attempt to parse if it's a string or number
        try {
            const date = new Date(timestamp);
            if (!isNaN(date.getTime())) {
                return format(date, 'PP p');
            }
        } catch (e) {
            console.warn("Failed to format timestamp directly:", timestamp, e);
        }
    }
    return 'N/A';
  };


  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="mt-4 text-muted-foreground">Loading complaints...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] text-center">
        <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
        <h2 className="text-xl font-semibold text-destructive">Error Fetching Complaints</h2>
        <p className="text-muted-foreground">{error}</p>
        <Button onClick={() => window.location.reload()} className="mt-4">Try Again</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Archive className="mr-3 h-8 w-8 text-primary" />
        <h1 className="text-3xl font-bold tracking-tight font-headline">My Saved Complaints</h1>
      </div>
      <p className="text-muted-foreground">
        Browse, review, and convert your recorded complaints into FIRs.
      </p>

      {complaints.length === 0 ? (
        <div className="text-center py-10 border-2 border-dashed rounded-lg">
          <FileSearch size={48} className="mx-auto mb-4 text-muted-foreground" />
          <p className="text-xl font-semibold text-muted-foreground">No complaints found.</p>
          <p className="text-sm text-muted-foreground">Start by recording a new complaint using the AI Chat feature.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {complaints.map((complaint) => (
            <Card key={complaint.id} className="shadow-lg flex flex-col">
              <CardHeader>
                <CardTitle className="font-headline text-xl truncate" title={complaint.id}>
                  ID: {complaint.id}
                </CardTitle>
                <CardDescription>
                  Recorded: {formatFirestoreTimestamp(complaint.createdAt)}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-sm text-muted-foreground">
                  {complaint.transcript && complaint.transcript.length > 0 
                    ? `${complaint.transcript.length} message(s) in transcript.` 
                    : 'No text transcript.'}
                  {complaint.audioDownloadUrl && ' Audio available.'}
                </p>
              </CardContent>
              <CardFooter className="flex-col sm:flex-row justify-between items-stretch sm:items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => handleViewDetails(complaint)} className="w-full sm:w-auto">
                  <FileSearch className="mr-2 h-4 w-4" /> View Details
                </Button>
                <Button variant="default" size="sm" asChild className="w-full sm:w-auto">
                  <Link href={`/cases/new?complaintId=${complaint.id}`}>
                    <FilePlus className="mr-2 h-4 w-4" /> Convert to FIR
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
      {selectedComplaint && (
        <ComplaintDetailDialog
          isOpen={isDetailDialogOpen}
          onClose={() => setIsDetailDialogOpen(false)}
          complaint={selectedComplaint}
        />
      )}
    </div>
  );
}
