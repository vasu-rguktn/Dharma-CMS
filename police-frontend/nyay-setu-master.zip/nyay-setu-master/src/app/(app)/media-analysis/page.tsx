
"use client";

import { useState, useRef, type ChangeEvent, type FormEvent, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Loader2, AlertTriangle, UploadCloud, ImageIcon, Search, FileText, ListChecks, Lightbulb, Save, Download, LanguagesIcon, FolderOpen } from 'lucide-react';
import { analyzeMedia, type MediaAnalysisInput, type MediaAnalysisOutput } from '@/ai/flows/media-analysis-flow';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { getFirestore, doc, collection, addDoc, getDocs, query, orderBy, serverTimestamp, Timestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from '@/hooks/useAuth';
import type { CaseDoc, MediaAnalysisRecord } from '@/types';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { addCaseJournalEntry } from '@/lib/journal';

export default function MediaAnalysisPage() {
  const { user } = useAuth(); 
  const { toast } = useToast();

  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [userContext, setUserContext] = useState('');
  
  const [analysisResult, setAnalysisResult] = useState<MediaAnalysisOutput | null>(null);
  const [editableSceneNarrative, setEditableSceneNarrative] = useState('');
  const [editableCaseFileSummary, setEditableCaseFileSummary] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [allCases, setAllCases] = useState<CaseDoc[]>([]);
  const [selectedCaseIdForSave, setSelectedCaseIdForSave] = useState<string | null>(null);
  const [isLoadingCases, setIsLoadingCases] = useState(false);
  const [casesError, setCasesError] = useState<string | null>(null);
  const [showSaveDialog, setShowSaveDialog] = useState(false);


  useEffect(() => {
    if (analysisResult) {
      setEditableSceneNarrative(analysisResult.sceneNarrative);
      setEditableCaseFileSummary(analysisResult.caseFileSummary);
    } else {
      setEditableSceneNarrative('');
      setEditableCaseFileSummary('');
    }
  }, [analysisResult]);
  
  useEffect(() => {
    const fetchCases = async () => {
      if (!user) return;
      setIsLoadingCases(true);
      setCasesError(null);
      try {
        const casesRef = collection(db, 'cases');
        const q = query(casesRef, orderBy('dateFiled', 'desc'));
        const querySnapshot = await getDocs(q);
        const fetchedCases: CaseDoc[] = [];
        querySnapshot.forEach((doc) => {
          fetchedCases.push({ id: doc.id, ...doc.data() } as CaseDoc);
        });
        setAllCases(fetchedCases);
      } catch (err: any) {
        console.error("Error fetching cases:", err);
        setCasesError(`Failed to load cases. ${err.message}`);
      } finally {
        setIsLoadingCases(false);
      }
    };
    fetchCases();
  }, [user]);


  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.size > 10 * 1024 * 1024) { 
        toast({ variant: "destructive", title: "File Too Large", description: "Please select an image smaller than 10MB." });
        return;
      }
      if (!selectedFile.type.startsWith('image/')) {
        toast({ variant: "destructive", title: "Invalid File Type", description: "Please select an image file (PNG, JPG, WEBP, etc.). Video not yet supported." });
        return;
      }
      setFile(selectedFile);
      setAnalysisResult(null); 
      setEditableSceneNarrative('');
      setEditableCaseFileSummary('');
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleSubmitAnalysis = async (event: FormEvent) => {
    event.preventDefault();
    if (!file) {
      toast({ variant: "destructive", title: "No File Selected", description: "Please select an image to analyze." });
      return;
    }
    if (!previewUrl) {
      toast({ variant: "destructive", title: "File Error", description: "Could not read the selected file." });
      return;
    }

    setIsLoading(true);
    setAnalysisResult(null);

    try {
      const input: MediaAnalysisInput = {
        imageDataUri: previewUrl,
        userContext: userContext.trim() ? userContext : undefined,
      };
      const output = await analyzeMedia(input);
      setAnalysisResult(output);
      toast({ title: "Analysis Complete", description: "Review the AI-generated findings below. You can edit the narrative and summary." });

    } catch (error: any) {
      console.error("Media Analysis Error:", error);
      toast({ variant: "destructive", title: "Analysis Failed", description: error.message || "Could not analyze the media." });
      setAnalysisResult({
        identifiedElements: [{ name: "Error", category: "System", description: `Analysis failed: ${error.message}` }],
        sceneNarrative: "Could not generate scene narrative due to an error.",
        caseFileSummary: "Could not generate case file summary due to an error.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadText = () => {
    if (!analysisResult) return;
    const reportDate = new Date().toLocaleDateString();
    const content = `
Crime Scene Analysis Report
Date: ${reportDate}
Original File: ${file?.name || 'N/A'}
User Context: ${userContext || "None"}
---
IDENTIFIED ELEMENTS:
${analysisResult.identifiedElements.map(el => `  - Name: ${el.name}\n    Category: ${el.category}\n    Description: ${el.description}${el.count ? `\n    Count: ${el.count}` : ''}`).join('\n\n')}
---
SCENE NARRATIVE (User Edited):
${editableSceneNarrative}
---
CASE FILE SUMMARY & HYPOTHESES (User Edited):
${editableCaseFileSummary}
    `;
    const blob = new Blob([content.trim()], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `CrimeSceneAnalysis_${file?.name.split('.')[0] || 'report'}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast({title: "Report Downloaded", description: "Text file saved."});
  };
  
  const handleOpenSaveDialog = () => {
    if (!analysisResult || !user) {
        toast({ variant: "destructive", title: "Cannot Save", description: "No analysis result or user not logged in."});
        return;
    }
    setShowSaveDialog(true);
  };

  const confirmSaveReport = async () => {
    if (!selectedCaseIdForSave || !user || !analysisResult || !file || !previewUrl) {
        toast({ variant: "destructive", title: "Save Error", description: "Missing case selection, user info, analysis data, original file, or image preview."});
        return;
    }
    setIsSaving(true);
    const pathForLog = `cases/${selectedCaseIdForSave}/mediaAnalyses`;
    try {
        const reportDataPayload: Omit<MediaAnalysisRecord, 'id' | 'createdAt' | 'updatedAt' | 'userContext'> & { userContext?: string; createdAt: any, updatedAt: any } = {
            userId: user.uid, // Ensure userId is the authenticated user's UID
            originalFileName: file.name,
            originalFileContentType: file.type,
            imageDataUri: previewUrl, 
            identifiedElements: analysisResult.identifiedElements,
            sceneNarrative: editableSceneNarrative,
            caseFileSummary: editableCaseFileSummary,
            caseId: selectedCaseIdForSave,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
        };

        const trimmedUserContext = userContext.trim();
        if (trimmedUserContext) {
            reportDataPayload.userContext = trimmedUserContext;
        }
        
        console.log(`Attempting to add document to Firestore path: ${pathForLog} with payload:`, reportDataPayload);
        const caseAnalysesRef = collection(db, 'cases', selectedCaseIdForSave, 'mediaAnalyses');
        const docRef = await addDoc(caseAnalysesRef, reportDataPayload);

        toast({ title: "Report Saved", description: `Crime scene analysis report saved with ID: ${docRef.id} to Case ID: ${selectedCaseIdForSave}` });
        
        try {
            await addCaseJournalEntry(
                selectedCaseIdForSave,
                user.uid,
                "Crime Scene Analysis Saved",
                `New crime scene analysis report (ID: ${docRef.id}) for original file "${file.name}" was saved.`,
                docRef.id 
            );
        } catch (journalError) {
            console.error("Failed to add journal entry for media analysis save:", journalError);
            toast({variant: "warning", title: "Journal Entry Failed", description: "Report saved, but journal entry failed."});
        }

        setShowSaveDialog(false);
        setSelectedCaseIdForSave(null); 

    } catch (error: any) {
        console.error(`Error saving media analysis report to ${pathForLog}:`, error);
        toast({ variant: "destructive", title: "Save Failed", description: `${error.message || "Could not save the report."} Check Firestore rules for path: ${pathForLog}`});
    } finally {
        setIsSaving(false);
    }
  };


  return (
    <div className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center">
            <Search className="mr-2 h-6 w-6 text-primary" /> AI Crime Scene Investigator
          </CardTitle>
          <CardDescription>
            Upload an image (max 10MB) for crime scene analysis. The AI will identify elements, describe the scene, and provide a summary.
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmitAnalysis}>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="mediaFile" className="text-lg">Upload Image</Label>
              <div className="mt-1 flex flex-col sm:flex-row items-center gap-3">
                <Input
                  id="mediaFile"
                  type="file"
                  accept="image/*"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                />
                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} className="w-full sm:w-auto">
                  <UploadCloud className="mr-2 h-4 w-4" /> Choose Image
                </Button>
                {file && <span className="text-sm text-muted-foreground truncate" title={file.name}>{file.name}</span>}
              </div>
              {previewUrl && (
                <div className="mt-4 border rounded-md p-2 flex justify-center bg-muted/30 max-h-96 overflow-hidden">
                  <Image src={previewUrl} alt="Preview" width={400} height={300} style={{ objectFit: 'contain', maxHeight: '360px', width: 'auto' }} />
                </div>
              )}
            </div>
            <div>
              <Label htmlFor="userContext" className="text-lg">Context / Specific Instructions (Optional)</Label>
              <Textarea
                id="userContext"
                value={userContext}
                onChange={(e) => setUserContext(e.target.value)}
                placeholder="E.g., 'Focus on potential weapons.', 'Is there any sign of forced entry?', 'What is written on the note on the table?'"
                rows={3}
                className="mt-1"
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button type="submit" disabled={isLoading || !file} className="min-w-[150px]">
              {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Search className="mr-2 h-4 w-4" />
              )}
              Analyze Image
            </Button>
          </CardFooter>
        </form>
      </Card>

      {isLoading && !analysisResult && (
        <div className="flex flex-col items-center justify-center p-10 rounded-md border bg-card shadow-lg">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 mt-4 text-muted-foreground">AI is analyzing the image, please wait...</p>
          <p className="text-xs text-muted-foreground mt-1">(This may take a moment depending on image complexity)</p>
        </div>
      )}

      {analysisResult && !isLoading && (
        <Card className="shadow-xl mt-6">
          <CardHeader>
            <CardTitle className="font-headline text-xl">Crime Scene Analysis Report</CardTitle>
            <CardDescription>
              Date: {new Date().toLocaleDateString()} | File: {file?.name || 'N/A'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <section>
              <h3 className="text-lg font-semibold mb-2 flex items-center"><ListChecks className="mr-2 h-5 w-5 text-primary" />Identified Elements</h3>
              {analysisResult.identifiedElements.length > 0 && !analysisResult.identifiedElements[0]?.name.startsWith("Error") ? (
                <div className="space-y-3 max-h-96 overflow-y-auto pr-2 rounded-md border bg-muted/20 p-3">
                  {analysisResult.identifiedElements.map((element, index) => (
                    <div key={index} className="p-3 border-b last:border-b-0 bg-card shadow-sm rounded-md">
                      <p className="font-semibold text-primary">{element.name} {element.count && `(Count: ${element.count})`}</p>
                      <p className="text-sm"><span className="font-medium text-muted-foreground">Category:</span> {element.category}</p>
                      <p className="text-sm"><span className="font-medium text-muted-foreground">Description:</span> {element.description}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground p-3 border rounded-md bg-muted/20">{analysisResult.identifiedElements[0]?.description || "No specific elements prominently identified or analysis incomplete."}</p>
              )}
            </section>

            <section>
              <Label htmlFor="sceneNarrative" className="text-lg font-semibold mb-2 flex items-center"><FileText className="mr-2 h-5 w-5 text-primary" />Scene Narrative (Editable)</Label>
              <Textarea
                id="sceneNarrative"
                value={editableSceneNarrative}
                onChange={(e) => setEditableSceneNarrative(e.target.value)}
                rows={10}
                className="mt-1 bg-background border p-3 rounded-md"
                placeholder="AI-generated scene narrative will appear here. You can edit it."
              />
            </section>

            <section>
              <Label htmlFor="caseFileSummary" className="text-lg font-semibold mb-2 flex items-center"><Lightbulb className="mr-2 h-5 w-5 text-primary" />Case File Summary & Hypotheses (Editable)</Label>
               <Textarea
                id="caseFileSummary"
                value={editableCaseFileSummary}
                onChange={(e) => setEditableCaseFileSummary(e.target.value)}
                rows={8}
                className="mt-1 bg-background border p-3 rounded-md"
                placeholder="AI-generated summary and hypotheses will appear here. You can edit it."
              />
            </section>
          </CardContent>
          <CardFooter className="flex flex-col sm:flex-row justify-between items-center gap-3 border-t pt-4">
            <p className="text-sm text-muted-foreground flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500" />
              AI-generated analysis. Verify with physical investigation.
            </p>
            <div className="flex gap-2 flex-wrap justify-end">
                <Button variant="outline" onClick={handleDownloadText} disabled={!analysisResult}><Download className="mr-2 h-4 w-4" />Download as Text</Button>
                <Button variant="outline" disabled><Download className="mr-2 h-4 w-4" />PDF (Soon)</Button>
                <Button onClick={handleOpenSaveDialog} disabled={!analysisResult || !user || isSaving}>
                  {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  <Save className="mr-2 h-4 w-4" />Finalize & Save
                </Button>
            </div>
          </CardFooter>
        </Card>
      )}

      <AlertDialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Save Crime Scene Analysis Report</AlertDialogTitle>
            <AlertDialogDescription>
              Select an existing case (FIR) to associate this crime scene analysis report with.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="selectCaseForSave">Select Case (FIR)</Label>
              {isLoadingCases ? (
                <div className="flex items-center text-sm text-muted-foreground">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading cases...
                </div>
              ) : casesError ? (
                <div className="text-sm text-destructive">{casesError}</div>
              ) : allCases.length === 0 ? (
                <div className="text-sm text-muted-foreground">No cases available to link. Please register a case first.</div>
              ) : (
                <Select onValueChange={setSelectedCaseIdForSave} value={selectedCaseIdForSave || ""}>
                  <SelectTrigger id="selectCaseForSave" className="w-full">
                    <SelectValue placeholder="Choose a case..." />
                  </SelectTrigger>
                  <SelectContent>
                    {allCases.map((c) => (
                      <SelectItem key={c.id} value={c.id!}>
                        {c.firNumber} - {c.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
                The report for "<strong>{file?.name || 'current image'}</strong>" will be saved under the selected case.
            </p>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isSaving}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmSaveReport} disabled={!selectedCaseIdForSave || isSaving || isLoadingCases || allCases.length === 0}>
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm & Save Report
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
}
    