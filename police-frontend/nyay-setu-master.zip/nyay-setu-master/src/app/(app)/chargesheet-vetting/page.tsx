"use client";

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2, AlertTriangle, FileCheck2, UploadCloud } from 'lucide-react';
import { chargesheetVetting, type ChargesheetVettingInput, type ChargesheetVettingOutput } from '@/ai/flows/chargesheet-vetting';
import { useToast } from '@/hooks/use-toast';

export default function ChargesheetVettingPage() {
  const [chargesheetContent, setChargesheetContent] = useState('');
  const [suggestions, setSuggestions] = useState<ChargesheetVettingOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type === "text/plain" || file.name.endsWith(".txt")) {
        const text = await file.text();
        setChargesheetContent(text);
        toast({ title: "File Uploaded", description: `${file.name} content loaded.` });
      } else {
        toast({ variant: "destructive", title: "Invalid File Type", description: "Please upload a plain text (.txt) file." });
      }
    }
  };

  const handleSubmit = async () => {
    if (!chargesheetContent.trim()) {
      toast({ variant: "destructive", title: "Input Missing", description: "Please upload or paste the charge sheet content." });
      return;
    }
    setIsLoading(true);
    setSuggestions(null);
    try {
      const input: ChargesheetVettingInput = { chargesheet: chargesheetContent };
      const output = await chargesheetVetting(input);
      setSuggestions(output);
      toast({ title: "Success", description: "Charge sheet vetted and suggestions provided." });
    } catch (error) {
      console.error("Chargesheet Vetting Error:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to vet charge sheet." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><FileCheck2 className="mr-2 h-6 w-6"/>Charge Sheet Vetting AI</CardTitle>
          <CardDescription>
            Upload or paste an existing charge sheet. The AI will review it and suggest improvements to strengthen the case.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="chargesheetFile" className="text-lg">Upload Charge Sheet ( .txt file )</Label>
            <div className="mt-1 flex items-center gap-2">
              <Input
                id="chargesheetFile"
                type="file"
                accept=".txt"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
              />
              <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                <UploadCloud className="mr-2 h-4 w-4" /> Choose File
              </Button>
               {chargesheetContent && <span className="text-sm text-muted-foreground">File loaded. You can also edit below.</span>}
            </div>
          </div>
          <div>
            <Label htmlFor="chargesheetContent" className="text-lg">Or Paste Charge Sheet Content</Label>
            <Textarea
              id="chargesheetContent"
              value={chargesheetContent}
              onChange={(e) => setChargesheetContent(e.target.value)}
              placeholder="Paste the full content of the charge sheet here..."
              rows={15}
              className="mt-1"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Vet Charge Sheet
          </Button>
        </CardFooter>
      </Card>

      {isLoading && (
        <div className="flex justify-center items-center p-10">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-muted-foreground">Vetting charge sheet, please wait...</p>
        </div>
      )}

      {suggestions && (
        <Card className="shadow-xl mt-6">
          <CardHeader>
            <CardTitle className="font-headline text-xl">AI Vetting Suggestions</CardTitle>
            <CardDescription>Review the suggestions to improve the charge sheet.</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea value={suggestions.suggestions} readOnly rows={15} className="mt-1 bg-muted/50 whitespace-pre-wrap" />
          </CardContent>
          <CardFooter>
            <p className="text-sm text-muted-foreground flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500" />
              AI-generated suggestions. Legal expertise is required for final decisions.
            </p>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
