"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2, AlertTriangle, Users, MessageSquare } from 'lucide-react';
import { witnessPreparation, type WitnessPreparationInput, type WitnessPreparationOutput } from '@/ai/flows/witness-preparation';
import { useToast } from '@/hooks/use-toast';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function WitnessPreparationPage() {
  const [caseDetails, setCaseDetails] = useState('');
  const [witnessStatement, setWitnessStatement] = useState('');
  const [witnessName, setWitnessName] = useState('');
  const [preparationResult, setPreparationResult] = useState<WitnessPreparationOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!caseDetails.trim() || !witnessStatement.trim() || !witnessName.trim()) {
      toast({ variant: "destructive", title: "Input Missing", description: "Please fill in all fields: case details, witness statement, and witness name." });
      return;
    }
    setIsLoading(true);
    setPreparationResult(null);
    try {
      const input: WitnessPreparationInput = { caseDetails, witnessStatement, witnessName };
      const output = await witnessPreparation(input);
      setPreparationResult(output);
      toast({ title: "Success", description: "Witness preparation session complete." });
    } catch (error) {
      console.error("Witness Preparation Error:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to conduct witness preparation session." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Users className="mr-2 h-6 w-6"/>AI Witness Preparation</CardTitle>
          <CardDescription>
            Simulate a mock trial experience for a witness. The AI assistant will ask potential cross-examination questions.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="witnessName" className="text-lg">Witness Name</Label>
            <Input
              id="witnessName"
              value={witnessName}
              onChange={(e) => setWitnessName(e.target.value)}
              placeholder="Enter the witness's full name"
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="caseDetails" className="text-lg">Case Details</Label>
            <Textarea
              id="caseDetails"
              value={caseDetails}
              onChange={(e) => setCaseDetails(e.target.value)}
              placeholder="Provide comprehensive case details: charges, evidence, known facts, etc."
              rows={8}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="witnessStatement" className="text-lg">Witness Statement</Label>
            <Textarea
              id="witnessStatement"
              value={witnessStatement}
              onChange={(e) => setWitnessStatement(e.target.value)}
              placeholder="Enter the witness's statement that will be used for the mock trial."
              rows={8}
              className="mt-1"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Start Mock Trial
          </Button>
        </CardFooter>
      </Card>

      {isLoading && (
        <div className="flex justify-center items-center p-10">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-muted-foreground">Preparing mock trial session...</p>
        </div>
      )}

      {preparationResult && (
        <Card className="shadow-xl mt-6">
          <CardHeader>
            <CardTitle className="font-headline text-xl flex items-center"><MessageSquare className="mr-2 h-5 w-5"/>Mock Trial & Feedback</CardTitle>
            <CardDescription>Review the mock trial transcript and AI feedback for witness {witnessName}.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="text-lg font-semibold">Mock Trial Transcript</Label>
              <ScrollArea className="h-72 w-full rounded-md border p-3 mt-1 bg-muted/30">
                <pre className="text-sm whitespace-pre-wrap">{preparationResult.mockTrialTranscript}</pre>
              </ScrollArea>
            </div>
            <div>
              <Label className="text-lg font-semibold">Potential Weaknesses</Label>
              <Textarea value={preparationResult.potentialWeaknesses} readOnly rows={4} className="mt-1 bg-muted/50" />
            </div>
            <div>
              <Label className="text-lg font-semibold">Suggested Improvements</Label>
              <Textarea value={preparationResult.suggestedImprovements} readOnly rows={4} className="mt-1 bg-muted/50" />
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-sm text-muted-foreground flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500" />
              This is an AI simulation. Real trial conditions may vary.
            </p>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
