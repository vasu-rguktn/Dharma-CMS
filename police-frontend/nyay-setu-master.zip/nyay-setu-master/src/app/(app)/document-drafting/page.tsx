"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, AlertTriangle, FileEdit } from 'lucide-react';
import { draftDocument, type DraftDocumentInput, type DraftDocumentOutput } from '@/ai/flows/document-drafting';
import { useToast } from '@/hooks/use-toast';

type RecipientType = 'medical officer' | 'forensic expert';

export default function DocumentDraftingPage() {
  const [caseData, setCaseData] = useState('');
  const [recipientType, setRecipientType] = useState<RecipientType | ''>('');
  const [additionalInstructions, setAdditionalInstructions] = useState('');
  const [draft, setDraft] = useState<DraftDocumentOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!caseData.trim() || !recipientType) {
      toast({ variant: "destructive", title: "Input Missing", description: "Please provide case data and select a recipient type." });
      return;
    }
    setIsLoading(true);
    setDraft(null);
    try {
      const input: DraftDocumentInput = {
        caseData,
        recipientType: recipientType as RecipientType, // Ensure type
        additionalInstructions: additionalInstructions.trim() ? additionalInstructions : undefined,
      };
      const output = await draftDocument(input);
      setDraft(output);
      toast({ title: "Success", description: "Document draft generated." });
    } catch (error) {
      console.error("Document Drafting Error:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to generate document draft." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><FileEdit className="mr-2 h-6 w-6"/>AI Document Drafter</CardTitle>
          <CardDescription>
            Generate document drafts based on case data for specific recipients like medical officers or forensic experts.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="caseData" className="text-lg">Case Data</Label>
            <Textarea
              id="caseData"
              value={caseData}
              onChange={(e) => setCaseData(e.target.value)}
              placeholder="Paste all relevant case data: complaint transcripts, witness statements, FIR details, investigation notes, etc..."
              rows={10}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="recipientType" className="text-lg">Recipient Type</Label>
            <Select onValueChange={(value) => setRecipientType(value as RecipientType)} value={recipientType}>
              <SelectTrigger id="recipientType" className="mt-1">
                <SelectValue placeholder="Select recipient type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="medical officer">Medical Officer</SelectItem>
                <SelectItem value="forensic expert">Forensic Expert</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="additionalInstructions" className="text-lg">Additional Instructions (Optional)</Label>
            <Textarea
              id="additionalInstructions"
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              placeholder="E.g., 'Focus on injuries sustained', 'Request specific tests for DNA analysis', 'Keep the tone formal and urgent'..."
              rows={3}
              className="mt-1"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Draft Document
          </Button>
        </CardFooter>
      </Card>

      {isLoading && (
        <div className="flex justify-center items-center p-10">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-muted-foreground">Drafting document, please wait...</p>
        </div>
      )}

      {draft && (
        <Card className="shadow-xl mt-6">
          <CardHeader>
            <CardTitle className="font-headline text-xl">Generated Document Draft</CardTitle>
            <CardDescription>Review the generated draft. You can copy and edit it as needed.</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea value={draft.draft} readOnly rows={20} className="mt-1 bg-muted/50 whitespace-pre-wrap" />
          </CardContent>
           <CardFooter className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500" />
              AI-generated content. Verify and adapt for official use.
            </p>
            <Button variant="outline" onClick={() => navigator.clipboard.writeText(draft.draft)}>Copy Draft</Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
