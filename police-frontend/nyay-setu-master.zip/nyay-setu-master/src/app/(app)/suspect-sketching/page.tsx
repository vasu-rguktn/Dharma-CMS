
"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { AlertTriangle } from 'lucide-react';

export default function SuspectSketchingPage() {
  return (
    <div className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center">
            <AlertTriangle className="mr-2 h-6 w-6 text-destructive" /> AI Suspect Sketcher (Temporarily Disabled)
          </CardTitle>
          <CardDescription>
            This feature is currently undergoing maintenance or review. Please check back later.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            We are working on improving this feature. Thank you for your patience.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
