// This page has been removed.
// The FIR Autofill feature is no longer available.

export default function FIRAutofillPage() {
  return null;
}
