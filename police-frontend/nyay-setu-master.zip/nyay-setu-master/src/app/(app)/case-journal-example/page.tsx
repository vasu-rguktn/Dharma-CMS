"use client";
// This is a placeholder page that redirects to an example case detail page (caseId '1')
// to demonstrate the Case Journal functionality from the sidebar.
// In a real application, this might be a list of cases or a specific case selection logic.

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

export default function CaseJournalExampleRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/cases/1'); // Redirect to example case with ID '1'
  }, [router]);

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
      <Loader2 className="h-12 w-12 animate-spin text-primary" />
      <p className="ml-4 text-muted-foreground">Loading example case journal...</p>
    </div>
  );
}
