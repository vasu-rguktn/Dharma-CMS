
"use client";

import { useState, useRef, type ChangeEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2, AlertTriangle, FilePlus2, UploadCloud, List, XCircle } from 'lucide-react';
import { generateChargeSheet, type GenerateChargeSheetInput, type GenerateChargeSheetOutput } from '@/ai/flows/chargesheet-generation';
import { useToast } from '@/hooks/use-toast';

interface UploadedDoc {
  file: File;
  name: string;
  dataUri?: string; // Will be populated before sending to AI
  contentType?: string; // Will be populated before sending to AI
}

export default function ChargeSheetGenerationPage() {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedDoc[]>([]);
  const [additionalInstructions, setAdditionalInstructions] = useState('');
  const [chargeSheet, setChargeSheet] = useState<GenerateChargeSheetOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const getContentType = (fileName: string): string => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf': return 'application/pdf';
      case 'doc': return 'application/msword';
      case 'docx': return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'txt': return 'text/plain';
      default: return 'application/octet-stream'; // Fallback
    }
  };

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newFiles: UploadedDoc[] = Array.from(files).map(file => ({
        file,
        name: file.name,
      }));
      // Prevent duplicates by name, new files replace old ones with same name
      setUploadedFiles(prevFiles => {
        const existingNames = new Set(prevFiles.map(f => f.name));
        const trulyNewFiles = newFiles.filter(nf => !existingNames.has(nf.name));
        const updatedOldFiles = prevFiles.map(pf => {
            const replacement = newFiles.find(nf => nf.name === pf.name);
            return replacement || pf;
        });
        return [...updatedOldFiles.filter(uof => !newFiles.some(nf => nf.name === uof.name && !trulyNewFiles.some(tnf => tnf.name === uof.name))), ...trulyNewFiles];
      });
    }
  };
  
  const removeFile = (fileName: string) => {
    setUploadedFiles(prevFiles => prevFiles.filter(f => f.name !== fileName));
  };

  const convertFileToDataUri = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
      reader.readAsDataURL(file);
    });
  };

  const handleSubmit = async () => {
    if (uploadedFiles.length === 0) {
      toast({ variant: "destructive", title: "Input Missing", description: "Please upload at least one document." });
      return;
    }
    setIsLoading(true);
    setChargeSheet(null);

    try {
      const documentsForApi = await Promise.all(
        uploadedFiles.map(async (uploadedDoc) => ({
          name: uploadedDoc.file.name,
          dataUri: await convertFileToDataUri(uploadedDoc.file),
          contentType: getContentType(uploadedDoc.file.name),
        }))
      );

      const input: GenerateChargeSheetInput = {
        documents: documentsForApi,
        additionalInstructions: additionalInstructions.trim() ? additionalInstructions : undefined,
      };
      const output = await generateChargeSheet(input);
      setChargeSheet(output);
      toast({ title: "Success", description: "Draft charge sheet generated." });
    } catch (error) {
      console.error("Charge Sheet Generation Error:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to generate charge sheet." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><FilePlus2 className="mr-2 h-6 w-6"/>Charge Sheet Generator</CardTitle>
          <CardDescription>
            Upload relevant documents (FIR, witness statements, evidence reports in .doc, .docx, .pdf, .txt) and provide additional instructions. The AI will formulate a draft charge sheet based on the provided template.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="caseDocuments" className="text-lg">Case Documents</Label>
            <div className="mt-1">
              <Input
                id="caseDocuments"
                type="file"
                multiple
                accept=".doc,.docx,.pdf,.txt,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf,text/plain"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
              />
              <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} className="w-full sm:w-auto">
                <UploadCloud className="mr-2 h-4 w-4" /> Choose Files
              </Button>
            </div>
            {uploadedFiles.length > 0 && (
              <div className="mt-4 space-y-2">
                <h4 className="text-md font-medium flex items-center"><List className="mr-2 h-5 w-5 text-primary"/>Uploaded Files:</h4>
                <ul className="list-none space-y-1 rounded-md border p-3 bg-muted/50 max-h-48 overflow-y-auto">
                  {uploadedFiles.map((uploadedDoc) => (
                    <li key={uploadedDoc.name} className="text-sm flex items-center justify-between p-1.5 hover:bg-muted rounded-md">
                      <span className="truncate" title={uploadedDoc.name}>{uploadedDoc.name}</span>
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:bg-destructive/10" onClick={() => removeFile(uploadedDoc.name)}>
                        <XCircle className="h-4 w-4" />
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="additionalInstructions" className="text-lg">Additional Instructions (Optional)</Label>
            <Textarea
              id="additionalInstructions"
              value={additionalInstructions}
              onChange={(e) => setAdditionalInstructions(e.target.value)}
              placeholder="E.g., 'Focus on connecting Accused A to the weapon found.', 'Emphasize the premeditation aspect based on Witness B's statement.'..."
              rows={5}
              className="mt-1"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleSubmit} disabled={isLoading || uploadedFiles.length === 0}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Generate Draft Charge Sheet
          </Button>
        </CardFooter>
      </Card>

      {isLoading && (
        <div className="flex justify-center items-center p-10">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-muted-foreground">Generating charge sheet, this may take a moment...</p>
        </div>
      )}

      {chargeSheet && (
        <Card className="shadow-xl mt-6">
          <CardHeader>
            <CardTitle className="font-headline text-xl">Generated Draft Charge Sheet</CardTitle>
            <CardDescription>Review the generated draft. This is a starting point and requires legal review and verification against original documents.</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea value={chargeSheet.chargeSheet} readOnly rows={25} className="mt-1 bg-muted/50 whitespace-pre-wrap text-xs sm:text-sm" />
          </CardContent>
          <CardFooter className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500" />
              AI-generated content. Must be reviewed and verified by a legal professional.
            </p>
             <Button variant="outline" onClick={() => navigator.clipboard.writeText(chargeSheet.chargeSheet)}>Copy Draft</Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}

    