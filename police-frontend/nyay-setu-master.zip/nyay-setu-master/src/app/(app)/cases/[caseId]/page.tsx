
"use client";

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { doc, getDoc, Timestamp, collection, query, where, orderBy, onSnapshot, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { CaseDoc, CrimeDetails, CaseJournalEntry, MediaAnalysisRecord, IdentifiedElement } from '@/types'; 
import { CaseStatus } from '@/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import CrimeDetailsForm from '@/components/cases/CrimeDetailsForm';
import EmbeddedCrimeSceneChat from '@/components/cases/EmbeddedCrimeSceneChat';
import {
  ArrowLeft, Edit, PlusCircle, Printer, Loader2, AlertTriangle, FileText, User, Users, Shield, MapPin, Clock, CalendarDays, BookOpen,
  Search, Archive as PropertyIcon, Eye, Stethoscope, UserMinus as ArrestIcon, FileOutput, GripVertical, Building, Milestone, LandmarkIcon, ListChecks, UserCheck, UserCog, Gavel, LocateFixed, PackageSearch, MessageSquare, Image as ImageIcon, ListNested
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import Image from 'next/image'; // For displaying images
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';


const statusColors: Record<CaseStatus, string> = {
  [CaseStatus.New]: 'bg-blue-500 hover:bg-blue-600',
  [CaseStatus.UnderInvestigation]: 'bg-orange-500 hover:bg-orange-600',
  [CaseStatus.PendingTrial]: 'bg-yellow-500 hover:bg-yellow-600 text-black',
  [CaseStatus.Resolved]: 'bg-green-500 hover:bg-green-600',
  [CaseStatus.Closed]: 'bg-gray-500 hover:bg-gray-600',
};

const caseStagesConfig = [
  { id: 'firDetails', title: 'FIR Details', icon: FileText, color: 'bg-blue-600', textColor: 'text-blue-600', hoverColor: 'hover:bg-blue-700', description: "Complete First Information Report details." },
  { id: 'crimeScene', title: 'Crime Scene & Details', icon: PackageSearch, color: 'bg-orange-500', textColor: 'text-orange-500', hoverColor: 'hover:bg-orange-600', description: "Crime details, scene observation, property seizure, and media analysis reports." },
  { id: 'investigationProgress', title: 'Investigation Progress', icon: Search, color: 'bg-teal-600', textColor: 'text-teal-600', hoverColor: 'hover:bg-teal-700', description: "Witness examinations, medical reports, arrests, and case diary." },
  { id: 'evidence', title: 'Evidence & Seizures', icon: PropertyIcon, color: 'bg-green-600', textColor: 'text-green-600', hoverColor: 'hover:bg-green-700', description: "Collected evidence and seized property details." },
  { id: 'finalReport', title: 'Final Report/Chargesheet', icon: FileOutput, color: 'bg-amber-500', textColor: 'text-amber-500', hoverColor: 'hover:bg-amber-600', description: "Charge sheet or case closure report." },
] as const;

type StageId = typeof caseStagesConfig[number]['id'];

const CaseTimeline = ({ entries, isLoadingJournal, journalError }: { entries: CaseJournalEntry[], isLoadingJournal?: boolean, journalError?: string | null }) => { 
  if (isLoadingJournal) {
    return (
      <div className="flex items-center justify-center py-4">
        <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
        <p className="text-muted-foreground">Loading journal entries...</p>
      </div>
    );
  }
  if (journalError) {
    return (
        <Alert variant="destructive" className="my-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Journal Error</AlertTitle>
            <AlertDescription>{journalError}</AlertDescription>
        </Alert>
    );
  }
  if (!entries || entries.length === 0) {
    return <p className="text-muted-foreground py-4">No journal entries yet for this case.</p>;
  }
  return (
    <div className="relative pl-6 after:absolute after:inset-y-0 after:w-px after:bg-border after:left-0">
      {entries.map((entry, index) => (
        <div key={entry.id || index} className={`relative pb-8 ${index === entries.length - 1 ? '' : 'after:absolute after:top-8 after:bottom-0 after:w-px after:bg-border after:left-[calc(0.5rem-1px)]'}`}>
          <div className="absolute left-[-0.60rem] top-2 z-10 flex h-5 w-5 items-center justify-center rounded-full bg-primary ring-4 ring-background">
            <div className="h-2 w-2 rounded-full bg-primary-foreground"></div>
          </div>
          <div className="grid flex-1 gap-1">
            <div className="font-semibold text-foreground">{entry.activityType}</div>
            <div className="text-sm text-muted-foreground whitespace-pre-wrap break-words">{entry.entryText}</div>
            <div className="text-xs text-muted-foreground">
              {entry.dateTime ? formatDateForDisplay(entry.dateTime, 'PP p') : 'Date N/A'}
              {' by '}{entry.officerName || 'Officer N/A'} ({entry.officerRank || 'Rank N/A'})
              {entry.relatedDocumentId && <span className="ml-2 text-blue-500">(Ref: {entry.relatedDocumentId})</span>}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

const formatDateForDisplay = (dateInput: any, timeFormat = 'PPP p'): string => {
  if (!dateInput) return 'N/A';
  if (dateInput instanceof Timestamp) { 
    return format(dateInput.toDate(), timeFormat);
  }
   if (typeof dateInput === 'string' || typeof dateInput === 'number') {
    try {
      const normalizedDateString = typeof dateInput === 'string' ? dateInput.replace(' ', 'T') : dateInput;
      const parsedDate = new Date(normalizedDateString);
      if (!isNaN(parsedDate.getTime())) {
        if (typeof dateInput === 'string' && !dateInput.includes('T') && !dateInput.includes(':') && timeFormat === 'PPP p') {
            return format(parsedDate, 'PPP');
        }
        return format(parsedDate, timeFormat);
      }
    } catch (e) { /* Fall through */ }
  }
  if (dateInput.toDate && typeof dateInput.toDate === 'function') { 
    return format(dateInput.toDate(), timeFormat);
  }
  try {
    const date = new Date(dateInput);
    if (isNaN(date.getTime())) { 
        return String(dateInput); 
    }
    return format(date, timeFormat);
  } catch (e) {
    return String(dateInput); 
  }
};

const DetailItem = ({ label, value, icon: Icon, isBoolean = false, isLink = false }: { label: string; value?: string | string[] | number | null | boolean; icon?: React.ElementType, isBoolean?: boolean, isLink?: boolean }) => {
  if (value === undefined || value === null || value === '') {
    if (isBoolean && value === false) { 
      // continue
    } else {
      return null;
    }
  }
  
  let displayValue: React.ReactNode;
  if (isBoolean) {
     displayValue = value ? "Yes" : "No";
  } else if (Array.isArray(value)) {
    displayValue = value.join(', ');
  } else if (isLink && typeof value === 'string' && value.startsWith('http')) {
    displayValue = <a href={value} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{value}</a>;
  } else {
    displayValue = String(value);
  }

  return (
    <div className="mb-3">
      <h4 className="text-sm font-semibold text-muted-foreground flex items-center">
        {Icon && <Icon className="mr-2 h-4 w-4" />}
        {label}
      </h4>
      <p className="text-foreground whitespace-pre-wrap break-words">{displayValue}</p>
    </div>
  );
};


export default function CaseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const caseId = params.caseId as string;
  
  const [caseData, setCaseData] = useState<CaseDoc | null>(null);
  const [crimeDetails, setCrimeDetails] = useState<CrimeDetails | null>(null);
  const [mediaAnalyses, setMediaAnalyses] = useState<MediaAnalysisRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeStageId, setActiveStageId] = useState<StageId>('firDetails');
  const [isFetchingCrimeDetails, setIsFetchingCrimeDetails] = useState(false);
  const [isFetchingMediaAnalyses, setIsFetchingMediaAnalyses] = useState(false);
  const [mediaAnalysesError, setMediaAnalysesError] = useState<string | null>(null);


  const [journalEntries, setJournalEntries] = useState<CaseJournalEntry[]>([]);
  const [isLoadingJournal, setIsLoadingJournal] = useState(false);
  const [journalError, setJournalError] = useState<string | null>(null);


  useEffect(() => {
    if (caseId) {
      const fetchAllCaseData = async () => {
        setIsLoading(true);
        setError(null);
        setMediaAnalysesError(null);
        setJournalError(null);
        try {
          // Fetch Case (FIR) Data
          const caseRef = doc(db, 'cases', caseId);
          const caseSnap = await getDoc(caseRef);

          if (caseSnap.exists()) {
            const fetchedCaseData = { id: caseSnap.id, ...caseSnap.data() } as CaseDoc;
            setCaseData(fetchedCaseData);

            // Fetch Crime Details
            setIsFetchingCrimeDetails(true);
            try {
                const crimeDetailsRef = doc(db, 'crimeDetails', caseId);
                const crimeDetailsSnap = await getDoc(crimeDetailsRef);
                setCrimeDetails(crimeDetailsSnap.exists() ? { id: crimeDetailsSnap.id, ...crimeDetailsSnap.data() } as CrimeDetails : null);
            } catch (crimeErr: any) {
                console.warn("Could not fetch crime details:", crimeErr.message);
                setCrimeDetails(null);
            } finally {
                setIsFetchingCrimeDetails(false);
            }

            // Fetch Media Analyses
            setIsFetchingMediaAnalyses(true);
            const analysesPathForLog = `cases/${caseId}/mediaAnalyses`;
            try {
              console.log(`Attempting to fetch media analyses from Firestore path: ${analysesPathForLog}`);
              const analysesRef = collection(db, 'cases', caseId, 'mediaAnalyses');
              const analysesQuery = query(analysesRef, orderBy('createdAt', 'desc'));
              const analysesSnap = await getDocs(analysesQuery);
              const fetchedAnalyses: MediaAnalysisRecord[] = [];
              analysesSnap.forEach(doc => fetchedAnalyses.push({ id: doc.id, ...doc.data() } as MediaAnalysisRecord));
              setMediaAnalyses(fetchedAnalyses);
            } catch (analysesErr: any) {
              console.error(`Error fetching media analyses from ${analysesPathForLog}:`, analysesErr);
              setMediaAnalysesError(`Failed to load media analyses. ${analysesErr.message}. Check Firestore rules for path: ${analysesPathForLog}`);
            } finally {
              setIsFetchingMediaAnalyses(false);
            }

          } else {
            setError('Case not found.');
            setCaseData(null);
          }
        } catch (err: any) {
          console.error("Error fetching case data:", err);
          setError(`Failed to fetch case data. ${err.message}`);
          setCaseData(null);
        } finally {
          setIsLoading(false);
        }
      };
      fetchAllCaseData();
    } else {
        setError('No Case ID provided.');
        setIsLoading(false);
        setCaseData(null);
    }
  }, [caseId]);

  useEffect(() => {
    if (activeStageId === 'investigationProgress' && caseData?.id) {
      setIsLoadingJournal(true);
      setJournalError(null);
      const journalQuery = query(
        collection(db, 'caseJournalEntries'),
        where('caseId', '==', caseData.id),
        orderBy('dateTime', 'desc')
      );
      const unsubscribe = onSnapshot(journalQuery, (querySnapshot) => {
        const entries: CaseJournalEntry[] = [];
        querySnapshot.forEach((doc) => entries.push({ id: doc.id, ...doc.data() } as CaseJournalEntry));
        setJournalEntries(entries);
        setIsLoadingJournal(false);
      }, (err: any) => {
        console.error("Error fetching journal entries: ", err);
        setJournalError(`Failed to load case journal. ${err.message || 'Please try again.'}`);
        setIsLoadingJournal(false);
      });
      return () => unsubscribe();
    } else {
        setJournalEntries([]);
        setIsLoadingJournal(false);
        setJournalError(null);
    }
  }, [activeStageId, caseData?.id]);
  
  const handleCrimeDetailsSaved = (savedData: CrimeDetails) => {
    setCrimeDetails(savedData);
  };


  const renderStageContent = () => {
    const stageConfig = caseStagesConfig.find(s => s.id === activeStageId);
    if (!caseData && !isLoading) { 
      return <Card className="shadow-md"><CardContent><p className="text-muted-foreground p-4">Case data is not available.</p></CardContent></Card>;
    }
    if (!stageConfig) return <Card className="shadow-md"><CardContent><p className="text-muted-foreground p-4">Select a stage.</p></CardContent></Card>;
    if (isLoading && !caseData) {
        return <Card className="shadow-md"><CardContent className="p-6 flex items-center justify-center min-h-[300px]"><Loader2 className="h-8 w-8 animate-spin text-primary mr-2" />Loading details...</CardContent></Card>;
    }

    switch (activeStageId) {
      case 'firDetails':
        if (!caseData) return <Card className="shadow-md"><CardContent><p className="text-muted-foreground p-4">Loading FIR details...</p></CardContent></Card>;
        return (
          <Card className="shadow-md">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="font-headline text-xl flex items-center"><stageConfig.icon className="mr-2 h-5 w-5 text-primary"/>{stageConfig.title}</CardTitle>
              <Button variant="outline" size="sm" disabled><Edit className="mr-2 h-4 w-4" /> Edit FIR</Button>
            </CardHeader>
            <CardContent className="space-y-6 pt-4">
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">1. District & FIR Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2">
                  <DetailItem label="Case Title" value={caseData.title} />
                  <DetailItem label="District" value={caseData.district} icon={Building} />
                  <DetailItem label="Police Station" value={caseData.policeStation} icon={Building} />
                  <DetailItem label="Year" value={caseData.year} />
                  <DetailItem label="FIR Number" value={caseData.firNumber} />
                  <DetailItem label="FIR Registration Date" value={formatDateForDisplay(caseData.date, 'PPP')} icon={CalendarDays} />
                </div>
              </section>
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">2. Occurrence of Offence</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2">
                  <DetailItem label="Day" value={caseData.occurrenceDay} />
                  <DetailItem label="Date/Time From" value={formatDateForDisplay(caseData.occurrenceDateTimeFrom)} icon={Clock} />
                  <DetailItem label="Date/Time To" value={formatDateForDisplay(caseData.occurrenceDateTimeTo)} icon={Clock}/>
                  <DetailItem label="Time Period" value={caseData.occurrenceTimePeriod} />
                  <DetailItem label="Prior to Date/Time Details" value={caseData.occurrencePriorToDateTime} />
                  <DetailItem label="Beat Number" value={caseData.occurrenceBeatNumber} icon={Milestone} />
                </div>
                <h4 className="text-sm font-semibold mt-3 mb-1 text-muted-foreground">Place of Occurrence:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1">
                  <DetailItem label="Street/Village" value={caseData.occurrencePlace?.streetVillage} />
                  <DetailItem label="Area/Mandal" value={caseData.occurrencePlace?.areaMandal} />
                  <DetailItem label="City/District" value={caseData.occurrencePlace?.cityDistrict} />
                  <DetailItem label="State" value={caseData.occurrencePlace?.state} />
                  <DetailItem label="PIN" value={caseData.occurrencePlace?.pin} />
                  <DetailItem label="Latitude" value={caseData.occurrencePlace?.latitude?.toString()} icon={LocateFixed} />
                  <DetailItem label="Longitude" value={caseData.occurrencePlace?.longitude?.toString()} icon={LocateFixed} />
                </div>
                 <h4 className="text-sm font-semibold mt-3 mb-1 text-muted-foreground">Distance & Direction from PS:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1">
                  <DetailItem label="Distance" value={caseData.occurrenceDistanceDirectionFromPS?.distance} />
                  <DetailItem label="Direction" value={caseData.occurrenceDistanceDirectionFromPS?.direction} />
                </div>
                <h4 className="text-sm font-semibold mt-3 mb-1 text-muted-foreground">Outside Jurisdiction:</h4>
                 <DetailItem label="Is Outside?" value={caseData.occurrenceOutsideJurisdiction?.isOutside} isBoolean/>
                 {caseData.occurrenceOutsideJurisdiction?.isOutside && <DetailItem label="Other PS Name" value={caseData.occurrenceOutsideJurisdiction?.policeStationName}/>}
              </section>
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">3. Information Received</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
                    <DetailItem label="Date/Time Received at PS" value={formatDateForDisplay(caseData.infoReceivedDateTime)} icon={Clock}/>
                    <DetailItem label="GD Entry No." value={caseData.infoReceivedEntryNumber}/>
                </div>
                <h3 className="text-md font-semibold text-muted-foreground mt-3 mb-2 border-b pb-1">4. Type of Information</h3>
                <DetailItem label="Type" value={caseData.typeOfInformation} />
              </section>
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">5. Complainant / Informant Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2">
                  <DetailItem label="Name" value={caseData.complainantName} icon={User}/>
                  <DetailItem label="Father's/Husband's Name" value={caseData.complainantFatherHusbandName}/>
                  <DetailItem label="Gender" value={caseData.complainantGender}/>
                  <DetailItem label="Nationality" value={caseData.complainantNationality}/>
                  <DetailItem label="Caste" value={caseData.complainantCaste}/>
                  <DetailItem label="Occupation" value={caseData.complainantOccupation}/>
                  <DetailItem label="Date of Birth" value={formatDateForDisplay(caseData.complainantDateOfBirth, 'PPP')} icon={CalendarDays}/>
                  <DetailItem label="Age" value={caseData.complainantAge}/>
                  <DetailItem label="Mobile Number" value={caseData.complainantMobileNumber}/>
                </div>
                <h4 className="text-sm font-semibold mt-3 mb-1 text-muted-foreground">Address:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1">
                  <DetailItem label="House No" value={caseData.complainantAddress?.houseNo}/>
                  <DetailItem label="Street/Village" value={caseData.complainantAddress?.streetVillage}/>
                  <DetailItem label="Area/Mandal" value={caseData.complainantAddress?.areaMandal}/>
                  <DetailItem label="City/District" value={caseData.complainantAddress?.cityDistrict}/>
                  <DetailItem label="State" value={caseData.complainantAddress?.state}/>
                  <DetailItem label="PIN" value={caseData.complainantAddress?.pin}/>
                </div>
                <h4 className="text-sm font-semibold mt-3 mb-1 text-muted-foreground">Passport (Optional):</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-1">
                  <DetailItem label="Passport No." value={caseData.complainantPassportNumber}/>
                  <DetailItem label="Place of Issue" value={caseData.complainantPassportPlaceOfIssue}/>
                  <DetailItem label="Date of Issue" value={formatDateForDisplay(caseData.complainantPassportDateOfIssue, 'PPP')}/>
                </div>
              </section>
                {caseData.accusedDetails && caseData.accusedDetails.length > 0 && (
                    <section>
                        <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">6. Accused Details</h3>
                        {caseData.accusedDetails.map((accused, index) => (
                        <div key={index} className="mb-4 p-3 border rounded-md bg-muted/20">
                            <h4 className="text-sm font-semibold text-primary mb-2">Accused {index + 1}</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1">
                            <DetailItem label="Serial No." value={accused.serialNo} />
                            <DetailItem label="Name" value={accused.name} icon={UserCog} />
                            <DetailItem label="Father's/Husband's Name" value={accused.fatherHusbandName} />
                            <DetailItem label="Gender" value={accused.gender} />
                            <DetailItem label="Age" value={accused.age} />
                            <DetailItem label="Nationality" value={accused.nationality} />
                            <DetailItem label="Caste" value={accused.caste} />
                            <DetailItem label="Occupation" value={accused.occupation} />
                            <DetailItem label="Cell No." value={accused.cellNo} />
                             <DetailItem label="Email" value={accused.email} />
                            </div>
                            <h5 className="text-xs font-semibold mt-2 mb-1 text-muted-foreground">Address:</h5>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1">
                                <DetailItem label="House No" value={accused.address?.houseNo}/>
                                <DetailItem label="Street/Village" value={accused.address?.streetVillage}/>
                                <DetailItem label="Area/Mandal" value={accused.address?.areaMandal}/>
                                <DetailItem label="City/District" value={accused.address?.cityDistrict}/>
                                <DetailItem label="State" value={accused.address?.state}/>
                                <DetailItem label="PIN" value={accused.address?.pin}/>
                            </div>
                            <h5 className="text-xs font-semibold mt-2 mb-1 text-muted-foreground">Physical Features:</h5>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1">
                                <DetailItem label="Build" value={accused.physicalFeatures?.build}/>
                                <DetailItem label="Height (cms)" value={accused.physicalFeatures?.heightCms}/>
                                <DetailItem label="Complexion" value={accused.physicalFeatures?.complexion}/>
                                <DetailItem label="Deformities/Peculiarities" value={accused.physicalFeatures?.deformitiesPeculiarities}/>
                            </div>
                        </div>
                        ))}
                    </section>
                )}
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">7. Properties Involved</h3>
                 <DetailItem label="Details" value={caseData.propertiesInvolvedDetails} icon={PropertyIcon}/>
                 <DetailItem label="Total Value Stolen (INR)" value={caseData.propertiesTotalValueStolen}/>
              </section>
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">8. Delay in Reporting</h3>
                 <DetailItem label="Is Delayed?" value={caseData.delayInReportingIsDelayed} isBoolean/>
                 {caseData.delayInReportingIsDelayed && <DetailItem label="Reason" value={caseData.delayInReportingReason}/>}
                <h3 className="text-md font-semibold text-muted-foreground mt-3 mb-2 border-b pb-1">9. Inquest Report / U.D. Case Number</h3>
                 <DetailItem label="Number" value={caseData.inquestReportUDCaseNumber}/>
              </section>
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">10. Complaint / Statement</h3>
                 <DetailItem label="Narrative" value={caseData.complaintStatement} icon={FileText}/>
              </section>
                <section>
                    <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">Victim Details</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2">
                        <DetailItem label="Name" value={caseData.victimName} icon={UserCheck} />
                        <DetailItem label="DOB" value={formatDateForDisplay(caseData.victimDob, 'PPP')} />
                        <DetailItem label="Age" value={caseData.victimAge} />
                        <DetailItem label="Gender" value={caseData.victimGender} />
                        <DetailItem label="Father's/Husband's Name" value={caseData.victimFatherHusbandName} />
                        <DetailItem label="Nationality" value={caseData.victimNationality} />
                        <DetailItem label="Religion" value={caseData.victimReligion} />
                        <DetailItem label="Caste" value={caseData.victimCaste} />
                        <DetailItem label="Occupation" value={caseData.victimOccupation} />
                    </div>
                     <h4 className="text-sm font-semibold mt-3 mb-1 text-muted-foreground">Victim Address:</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-1">
                        <DetailItem label="House No" value={caseData.victimAddress?.houseNo}/>
                        <DetailItem label="Street/Village" value={caseData.victimAddress?.streetVillage}/>
                        <DetailItem label="Area/Mandal" value={caseData.victimAddress?.areaMandal}/>
                        <DetailItem label="City/District" value={caseData.victimAddress?.cityDistrict}/>
                        <DetailItem label="State" value={caseData.victimAddress?.state}/>
                        <DetailItem label="PIN" value={caseData.victimAddress?.pin}/>
                    </div>
                </section>
                <section>
                    <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">Acts & Sections Involved</h3>
                    <DetailItem label="Acts/Sections" value={caseData.actsAndSectionsInvolved} icon={Gavel} />
                </section>
              <section>
                <h3 className="text-md font-semibold text-muted-foreground mb-2 border-b pb-1">11. Action Taken</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2">
                    <DetailItem label="Action Type" value={caseData.actionTakenType} />
                    <DetailItem label="Officer Name" value={caseData.actionTakenOfficerName} />
                    <DetailItem label="Officer Rank" value={caseData.actionTakenOfficerRank} />
                    <DetailItem label="District (Officer)" value={caseData.actionTakenDistrict} />
                </div>
                <h3 className="text-md font-semibold text-muted-foreground mt-3 mb-2 border-b pb-1">12. Dispatch to Court</h3>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-2">
                    <DetailItem label="Date/Time" value={formatDateForDisplay(caseData.dispatchToCourtDateTime)} />
                    <DetailItem label="Officer Name" value={caseData.dispatchToCourtOfficerName} />
                    <DetailItem label="Officer Rank" value={caseData.dispatchToCourtOfficerRank} />
                </div>
                <h3 className="text-md font-semibold text-muted-foreground mt-3 mb-2 border-b pb-1">13. Confirmation</h3>
                <div className="space-y-1">
                    <DetailItem label="FIR Read Over & Admitted Correct" value={caseData.confirmationFirReadOverAndAdmitted} isBoolean />
                    <DetailItem label="Copy Given to Complainant" value={caseData.confirmationCopyGivenToComplainant} isBoolean />
                    <DetailItem label="ROAC" value={caseData.confirmationRoac} isBoolean />
                    <DetailItem label="Signature of Complainant" value={caseData.confirmationSignatureOfComplainant} />
                </div>
              </section>
            </CardContent>
          </Card>
        );
      case 'crimeScene':
        if (!caseData) return <Card className="shadow-md"><CardContent><p className="text-muted-foreground p-4">Loading...</p></CardContent></Card>;
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <div className="lg:col-span-3">
                <CrimeDetailsForm 
                    caseData={caseData} 
                    existingCrimeDetails={crimeDetails} 
                    onSaveSuccess={handleCrimeDetailsSaved} 
                />
                </div>
                <div className="lg:col-span-2">
                <EmbeddedCrimeSceneChat 
                    firNumber={caseData.firNumber}
                    caseTitle={caseData.title}
                    caseId={caseData.id!}
                    initialContextText={caseData.complaintStatement}
                />
                </div>
            </div>
            
            <Card className="shadow-lg">
                <CardHeader>
                    <CardTitle className="font-headline text-xl flex items-center"><ImageIcon className="mr-2 h-5 w-5 text-primary"/>Saved Crime Scene Analysis Reports</CardTitle>
                    <CardDescription>View AI-generated analysis reports for this case.</CardDescription>
                </CardHeader>
                <CardContent>
                    {isFetchingMediaAnalyses && <div className="flex items-center justify-center py-4"><Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />Loading reports...</div>}
                    {mediaAnalysesError && <Alert variant="destructive"><AlertTriangle className="h-4 w-4" /><AlertTitle>Error</AlertTitle><AlertDescription>{mediaAnalysesError}</AlertDescription></Alert>}
                    {!isFetchingMediaAnalyses && !mediaAnalysesError && mediaAnalyses.length === 0 && <p className="text-muted-foreground text-center py-4">No crime scene analysis reports found for this case.</p>}
                    {!isFetchingMediaAnalyses && !mediaAnalysesError && mediaAnalyses.length > 0 && (
                        <Accordion type="single" collapsible className="w-full">
                            {mediaAnalyses.map((report, index) => (
                                <AccordionItem value={`report-${report.id || index}`} key={report.id || index}>
                                    <AccordionTrigger className="hover:bg-muted/50 px-3 rounded-md">
                                        <div className="flex items-center gap-2">
                                            <ImageIcon className="h-4 w-4 text-muted-foreground" />
                                            <span>Report for: {report.originalFileName} (Analyzed: {formatDateForDisplay(report.createdAt, 'PP')})</span>
                                        </div>
                                    </AccordionTrigger>
                                    <AccordionContent className="pt-2 pb-4 px-3 space-y-4">
                                        {report.imageDataUri && (
                                            <div className="my-2">
                                                <h4 className="font-semibold text-sm mb-1">Analyzed Image:</h4>
                                                <Image src={report.imageDataUri} alt={`Analyzed scene - ${report.originalFileName}`} width={600} height={400} className="rounded-md border object-contain max-h-96 w-auto" />
                                            </div>
                                        )}
                                        <div className="space-y-1">
                                            <h4 className="font-semibold text-sm">Identified Elements:</h4>
                                            {report.identifiedElements && report.identifiedElements.length > 0 ? (
                                                <ul className="list-disc list-inside pl-4 text-xs space-y-0.5 bg-muted/30 p-2 rounded-md">
                                                    {report.identifiedElements.map((el, i) => <li key={i}><strong>{el.name}</strong> ({el.category}): {el.description} {el.count ? `(Count: ${el.count})` : ''}</li>)}
                                                </ul>
                                            ) : <p className="text-xs text-muted-foreground">No specific elements identified.</p>}
                                        </div>
                                        <div className="space-y-1">
                                            <h4 className="font-semibold text-sm">Scene Narrative:</h4>
                                            <ScrollArea className="h-32 bg-muted/30 p-2 rounded-md"><pre className="text-xs whitespace-pre-wrap">{report.sceneNarrative}</pre></ScrollArea>
                                        </div>
                                        <div className="space-y-1">
                                            <h4 className="font-semibold text-sm">Case File Summary & Hypotheses:</h4>
                                            <ScrollArea className="h-32 bg-muted/30 p-2 rounded-md"><pre className="text-xs whitespace-pre-wrap">{report.caseFileSummary}</pre></ScrollArea>
                                        </div>
                                        {report.userContext && <p className="text-xs text-muted-foreground italic">User Context Provided: {report.userContext}</p>}
                                    </AccordionContent>
                                </AccordionItem>
                            ))}
                        </Accordion>
                    )}
                </CardContent>
            </Card>
          </div>
        );
      case 'investigationProgress': 
        if (!caseData) return <Card className="shadow-md"><CardContent><p className="text-muted-foreground p-4">Loading...</p></CardContent></Card>;
        return (
            <Card className="shadow-xl">
                <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="font-headline text-xl flex items-center"><BookOpen className="mr-2 h-5 w-5 text-primary"/>Case Journal (IO's Diary)</CardTitle>
                <Button size="sm" disabled><PlusCircle className="mr-2 h-4 w-4" /> Add New Journal Entry</Button>
                </CardHeader>
                <CardContent>
                    <CaseTimeline entries={journalEntries} isLoadingJournal={isLoadingJournal} journalError={journalError} /> 
                    <p className="mt-4 text-muted-foreground">
                      {stageConfig.description} (Sections like Witness Examinations, Medical Reports, and Arrests will be added here, and their actions will also be logged to this journal.)
                    </p>
                </CardContent>
            </Card>
        );
      default: 
        if (!caseData) return <Card className="shadow-md"><CardContent><p className="text-muted-foreground p-4">Loading...</p></CardContent></Card>;
        return (
          <Card className="shadow-md">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="font-headline text-xl flex items-center">
                <stageConfig.icon className="mr-2 h-5 w-5 text-primary"/>
                {stageConfig.title}
              </CardTitle>
              <Button variant="outline" size="sm" disabled><Edit className="mr-2 h-4 w-4" /> Edit {stageConfig.title}</Button>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{stageConfig.description} (Coming Soon)</p>
              <p className="text-sm mt-2 text-muted-foreground">Detailed forms and data for {stageConfig.title.toLowerCase()} will be managed here. Actions taken will be logged to the Case Journal.</p>
            </CardContent>
          </Card>
        );
    }
  };

  if (isLoading && !caseData) { 
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-muted-foreground">Loading case details...</p>
      </div>
    );
  }

  if (error || (!isLoading && !caseData && caseId)) { 
    return (
      <div className="text-center py-10">
        <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-destructive">{error || 'Case Not Found'}</h1>
        <p className="text-muted-foreground">The case you are looking for does not exist or there was an error loading it.</p>
        <Button variant="outline" onClick={() => router.push('/cases')} className="mt-4">
          Back to All Cases
        </Button>
      </div>
    );
  }
  

  if (!caseData) { 
      if (isLoading) { 
          return (
              <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
                <p className="ml-4 text-muted-foreground">Loading case details...</p>
              </div>
            );
      }
      return (
        <div className="text-center py-10">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-destructive">Case Data Unavailable</h1>
          <p className="text-muted-foreground">The requested case data could not be loaded.</p>
          <Button variant="outline" onClick={() => router.push('/cases')} className="mt-4">
            Back to All Cases
          </Button>
        </div>
      );
  }


  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-4 sticky top-0 bg-background/95 backdrop-blur-sm py-3 z-10 -mx-4 px-4 border-b md:hidden">
         <Button variant="outline" size="icon" onClick={() => router.back()} className="md:hidden">
            <ArrowLeft className="h-5 w-5" />
         </Button>
         <h1 className="text-lg font-semibold truncate flex-1 mx-2 md:hidden">{caseData.title}</h1>
         <Button variant="ghost" size="icon" className="md:hidden" disabled><GripVertical className="h-5 w-5" /></Button> 
      </div>

      <div className="hidden md:flex items-center justify-between mb-4">
        <Button variant="outline" size="sm" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to All Cases
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled><Edit className="mr-2 h-4 w-4" /> Edit Overall Status</Button>
          <Button variant="outline" size="sm" disabled><Printer className="mr-2 h-4 w-4" /> Print Summary</Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6 flex-1">
        <div className="w-full md:w-[280px] lg:w-[320px] space-y-3 md:sticky md:top-[calc(var(--header-height,4rem)+1rem)] md:self-start md:max-h-[calc(100vh-var(--header-height,4rem)-2rem)] md:overflow-y-auto pb-4 md:pr-2">
            <Card className="shadow-sm mb-4">
                <CardHeader className="p-3 sm:p-4">
                    <div className="flex items-center justify-between mb-1">
                        <CardTitle className="text-lg font-headline leading-tight truncate" title={caseData.title}>
                            {caseData.title}
                        </CardTitle>
                        <Badge className={`${statusColors[caseData.status]} text-white text-xs px-2 py-0.5`}>{caseData.status}</Badge>
                    </div>
                    <CardDescription className="text-xs text-muted-foreground">
                        FIR No: {caseData.firNumber} | Filed: {formatDateForDisplay(caseData.dateFiled, 'PPP')}
                    </CardDescription>
                    {caseData.originalComplaintId && (
                        <p className="text-xs text-muted-foreground mt-1">
                            From Complaint: {' '}
                            <Link href={`/complaints?highlight=${caseData.originalComplaintId}`} className="text-primary hover:underline">
                                {caseData.originalComplaintId}
                            </Link>
                        </p>
                    )}
                </CardHeader>
            </Card>

            <nav className="space-y-1">
                {caseStagesConfig.map((stage, index) => (
                    <Button
                        key={stage.id}
                        variant={activeStageId === stage.id ? "default" : "ghost"}
                        className={cn(
                            "w-full justify-start items-center text-sm h-auto py-2.5 px-3 group",
                            activeStageId === stage.id ? `${stage.color} text-primary-foreground ${stage.hoverColor} shadow-md` : "hover:bg-accent hover:text-accent-foreground"
                        )}
                        onClick={() => setActiveStageId(stage.id)}
                    >
                        <div className={cn(
                            "flex items-center justify-center w-6 h-6 rounded-full text-xs font-semibold mr-3 shrink-0",
                            activeStageId === stage.id ? "bg-primary-foreground text-primary" : `bg-muted ${stage.textColor}`
                        )}>
                            {index + 1}
                        </div>
                        <stage.icon className={cn(
                            "h-4 w-4 mr-2 shrink-0",
                            activeStageId === stage.id ? "text-primary-foreground" : stage.textColor
                        )} />
                        <span className="truncate">{stage.title}</span>
                    </Button>
                ))}
            </nav>
        </div>

        <div className="flex-1 min-w-0">
          <ScrollArea className="h-full pr-1">
            {renderStageContent()}
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}
