
"use client";

import { useState, useEffect, Suspense, useCallback } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, FilePlus2, AlertTriangle, PlusCircle, Trash2, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { doc, getDoc, addDoc, collection, Timestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { extractFirDetailsFromTranscript, type ExtractFirDetailsInput, type ExtractFirDetailsOutput } from '@/ai/flows/extract-fir-details';
import type { SavedComplaint, CaseDoc, TranscriptMessage, AccusedDetail } from '@/types';
import { CaseStatus } from '@/types';
import { differenceInYears } from 'date-fns';
import { useAuth } from '@/hooks/useAuth';

const initialAccusedDetail: AccusedDetail = {
    serialNo: '1', 
    name: '',
    fatherHusbandName: '',
    caste: '',
    nationality: 'Indian',
    occupation: '',
    age: '',
    gender: '',
    address: { houseNo: '', streetVillage: '', areaMandal: '', cityDistrict: '', state: '', pin: '' },
    phoneOffice: '',
    phoneResidence: '',
    cellNo: '',
    email: '',
    physicalFeatures: { build: '', heightCms: '', complexion: '', deformitiesPeculiarities: '', teeth: '', hair: '', eyes: '', habits: '', dressHabits: '', languagesDialect: ''},
    identificationMarks: { mole: false, scar: false, tattoo: false, leucoderma: false, burnMark: false }
};

const localStorageKey = 'nyayasahayak_fir_draft';

function NewCasePageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const { user } = useAuth();

  const initialFormData: Partial<CaseDoc> = {
    status: CaseStatus.New,
    accusedDetails: [{ ...initialAccusedDetail }], 
    district: '',
    policeStation: '',
    typeOfInformation: '',
    complainantGender: '',
    victimGender: '',
    year: new Date().getFullYear().toString(),
    confirmationFirReadOverAndAdmitted: true,
    confirmationCopyGivenToComplainant: true,
    confirmationRoac: true,
    occurrencePlace: { latitude: null, longitude: null }
  };

  const [formData, setFormData] = useState<Partial<CaseDoc>>(initialFormData);
  const [originalComplaintId, setOriginalComplaintId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isPrefilling, setIsPrefilling] = useState(true); 
  const [isComplainantVictim, setIsComplainantVictim] = useState(false);
  const [hasInitialized, setHasInitialized] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  const handleCheckboxChange = (name: string, checked: boolean) => {
    if (name.includes('.')) {
        handleNestedInputChange(name, checked, 'checkbox');
    } else {
        setFormData(prev => ({ ...prev, [name]: checked }));
    }
  };

  const handleNestedInputChange = useCallback((path: string, value: any, type?: string) => {
    if (typeof path !== 'string' || !path) {
      console.error('handleNestedInputChange called with invalid path:', path, 'value:', value);
      toast({
        variant: "destructive",
        title: "Internal Form Error",
        description: "A problem occurred with form data handling. Please check console.",
      });
      return; 
    }
    setFormData(prev => {
        const keys = path.split('.');
        let newFormData = JSON.parse(JSON.stringify(prev)); 
        let current: any = newFormData;

        for (let i = 0; i < keys.length - 1; i++) {
            const key = keys[i];
            let arrayMatch = key.match(/(\w+)\[(\d+)\]/);

            if (arrayMatch) {
                const arrayKey = arrayMatch[1];
                const index = parseInt(arrayMatch[2]);
                if (!current[arrayKey]) current[arrayKey] = [];
                while(current[arrayKey].length <= index) {
                     const newAccused = JSON.parse(JSON.stringify(initialAccusedDetail));
                     newAccused.serialNo = (current[arrayKey].length + 1).toString();
                     current[arrayKey].push(newAccused);
                }
                current = current[arrayKey][index];
            } else {
                if (!current[key] || typeof current[key] !== 'object') current[key] = {};
                current = current[key];
            }
        }
        
        const finalKey = keys[keys.length - 1];
        let finalValue = value;

        if (type === 'checkbox') {
          finalValue = !!value; 
        } else if (type === 'number') {
          finalValue = value === '' ? null : Number(value); 
        } else if (type === 'date' || type === 'datetime-local') {
            finalValue = value === '' ? '' : value;
        }
        
        if (path === 'district') {
            current.district = finalValue;
            current.policeStation = ''; 
        } else {
            current[finalKey] = finalValue;
        }
        
        return newFormData;
    });
  }, [toast]); 

  useEffect(() => {
    const complaintId = searchParams.get('complaintId');
    if (complaintId) {
      setOriginalComplaintId(complaintId);
      const fetchComplaintAndPrefill = async () => {
        setIsPrefilling(true); 
        try {
          const complaintRef = doc(db, 'complaints', complaintId);
          const complaintSnap = await getDoc(complaintRef);

          if (complaintSnap.exists()) {
            const complaintData = complaintSnap.data() as SavedComplaint;
            const transcriptText = complaintData.transcript
              ?.map((msg: TranscriptMessage) => `${msg.sender === 'user' ? 'User' : 'AI Assistant'}: ${msg.text}`)
              .join('\n\n') || '';
            
            if (transcriptText) {
              const extractInput: ExtractFirDetailsInput = { complaintTranscript: transcriptText, language: 'en' };
              toast({ title: "AI Processing", description: "Extracting details and drafting complaint for FIR prefill..." });
              const extractedOutput: ExtractFirDetailsOutput = await extractFirDetailsFromTranscript(extractInput);
              
              setFormData(prev => {
                const newFormData = { ...prev, ...initialFormData }; 

                newFormData.title = extractedOutput.title || `Case from Complaint ${complaintId}`;
                newFormData.complainantName = extractedOutput.complainantName || '';
                newFormData.complainantGender = extractedOutput.complainantGender === 'Unknown' ? '' : extractedOutput.complainantGender || '';
                newFormData.complainantAge = extractedOutput.complainantAge || '';
                newFormData.complainantFatherHusbandName = extractedOutput.complainantFatherHusbandName || '';
                if (extractedOutput.complainantAddress_streetVillage || extractedOutput.complainantAddress_cityDistrict) {
                    newFormData.complainantAddress = {
                        ...(newFormData.complainantAddress || {}),
                        streetVillage: extractedOutput.complainantAddress_streetVillage || '',
                        cityDistrict: extractedOutput.complainantAddress_cityDistrict || '',
                    };
                }
                newFormData.complainantMobileNumber = extractedOutput.complainantMobileNumber || '';
                
                if (extractedOutput.occurrenceDateTimeFrom) {
                    if (extractedOutput.occurrenceDateTimeFrom.includes('T')) {
                        newFormData.occurrenceDateTimeFrom = extractedOutput.occurrenceDateTimeFrom.substring(0, 16); 
                    } else if (extractedOutput.occurrenceDateTimeFrom.match(/^\d{4}-\d{2}-\d{2}$/)) {
                        newFormData.occurrenceDateTimeFrom = `${extractedOutput.occurrenceDateTimeFrom}T00:00`;
                    } else {
                       newFormData.occurrenceDateTimeFrom = '';
                    }
                } else {
                    newFormData.occurrenceDateTimeFrom = prev.occurrenceDateTimeFrom || new Date().toISOString().substring(0,16);
                }
                
                newFormData.occurrenceDay = extractedOutput.occurrenceDay || '';

                if (extractedOutput.occurrencePlace_streetVillage || extractedOutput.occurrencePlace_areaMandal || extractedOutput.occurrencePlace_cityDistrict) {
                   newFormData.occurrencePlace = {
                     ...(newFormData.occurrencePlace || initialFormData.occurrencePlace), 
                     streetVillage: extractedOutput.occurrencePlace_streetVillage || '',
                     areaMandal: extractedOutput.occurrencePlace_areaMandal || '',
                     cityDistrict: extractedOutput.occurrencePlace_cityDistrict || '',
                   };
                }
                
                newFormData.complaintStatement = extractedOutput.complaintStatement || transcriptText; 
                
                if (extractedOutput.accusedName) {
                  newFormData.accusedDetails = [{ 
                    ...initialAccusedDetail, 
                    name: extractedOutput.accusedName || '',
                    gender: extractedOutput.accusedGender === 'Unknown' ? '' : extractedOutput.accusedGender || '',
                    age: extractedOutput.accusedAge || '',
                    address: {
                        ...(initialAccusedDetail.address || {}),
                        streetVillage: extractedOutput.accusedAddress_streetVillage || '',
                    }
                  }];
                } else {
                  newFormData.accusedDetails = [{ ...initialAccusedDetail }];
                }

                newFormData.victimName = extractedOutput.victimName || '';
                newFormData.victimGender = extractedOutput.victimGender === 'Unknown' ? '' : extractedOutput.victimGender || '';
                newFormData.victimAge = extractedOutput.victimAge || '';

                newFormData.propertiesInvolvedDetails = extractedOutput.propertiesInvolvedDetails || '';
                newFormData.propertiesTotalValueStolen = extractedOutput.propertiesTotalValueStolen || '';
                newFormData.actsAndSectionsInvolved = extractedOutput.actsAndSectionsInvolved || '';
                newFormData.typeOfInformation = extractedOutput.typeOfInformation === 'Unknown' ? '' : extractedOutput.typeOfInformation || '';
                
                newFormData.year = newFormData.year || new Date().getFullYear().toString();
                newFormData.date = newFormData.date || new Date().toISOString().split('T')[0];

                return newFormData;
              });
              toast({ title: "FIR Details Extracted", description: "Form prefilled with AI suggestions. Please review and complete all fields." });
            } else {
              setFormData(prev => ({
                ...prev,
                ...initialFormData,
                title: `Case from Complaint ${complaintId} (no transcript text found)`,
              }));
              toast({ variant: "warning", title: "Prefill Warning", description: "Complaint transcript was empty. Please fill FIR manually." });
            }
          } else {
            toast({ variant: "destructive", title: "Prefill Error", description: `Complaint with ID ${complaintId} not found.` });
            setFormData(initialFormData); 
          }
        } catch (error) {
          console.error("Error fetching complaint or prefilling FIR:", error);
          toast({ variant: "destructive", title: "AI Prefill Error", description: "Could not extract details from complaint for FIR." });
          setFormData(initialFormData); 
        } finally {
          setIsPrefilling(false);
          setHasInitialized(true);
        }
      };
      fetchComplaintAndPrefill();
    } else { 
      try {
        const cachedDataString = localStorage.getItem(localStorageKey);
        if (cachedDataString) {
          const parsedData = JSON.parse(cachedDataString);
          if (!parsedData.accusedDetails || parsedData.accusedDetails.length === 0) {
            parsedData.accusedDetails = [{ ...initialAccusedDetail }];
          }
          if (parsedData.occurrencePlace) {
            parsedData.occurrencePlace.latitude = parsedData.occurrencePlace.latitude != null ? Number(parsedData.occurrencePlace.latitude) : null;
            parsedData.occurrencePlace.longitude = parsedData.occurrencePlace.longitude != null ? Number(parsedData.occurrencePlace.longitude) : null;
          } else {
            parsedData.occurrencePlace = { latitude: null, longitude: null };
          }
          setFormData(parsedData);
          toast({ title: "Draft Restored", description: "Your previous FIR draft has been loaded." });
        } else {
          setFormData(initialFormData); 
        }
      } catch (error) {
        console.error("Error loading FIR draft from localStorage:", error);
        setFormData(initialFormData); 
      } finally {
        setIsPrefilling(false);
        setHasInitialized(true);
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, toast]); 


  useEffect(() => {
    if (hasInitialized && !isPrefilling) {
      try {
        localStorage.setItem(localStorageKey, JSON.stringify(formData));
      } catch (error) {
        console.error("Error saving FIR draft to localStorage:", error);
      }
    }
  }, [formData, hasInitialized, isPrefilling]);

  useEffect(() => {
    if (formData.complainantDateOfBirth) {
      try {
        const dob = new Date(formData.complainantDateOfBirth);
        if (!isNaN(dob.getTime())) {
          const age = differenceInYears(new Date(), dob);
          if (age >= 0) {
            handleNestedInputChange('complainantAge', age.toString());
          } else {
            handleNestedInputChange('complainantAge', '');
          }
        } else {
           handleNestedInputChange('complainantAge', '');
        }
      } catch (error) {
        handleNestedInputChange('complainantAge', '');
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formData.complainantDateOfBirth]); 

  useEffect(() => {
    if (formData.victimDob) {
      try {
        const dob = new Date(formData.victimDob);
         if (!isNaN(dob.getTime())) {
            const age = differenceInYears(new Date(), dob);
            if (age >= 0) {
                handleNestedInputChange('victimAge', age.toString());
            } else {
                handleNestedInputChange('victimAge', '');
            }
        } else {
            handleNestedInputChange('victimAge', '');
        }
      } catch (error) {
        handleNestedInputChange('victimAge', '');
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formData.victimDob]); 


  useEffect(() => {
    if (isComplainantVictim) {
      const {
        complainantName, complainantFatherHusbandName, complainantGender,
        complainantNationality, complainantCaste, complainantOccupation,
        complainantDateOfBirth, complainantAge, complainantAddress
      } = formData;

      handleNestedInputChange('victimName', complainantName || '');
      handleNestedInputChange('victimFatherHusbandName', complainantFatherHusbandName || '');
      handleNestedInputChange('victimGender', complainantGender || '');
      handleNestedInputChange('victimNationality', complainantNationality || 'Indian');
      handleNestedInputChange('victimCaste', complainantCaste || '');
      handleNestedInputChange('victimOccupation', complainantOccupation || '');
      handleNestedInputChange('victimDob', complainantDateOfBirth || '');
      handleNestedInputChange('victimAge', complainantAge || '');
      if (complainantAddress) {
        Object.keys(complainantAddress).forEach(key => {
          handleNestedInputChange(`victimAddress.${key}`, (complainantAddress as any)[key] || '');
        });
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ 
    isComplainantVictim,
    formData.complainantName,
    formData.complainantFatherHusbandName,
    formData.complainantGender,
    formData.complainantNationality,
    formData.complainantCaste,
    formData.complainantOccupation,
    formData.complainantDateOfBirth,
    formData.complainantAge,
    formData.complainantAddress?.houseNo,
    formData.complainantAddress?.streetVillage,
    formData.complainantAddress?.areaMandal,
    formData.complainantAddress?.cityDistrict,
    formData.complainantAddress?.state,
    formData.complainantAddress?.pin
  ]);


  const addAccused = () => {
    setFormData(prev => ({
      ...prev,
      accusedDetails: [
        ...(prev.accusedDetails || []),
        { ...JSON.parse(JSON.stringify(initialAccusedDetail)), serialNo: ((prev.accusedDetails?.length || 0) + 1).toString() }
      ]
    }));
  };

  const removeAccused = (index: number) => {
    setFormData(prev => {
        const updatedAccusedDetails = prev.accusedDetails?.filter((_, i) => i !== index)
                                 .map((acc, newIdx) => ({ ...acc, serialNo: (newIdx + 1).toString() }));
        return { ...prev, accusedDetails: updatedAccusedDetails };
    });
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({ variant: "destructive", title: "Not Authenticated", description: "Please log in to register an FIR." });
      return;
    }
    if (!formData.firNumber?.trim() || !formData.title?.trim() || !formData.district?.trim() || !formData.policeStation?.trim() || !formData.year?.trim() || !formData.date?.trim() || !formData.complaintStatement?.trim()) {
      toast({ variant: "destructive", title: "Missing Required Fields", description: "Please fill in all fields marked with (*)." });
      return;
    }
    setIsLoading(true);

    const caseToSave: CaseDoc = {
      ...initialFormData, 
      ...formData,
      userId: user.uid,
      originalComplaintId: originalComplaintId || undefined,
      status: formData.status || CaseStatus.New,
      dateFiled: Timestamp.now(),
      lastUpdated: Timestamp.now(),
      firNumber: formData.firNumber, 
      title: formData.title,
      district: formData.district,
      policeStation: formData.policeStation,
      year: formData.year,
      date: formData.date,
      complaintStatement: formData.complaintStatement,
      accusedDetails: formData.accusedDetails && formData.accusedDetails.length > 0 
        ? formData.accusedDetails.map(acc => ({...initialAccusedDetail, ...acc})) 
        : [],
      occurrencePlace: {
        ...(initialFormData.occurrencePlace || {}),
        ...(formData.occurrencePlace || {}),
        latitude: formData.occurrencePlace?.latitude !== undefined && formData.occurrencePlace?.latitude !== null ? Number(formData.occurrencePlace.latitude) : null,
        longitude: formData.occurrencePlace?.longitude !== undefined && formData.occurrencePlace?.longitude !== null ? Number(formData.occurrencePlace.longitude) : null,
      }
    } as CaseDoc; 

    try {
      const docRef = await addDoc(collection(db, 'cases'), caseToSave);
      toast({ title: "FIR Registered", description: `New case created with ID: ${docRef.id}` });
      localStorage.removeItem(localStorageKey); 
      router.push(`/cases/${docRef.id}`); 
    } catch (error) {
      console.error("Error registering FIR:", error);
      toast({ variant: "destructive", title: "Registration Failed", description: "Could not save the new FIR." });
    } finally {
      setIsLoading(false);
    }
  };
  
  if (isPrefilling && !hasInitialized) { 
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-muted-foreground">Loading form data...</p>
      </div>
    );
  }

  const districtOptions = ["District A", "District B", "Eluru", "Another District"];
  const eluruPoliceStations = [
    "Eluru I Town", "Eluru II Town", "Eluru III Town", "Eluru Rural", "Women Eluru", "Traffic Eluru",
    "Denduluru", "Pedavegi", "Polavaram", "Koyyalagudem", "Chintalapudi", "Jeelugumilli",
    "Nuzvid Rural", "Nuzvid Town", "Kaikaluru Rural", "Kaikaluru Town", "Kalidindi", "Mandavalli",
    "Mudinepalli", "Ganapavaram", "Chebrole", "Dwaraka Tirumala", "Lakkavaram", "Tadikala Pudi",
    "Nidamarru", "Buttaigudem", "Agiripalli", "Musunur", "Chatrai", "T Narasapuram",
    "Dharmajigudem", "Kukunoor", "Velairpad", "Special Branch Eluru", "CCS Eluru"
  ];

  const policeStationOptions: { [key: string]: string[] } = {
    "District A": ["PS A1", "PS A2"],
    "District B": ["PS B1", "PS B2"],
    "Eluru": eluruPoliceStations,
    "Another District": ["PS C1"],
    "": [] 
  };
  const genderOptions = ["Male", "Female", "Other"];
  const typeOfInformationOptions = ["Written", "Oral"];


  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center">
            <FilePlus2 className="mr-2 h-6 w-6" /> Register New FIR/Case
          </CardTitle>
          <CardDescription>
            {originalComplaintId 
              ? `Fill in the details for the new FIR, partially pre-filled using AI from complaint ${originalComplaintId}. Please review all fields carefully.`
              : "Fill in the details for the new FIR/Case. Your progress is saved automatically."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          
          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">1. District & FIR Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div><Label htmlFor="title">Case Title <span className="text-destructive">*</span></Label><Input id="title" name="title" value={formData.title || ''} onChange={handleInputChange} placeholder="E.g., Theft at City Mall" required /></div>
              
              <div><Label htmlFor="district">District <span className="text-destructive">*</span></Label>
                <Select name="district" value={formData.district || ''} onValueChange={(value) => handleNestedInputChange("district", value)} required>
                    <SelectTrigger id="district"><SelectValue placeholder="Select District" /></SelectTrigger>
                    <SelectContent>
                        {districtOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                </Select>
              </div>
              <div><Label htmlFor="policeStation">Police Station <span className="text-destructive">*</span></Label>
                <Select name="policeStation" value={formData.policeStation || ''} onValueChange={(value) => handleNestedInputChange("policeStation", value)} required disabled={!formData.district}>
                    <SelectTrigger id="policeStation"><SelectValue placeholder="Select Police Station" /></SelectTrigger>
                    <SelectContent>
                        {(policeStationOptions[formData.district || ''] || []).map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                </Select>
              </div>

              <div><Label htmlFor="year">Year <span className="text-destructive">*</span></Label><Input id="year" name="year" value={formData.year || ''} onChange={handleInputChange} placeholder="YYYY" required /></div>
              <div><Label htmlFor="firNumber">FIR Number <span className="text-destructive">*</span></Label><Input id="firNumber" name="firNumber" value={formData.firNumber || ''} onChange={handleInputChange} placeholder="E.g., 126/2021" required /></div>
              <div><Label htmlFor="date">FIR Registration Date <span className="text-destructive">*</span></Label><Input id="date" name="date" type="date" value={formData.date || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'date')} required /></div>
            </div>
          </div>

          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">2. Occurrence of Offence</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div><Label htmlFor="occurrenceDay">Day of Occurrence</Label><Input id="occurrenceDay" name="occurrenceDay" value={formData.occurrenceDay || ''} onChange={handleInputChange} placeholder="E.g., Monday" /></div>
              <div><Label htmlFor="occurrenceDateTimeFrom">Date/Time From</Label><Input id="occurrenceDateTimeFrom" name="occurrenceDateTimeFrom" type="datetime-local" value={formData.occurrenceDateTimeFrom || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'datetime-local')}/></div>
              <div><Label htmlFor="occurrenceDateTimeTo">Date/Time To</Label><Input id="occurrenceDateTimeTo" name="occurrenceDateTimeTo" type="datetime-local" value={formData.occurrenceDateTimeTo || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'datetime-local')} /></div>
              <div className="lg:col-span-1"><Label htmlFor="occurrenceTimePeriod">Time Period</Label><Input id="occurrenceTimePeriod" name="occurrenceTimePeriod" value={formData.occurrenceTimePeriod || ''} onChange={handleInputChange} placeholder="E.g., 19:15-21:30" /></div>
              <div className="lg:col-span-2"><Label htmlFor="occurrencePriorToDateTime">Prior to Date/Time (Details)</Label><Input id="occurrencePriorToDateTime" name="occurrencePriorToDateTime" value={formData.occurrencePriorToDateTime || ''} onChange={handleInputChange} /></div>
              
              <div><Label htmlFor="occurrenceBeatNumber">Beat Number</Label><Input id="occurrenceBeatNumber" name="occurrenceBeatNumber" value={formData.occurrenceBeatNumber || ''} onChange={handleInputChange} /></div>
            </div>
            <h4 className="text-md font-medium mt-4 mb-2">Place of Occurrence:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div><Label htmlFor="occurrencePlace.streetVillage">Street/Village</Label><Input id="occurrencePlace.streetVillage" name="occurrencePlace.streetVillage" value={formData.occurrencePlace?.streetVillage || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="occurrencePlace.areaMandal">Area/Mandal</Label><Input id="occurrencePlace.areaMandal" name="occurrencePlace.areaMandal" value={formData.occurrencePlace?.areaMandal || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="occurrencePlace.cityDistrict">City/District</Label><Input id="occurrencePlace.cityDistrict" name="occurrencePlace.cityDistrict" value={formData.occurrencePlace?.cityDistrict || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="occurrencePlace.state">State</Label><Input id="occurrencePlace.state" name="occurrencePlace.state" value={formData.occurrencePlace?.state || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="occurrencePlace.pin">PIN</Label><Input id="occurrencePlace.pin" name="occurrencePlace.pin" value={formData.occurrencePlace?.pin || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3 items-end">
                <div><Label htmlFor="occurrencePlace.latitude">Latitude</Label><Input id="occurrencePlace.latitude" name="occurrencePlace.latitude" type="number" step="any" value={formData.occurrencePlace?.latitude ?? ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'number')} placeholder="e.g., 16.5062" /></div>
                <div><Label htmlFor="occurrencePlace.longitude">Longitude</Label><Input id="occurrencePlace.longitude" name="occurrencePlace.longitude" type="number" step="any" value={formData.occurrencePlace?.longitude ?? ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'number')} placeholder="e.g., 80.6480" /></div>
                <Button type="button" variant="outline" disabled className="h-10"><MapPin className="mr-2 h-4 w-4" />Pick on Map (Placeholder)</Button>
            </div>


            <h4 className="text-md font-medium mt-4 mb-2">Distance & Direction from PS:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label htmlFor="occurrenceDistanceDirectionFromPS.distance">Distance from PS</Label><Input id="occurrenceDistanceDirectionFromPS.distance" name="occurrenceDistanceDirectionFromPS.distance" value={formData.occurrenceDistanceDirectionFromPS?.distance || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} placeholder="E.g., 1km" /></div>
              <div><Label htmlFor="occurrenceDistanceDirectionFromPS.direction">Direction from PS</Label><Input id="occurrenceDistanceDirectionFromPS.direction" name="occurrenceDistanceDirectionFromPS.direction" value={formData.occurrenceDistanceDirectionFromPS?.direction || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} placeholder="E.g., East" /></div>
            </div>
             <h4 className="text-md font-medium mt-4 mb-2">Outside Jurisdiction:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                <div className="flex items-center space-x-2">
                    <Checkbox id="occurrenceOutsideJurisdiction.isOutside" name="occurrenceOutsideJurisdiction.isOutside" checked={formData.occurrenceOutsideJurisdiction?.isOutside || false} onCheckedChange={(checked) => handleCheckboxChange("occurrenceOutsideJurisdiction.isOutside", !!checked)} />
                    <Label htmlFor="occurrenceOutsideJurisdiction.isOutside">Is Outside Jurisdiction?</Label>
                </div>
                {formData.occurrenceOutsideJurisdiction?.isOutside && (
                    <div><Label htmlFor="occurrenceOutsideJurisdiction.policeStationName">If so, PS Name</Label><Input id="occurrenceOutsideJurisdiction.policeStationName" name="occurrenceOutsideJurisdiction.policeStationName" value={formData.occurrenceOutsideJurisdiction?.policeStationName || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                )}
            </div>
          </div>

          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">3. Information Received</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><Label htmlFor="infoReceivedDateTime">Date/Time Received at PS</Label><Input id="infoReceivedDateTime" name="infoReceivedDateTime" type="datetime-local" value={formData.infoReceivedDateTime || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'datetime-local')} /></div>
                <div><Label htmlFor="infoReceivedEntryNumber">General Diary Entry No.</Label><Input id="infoReceivedEntryNumber" name="infoReceivedEntryNumber" value={formData.infoReceivedEntryNumber || ''} onChange={handleInputChange} placeholder="E.g., 40" /></div>
            </div>
            <h3 className="text-lg font-semibold text-primary mt-4 mb-3">4. Type of Information</h3>
            <div>
                <Label htmlFor="typeOfInformation">Type</Label>
                <Select name="typeOfInformation" value={formData.typeOfInformation || ''} onValueChange={(value) => handleNestedInputChange("typeOfInformation", value)}>
                    <SelectTrigger id="typeOfInformation"><SelectValue placeholder="Select type" /></SelectTrigger>
                    <SelectContent>
                    {typeOfInformationOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
          </div>
          
          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">5. Complainant / Informant Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div><Label htmlFor="complainantName">Name</Label><Input id="complainantName" name="complainantName" value={formData.complainantName || ''} onChange={handleInputChange} /></div>
              <div><Label htmlFor="complainantFatherHusbandName">Father's/Husband's Name</Label><Input id="complainantFatherHusbandName" name="complainantFatherHusbandName" value={formData.complainantFatherHusbandName || ''} onChange={handleInputChange} /></div>
              <div><Label htmlFor="complainantGender">Gender</Label>
                <Select name="complainantGender" value={formData.complainantGender || ''} onValueChange={(value) => handleNestedInputChange("complainantGender", value)}>
                    <SelectTrigger><SelectValue placeholder="Select Gender" /></SelectTrigger>
                    <SelectContent>{genderOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label htmlFor="complainantNationality">Nationality</Label><Input id="complainantNationality" name="complainantNationality" value={formData.complainantNationality || 'Indian'} onChange={handleInputChange} /></div>
              <div><Label htmlFor="complainantCaste">Caste</Label><Input id="complainantCaste" name="complainantCaste" value={formData.complainantCaste || ''} onChange={handleInputChange} /></div>
              <div><Label htmlFor="complainantOccupation">Occupation</Label><Input id="complainantOccupation" name="complainantOccupation" value={formData.complainantOccupation || ''} onChange={handleInputChange} /></div>
              <div><Label htmlFor="complainantDateOfBirth">Date of Birth</Label><Input id="complainantDateOfBirth" name="complainantDateOfBirth" type="date" value={formData.complainantDateOfBirth || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'date')} /></div>
              <div><Label htmlFor="complainantAge">Age (auto-calculated)</Label><Input id="complainantAge" name="complainantAge" value={formData.complainantAge || ''} readOnly disabled={!!formData.complainantDateOfBirth} /></div>
              <div><Label htmlFor="complainantMobileNumber">Mobile Number</Label><Input id="complainantMobileNumber" name="complainantMobileNumber" value={formData.complainantMobileNumber || ''} onChange={handleInputChange} placeholder="10 digits" /></div>
            </div>
            <h4 className="text-md font-medium mt-4 mb-2">Complainant Address:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div><Label htmlFor="complainantAddress.houseNo">House No.</Label><Input id="complainantAddress.houseNo" name="complainantAddress.houseNo" value={formData.complainantAddress?.houseNo || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="complainantAddress.streetVillage">Street/Village</Label><Input id="complainantAddress.streetVillage" name="complainantAddress.streetVillage" value={formData.complainantAddress?.streetVillage || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="complainantAddress.areaMandal">Area/Mandal</Label><Input id="complainantAddress.areaMandal" name="complainantAddress.areaMandal" value={formData.complainantAddress?.areaMandal || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="complainantAddress.cityDistrict">City/District</Label><Input id="complainantAddress.cityDistrict" name="complainantAddress.cityDistrict" value={formData.complainantAddress?.cityDistrict || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="complainantAddress.state">State</Label><Input id="complainantAddress.state" name="complainantAddress.state" value={formData.complainantAddress?.state || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
              <div><Label htmlFor="complainantAddress.pin">PIN</Label><Input id="complainantAddress.pin" name="complainantAddress.pin" value={formData.complainantAddress?.pin || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
            </div>
             <h4 className="text-md font-medium mt-4 mb-2">Complainant Passport (Optional):</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div><Label htmlFor="complainantPassportNumber">Passport No.</Label><Input id="complainantPassportNumber" name="complainantPassportNumber" value={formData.complainantPassportNumber || ''} onChange={handleInputChange} /></div>
                <div><Label htmlFor="complainantPassportPlaceOfIssue">Place of Issue</Label><Input id="complainantPassportPlaceOfIssue" name="complainantPassportPlaceOfIssue" value={formData.complainantPassportPlaceOfIssue || ''} onChange={handleInputChange} /></div>
                <div><Label htmlFor="complainantPassportDateOfIssue">Date of Issue</Label><Input id="complainantPassportDateOfIssue" name="complainantPassportDateOfIssue" type="date" value={formData.complainantPassportDateOfIssue || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'date')} /></div>
            </div>
          </div>

            <div className="border-b pb-6 mb-6">
                <div className="flex justify-between items-center mb-3">
                    <h3 className="text-lg font-semibold text-primary">6. Accused Details</h3>
                    <Button type="button" variant="outline" size="sm" onClick={addAccused}><PlusCircle className="mr-2 h-4 w-4" />Add Accused</Button>
                </div>
                {formData.accusedDetails?.map((accused, index) => (
                    <div key={index} className="border p-4 rounded-md mb-4 relative">
                        <h4 className="text-md font-medium mb-3">Accused {index + 1}</h4>
                        {formData.accusedDetails && formData.accusedDetails.length > 0 && ( 
                            <Button type="button" variant="ghost" size="icon" className="absolute top-2 right-2 text-destructive hover:bg-destructive/10" onClick={() => removeAccused(index)}>
                                <Trash2 className="h-4 w-4" />
                            </Button>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div><Label htmlFor={`accusedDetails[${index}].serialNo`}>Serial No.</Label><Input name={`accusedDetails[${index}].serialNo`} value={accused.serialNo || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} disabled/></div>
                            <div><Label htmlFor={`accusedDetails[${index}].name`}>Name</Label><Input name={`accusedDetails[${index}].name`} value={accused.name || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].fatherHusbandName`}>Father's/Husband's Name</Label><Input name={`accusedDetails[${index}].fatherHusbandName`} value={accused.fatherHusbandName || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].gender`}>Gender</Label>
                                <Select name={`accusedDetails[${index}].gender`} value={accused.gender || ''} onValueChange={(value) => handleNestedInputChange(`accusedDetails[${index}].gender`, value)}>
                                    <SelectTrigger><SelectValue placeholder="Select Gender" /></SelectTrigger>
                                    <SelectContent>{genderOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                                </Select>
                            </div>
                            <div><Label htmlFor={`accusedDetails[${index}].age`}>Age</Label><Input name={`accusedDetails[${index}].age`} value={accused.age || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                             <div><Label htmlFor={`accusedDetails[${index}].nationality`}>Nationality</Label><Input name={`accusedDetails[${index}].nationality`} value={accused.nationality || 'Indian'} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                             <div><Label htmlFor={`accusedDetails[${index}].caste`}>Caste</Label><Input name={`accusedDetails[${index}].caste`} value={accused.caste || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                             <div><Label htmlFor={`accusedDetails[${index}].occupation`}>Occupation</Label><Input name={`accusedDetails[${index}].occupation`} value={accused.occupation || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                             <div><Label htmlFor={`accusedDetails[${index}].cellNo`}>Cell No.</Label><Input name={`accusedDetails[${index}].cellNo`} value={accused.cellNo || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                             <div><Label htmlFor={`accusedDetails[${index}].email`}>Email</Label><Input type="email" name={`accusedDetails[${index}].email`} value={accused.email || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                        </div>
                        <h5 className="text-sm font-medium mt-3 mb-2">Accused Address:</h5>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div><Label htmlFor={`accusedDetails[${index}].address.houseNo`}>House No.</Label><Input name={`accusedDetails[${index}].address.houseNo`} value={accused.address?.houseNo || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].address.streetVillage`}>Street/Village</Label><Input name={`accusedDetails[${index}].address.streetVillage`} value={accused.address?.streetVillage || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].address.areaMandal`}>Area/Mandal</Label><Input name={`accusedDetails[${index}].address.areaMandal`} value={accused.address?.areaMandal || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].address.cityDistrict`}>City/District</Label><Input name={`accusedDetails[${index}].address.cityDistrict`} value={accused.address?.cityDistrict || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].address.state`}>State</Label><Input name={`accusedDetails[${index}].address.state`} value={accused.address?.state || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].address.pin`}>PIN</Label><Input name={`accusedDetails[${index}].address.pin`} value={accused.address?.pin || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                        </div>
                        <h5 className="text-sm font-medium mt-3 mb-2">Physical Features:</h5>
                         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div><Label htmlFor={`accusedDetails[${index}].physicalFeatures.build`}>Build</Label><Input name={`accusedDetails[${index}].physicalFeatures.build`} value={accused.physicalFeatures?.build || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].physicalFeatures.heightCms`}>Height (cms)</Label><Input name={`accusedDetails[${index}].physicalFeatures.heightCms`} value={accused.physicalFeatures?.heightCms || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div><Label htmlFor={`accusedDetails[${index}].physicalFeatures.complexion`}>Complexion</Label><Input name={`accusedDetails[${index}].physicalFeatures.complexion`} value={accused.physicalFeatures?.complexion || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                            <div className="md:col-span-3"><Label htmlFor={`accusedDetails[${index}].physicalFeatures.deformitiesPeculiarities`}>Deformities/Peculiarities</Label><Input name={`accusedDetails[${index}].physicalFeatures.deformitiesPeculiarities`} value={accused.physicalFeatures?.deformitiesPeculiarities || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} /></div>
                        </div>
                    </div>
                ))}
                 {(!formData.accusedDetails || formData.accusedDetails.length === 0) && <p className="text-muted-foreground text-sm">No accused added yet. Click "Add Accused" to add one.</p>}
            </div>

          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">7. Properties Involved</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2"><Label htmlFor="propertiesInvolvedDetails">Details of Properties Stolen/Involved</Label><Textarea id="propertiesInvolvedDetails" name="propertiesInvolvedDetails" value={formData.propertiesInvolvedDetails || ''} onChange={handleInputChange} rows={3} /></div>
              <div><Label htmlFor="propertiesTotalValueStolen">Total Value of Properties Stolen (INR)</Label><Input id="propertiesTotalValueStolen" name="propertiesTotalValueStolen" value={formData.propertiesTotalValueStolen || ''} onChange={handleInputChange} /></div>
            </div>
          </div>
          
          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">8. Delay in Reporting (if any)</h3>
             <div className="flex items-center space-x-2 mb-2">
                <Checkbox id="delayInReportingIsDelayed" name="delayInReportingIsDelayed" checked={formData.delayInReportingIsDelayed || false} onCheckedChange={(checked) => handleCheckboxChange("delayInReportingIsDelayed", !!checked)} />
                <Label htmlFor="delayInReportingIsDelayed">Was there a delay in reporting?</Label>
            </div>
            {formData.delayInReportingIsDelayed && (
                <div><Label htmlFor="delayInReportingReason">Reason for Delay</Label><Textarea id="delayInReportingReason" name="delayInReportingReason" value={formData.delayInReportingReason || ''} onChange={handleInputChange} rows={2}/></div>
            )}
            <h3 className="text-lg font-semibold text-primary mt-4 mb-3">9. Inquest Report / U.D. Case No. (if any)</h3>
            <div><Label htmlFor="inquestReportUDCaseNumber">Inquest Report / U.D. Case No.</Label><Input id="inquestReportUDCaseNumber" name="inquestReportUDCaseNumber" value={formData.inquestReportUDCaseNumber || ''} onChange={handleInputChange} /></div>
          </div>

          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">10. Complaint / Statement of Complainant/Informant <span className="text-destructive">*</span></h3>
            <Label htmlFor="complaintStatement">Detailed Narrative</Label>
            <Textarea id="complaintStatement" name="complaintStatement" value={formData.complaintStatement || ''} onChange={handleInputChange} rows={8} placeholder="AI Suggestion: Draft complaint based on the original conversation." required/>
          </div>

            <div className="border-b pb-6 mb-6">
            <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-primary">Victim Details</h3>
                <div className="flex items-center space-x-2">
                    <Checkbox id="isComplainantVictim" checked={isComplainantVictim} onCheckedChange={(checked) => { setIsComplainantVictim(!!checked); }} />
                    <Label htmlFor="isComplainantVictim">Complainant is also the Victim</Label>
                </div>
            </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div><Label htmlFor="victimName">Victim Name</Label><Input name="victimName" value={formData.victimName || ''} onChange={handleInputChange} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimDob">Victim DOB</Label><Input name="victimDob" type="date" value={formData.victimDob || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'date')} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimAge">Victim Age (auto-calculated)</Label><Input name="victimAge" value={formData.victimAge || ''}  disabled={isComplainantVictim || !!formData.victimDob} readOnly /></div>
                    <div><Label htmlFor="victimGender">Victim Gender</Label>
                         <Select name="victimGender" value={formData.victimGender || ''} onValueChange={(value) => handleNestedInputChange("victimGender", value)} disabled={isComplainantVictim}>
                            <SelectTrigger><SelectValue placeholder="Select Gender" /></SelectTrigger>
                            <SelectContent>{genderOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div><Label htmlFor="victimFatherHusbandName">Victim Father's/Husband's Name</Label><Input name="victimFatherHusbandName" value={formData.victimFatherHusbandName || ''} onChange={handleInputChange} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimNationality">Victim Nationality</Label><Input name="victimNationality" value={formData.victimNationality || 'Indian'} onChange={handleInputChange} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimReligion">Victim Religion</Label><Input name="victimReligion" value={formData.victimReligion || ''} onChange={handleInputChange} /></div>
                    <div><Label htmlFor="victimCaste">Victim Caste</Label><Input name="victimCaste" value={formData.victimCaste || ''} onChange={handleInputChange} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimOccupation">Victim Occupation</Label><Input name="victimOccupation" value={formData.victimOccupation || ''} onChange={handleInputChange} disabled={isComplainantVictim} /></div>
                </div>
                <h4 className="text-md font-medium mt-4 mb-2">Victim Address:</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div><Label htmlFor="victimAddress.houseNo">House No.</Label><Input name="victimAddress.houseNo" value={formData.victimAddress?.houseNo || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimAddress.streetVillage">Street/Village</Label><Input name="victimAddress.streetVillage" value={formData.victimAddress?.streetVillage || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimAddress.areaMandal">Area/Mandal</Label><Input name="victimAddress.areaMandal" value={formData.victimAddress?.areaMandal || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimAddress.cityDistrict">City/District</Label><Input name="victimAddress.cityDistrict" value={formData.victimAddress?.cityDistrict || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimAddress.state">State</Label><Input name="victimAddress.state" value={formData.victimAddress?.state || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} disabled={isComplainantVictim} /></div>
                    <div><Label htmlFor="victimAddress.pin">PIN</Label><Input name="victimAddress.pin" value={formData.victimAddress?.pin || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value)} disabled={isComplainantVictim} /></div>
                </div>
            </div>

            <div className="border-b pb-6 mb-6">
                <h3 className="text-lg font-semibold text-primary mb-3">Acts & Sections Involved</h3>
                <Label htmlFor="actsAndSectionsInvolved">Acts & Sections (comma-separated or detailed)</Label>
                <Textarea name="actsAndSectionsInvolved" value={formData.actsAndSectionsInvolved || ''} onChange={handleInputChange} rows={2} placeholder="E.g., IPC 379, BNS 101" />
            </div>

          <div className="border-b pb-6 mb-6">
            <h3 className="text-lg font-semibold text-primary mb-3">11. Action Taken</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="lg:col-span-3"><Label htmlFor="actionTakenType">Action Taken (Details)</Label><Textarea id="actionTakenType" name="actionTakenType" value={formData.actionTakenType || ''} onChange={handleInputChange} rows={2} placeholder="E.g., Registered the case and took up the investigation" /></div>
                <div><Label htmlFor="actionTakenOfficerName">Investigating Officer Name</Label><Input id="actionTakenOfficerName" name="actionTakenOfficerName" value={formData.actionTakenOfficerName || ''} onChange={handleInputChange} /></div>
                <div><Label htmlFor="actionTakenOfficerRank">Officer Rank</Label><Input id="actionTakenOfficerRank" name="actionTakenOfficerRank" value={formData.actionTakenOfficerRank || ''} onChange={handleInputChange} /></div>
                <div><Label htmlFor="actionTakenDistrict">District (of officer)</Label><Input id="actionTakenDistrict" name="actionTakenDistrict" value={formData.actionTakenDistrict || ''} onChange={handleInputChange} /></div>
            </div>

            <h3 className="text-lg font-semibold text-primary mt-4 mb-3">12. Dispatch to Court</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div><Label htmlFor="dispatchToCourtDateTime">Date/Time of Dispatch</Label><Input id="dispatchToCourtDateTime" name="dispatchToCourtDateTime" type="datetime-local" value={formData.dispatchToCourtDateTime || ''} onChange={(e) => handleNestedInputChange(e.target.name, e.target.value, 'datetime-local')} /></div>
                <div><Label htmlFor="dispatchToCourtOfficerName">Name of Officer</Label><Input id="dispatchToCourtOfficerName" name="dispatchToCourtOfficerName" value={formData.dispatchToCourtOfficerName || ''} onChange={handleInputChange} /></div>
                <div><Label htmlFor="dispatchToCourtOfficerRank">Rank of Officer</Label><Input id="dispatchToCourtOfficerRank" name="dispatchToCourtOfficerRank" value={formData.dispatchToCourtOfficerRank || ''} onChange={handleInputChange} /></div>
            </div>
            
            <h3 className="text-lg font-semibold text-primary mt-4 mb-3">13. Confirmation</h3>
            <div className="space-y-2">
                <div className="flex items-center space-x-2">
                    <Checkbox id="confirmationFirReadOverAndAdmitted" name="confirmationFirReadOverAndAdmitted" checked={formData.confirmationFirReadOverAndAdmitted || false} onCheckedChange={(checked) => handleCheckboxChange("confirmationFirReadOverAndAdmitted", !!checked)} />
                    <Label htmlFor="confirmationFirReadOverAndAdmitted">FIR read over and admitted correct by Complainant/Informant</Label>
                </div>
                <div className="flex items-center space-x-2">
                    <Checkbox id="confirmationCopyGivenToComplainant" name="confirmationCopyGivenToComplainant" checked={formData.confirmationCopyGivenToComplainant || false} onCheckedChange={(checked) => handleCheckboxChange("confirmationCopyGivenToComplainant", !!checked)} />
                    <Label htmlFor="confirmationCopyGivenToComplainant">Copy of FIR given to Complainant/Informant free of cost</Label>
                </div>
                 <div className="flex items-center space-x-2">
                    <Checkbox id="confirmationRoac" name="confirmationRoac" checked={formData.confirmationRoac || false} onCheckedChange={(checked) => handleCheckboxChange("confirmationRoac", !!checked)} />
                    <Label htmlFor="confirmationRoac">ROAC (Recorded Over & Admitted Correct)</Label>
                </div>
                <div>
                    <Label htmlFor="confirmationSignatureOfComplainant">Signature/Thumb Impression of Complainant/Informant (Enter 'Digitally Signed' or path if applicable)</Label>
                    <Input id="confirmationSignatureOfComplainant" name="confirmationSignatureOfComplainant" value={formData.confirmationSignatureOfComplainant || ''} onChange={handleInputChange} />
                </div>
            </div>
          </div>

        </CardContent>
        <CardFooter className="flex justify-end gap-2 sticky bottom-0 bg-card py-4 border-t">
           {originalComplaintId && <p className="text-sm text-muted-foreground flex items-center mr-auto"><AlertTriangle className="h-4 w-4 mr-1 text-yellow-500" /> Review AI-suggested fields and complete all required details.</p>}
          <Button type="button" variant="outline" onClick={() => router.back()}>Cancel</Button>
          <Button type="submit" disabled={isLoading || (isPrefilling && !hasInitialized) }>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Confirm FIR Registration
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}


export default function NewCasePage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center min-h-[calc(100vh-10rem)]"><Loader2 className="h-12 w-12 animate-spin text-primary" /> <p className="ml-4">Loading...</p></div>}>
      <NewCasePageContent />
    </Suspense>
  );
}
    