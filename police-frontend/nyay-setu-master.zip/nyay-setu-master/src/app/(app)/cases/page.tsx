"use client";

import { useEffect, useState } from 'react';
import { collection, getDocs, orderBy, query, Timestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import FIRCard from '@/components/dashboard/FIRCard';
import type { CaseDoc } from '@/types'; // Use CaseDoc
import { CaseStatus } from '@/types';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { PlusCircle, FolderOpen, Loader2, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

export default function AllCasesPage() {
  const { user, profileLoading } = useAuth();
  const [cases, setCases] = useState<CaseDoc[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (profileLoading) return;
    if (!user) {
      setIsLoading(false);
      setError('User not authenticated. Please log in.');
      return;
    }
    const fetchCases = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const casesRef = collection(db, 'cases');
        const q = query(casesRef, orderBy('dateFiled', 'desc'));
        const querySnapshot = await getDocs(q);
        const fetchedCases: CaseDoc[] = [];
        querySnapshot.forEach((doc) => {
          const data = doc.data();
          fetchedCases.push({
            id: doc.id,
            ...data,
            dateFiled: data.dateFiled,
            lastUpdated: data.lastUpdated,
          } as CaseDoc);
        });
        // Filter cases: show all if admin, else only user's own
        if (user.profile?.role === 'admin') {
          setCases(fetchedCases);
        } else {
          setCases(fetchedCases.filter(c => c.userId === user.uid));
        }
      } catch (err: any) {
        console.error("Error fetching cases:", err);
        setError(`Failed to fetch cases. ${err.message}`);
      } finally {
        setIsLoading(false);
      }
    };
    fetchCases();
  }, [user, profileLoading]);

  if (isLoading || profileLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-muted-foreground">Loading cases...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] text-center">
        <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
        <h2 className="text-xl font-semibold text-destructive">Error Fetching Cases</h2>
        <p className="text-muted-foreground">{error}</p>
        <Button onClick={() => window.location.reload()} className="mt-4">Try Again</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight font-headline flex items-center">
            <FolderOpen className="mr-3 h-8 w-8 text-primary" /> All Cases
          </h1>
          <p className="text-muted-foreground">Manage and view details of all registered FIRs/cases.</p>
        </div>
        <Button asChild>
          <Link href="/cases/new">
            <PlusCircle className="mr-2 h-4 w-4" /> Register New Case
          </Link>
        </Button>
      </div>
      
      {cases.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {cases.map((caseDoc) => (
            // FIRCard needs to be adapted if CaseDoc structure is very different from FIRData
            // For now, let's assume FIRCard can handle it or we'll adapt it next.
            <FIRCard key={caseDoc.id} caseData={caseDoc} />
          ))}
        </div>
      ) : (
        <div className="text-center py-10 border-2 border-dashed rounded-lg">
            <p className="text-muted-foreground">No cases found.</p>
            <Button variant="link" asChild className="mt-2">
                <Link href="/cases/new">Start by registering a new case.</Link>
            </Button>
        </div>
      )}
    </div>
  );
}
