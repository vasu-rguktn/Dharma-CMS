"use client";

import { useEffect, useState, useMemo } from 'react';
import { collection, getDocs, orderBy, query, Timestamp, where, doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import FIRCard from '@/components/dashboard/FIRCard';
import type { CaseDoc, SavedComplaint, MediaAnalysisRecord, UserProfile } from '@/types';
import { CaseStatus } from '@/types';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { PlusCircle, Loader2, AlertTriangle, BarChart3, PieChartIcon, Users, Building, FileText as ComplaintIcon, FileText as FIRIcon, ImageIcon as MediaIcon } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  type ChartConfig
} from "@/components/ui/chart";
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Pie, PieChart, Cell } from "recharts";
import { ScrollArea } from '@/components/ui/scroll-area';

const statusColorsForChart: ChartConfig = {
  [CaseStatus.New]: { label: CaseStatus.New, color: "hsl(var(--chart-1))" },
  [CaseStatus.UnderInvestigation]: { label: CaseStatus.UnderInvestigation, color: "hsl(var(--chart-2))" },
  [CaseStatus.PendingTrial]: { label: CaseStatus.PendingTrial, color: "hsl(var(--chart-3))" },
  [CaseStatus.Resolved]: { label: CaseStatus.Resolved, color: "hsl(var(--chart-4))" },
  [CaseStatus.Closed]: { label: CaseStatus.Closed, color: "hsl(var(--chart-5))" },
};

interface ActivityCounts {
  complaints: number;
  firs: number;
  mediaAnalyses: number;
}
interface StationActivity extends ActivityCounts { name: string; }
interface OfficerActivity extends ActivityCounts { name: string; station?: string; }

export default function DashboardPage() {
  const { user, profileLoading: authProfileLoading } = useAuth();
  const [allCases, setAllCases] = useState<CaseDoc[]>([]);
  const [allComplaints, setAllComplaints] = useState<SavedComplaint[]>([]);
  const [allMediaAnalyses, setAllMediaAnalyses] = useState<MediaAnalysisRecord[]>([]);
  const [allUserProfiles, setAllUserProfiles] = useState<Record<string, UserProfile>>({});
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (authProfileLoading) return; 

    const fetchDashboardData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const usersRef = collection(db, 'users');
        const usersSnapshot = await getDocs(usersRef);
        const profiles: Record<string, UserProfile> = {};
        usersSnapshot.forEach(userDoc => {
          profiles[userDoc.id] = { uid: userDoc.id, ...userDoc.data() } as UserProfile;
        });
        setAllUserProfiles(profiles);

        let fetchedCases: CaseDoc[] = [];
        let fetchedComplaints: SavedComplaint[] = [];
        let fetchedMediaAnalysesData: MediaAnalysisRecord[] = [];

        // Fetch all data regardless of role
        const casesQuery = query(collection(db, 'cases'), orderBy('dateFiled', 'desc'));
        const casesSnapshot = await getDocs(casesQuery);
        casesSnapshot.forEach(doc => fetchedCases.push({ id: doc.id, ...doc.data() } as CaseDoc));

        const complaintsQuery = query(collection(db, 'complaints'), orderBy('createdAt', 'desc'));
        const complaintsSnapshot = await getDocs(complaintsQuery);
        complaintsSnapshot.forEach(doc => fetchedComplaints.push({ id: doc.id, ...doc.data() } as SavedComplaint));
        
        if (fetchedCases.length > 0) {
          const analysesPromises = fetchedCases.map(async (caseDoc) => {
            if (caseDoc.id) {
              const analysesRef = collection(db, 'cases', caseDoc.id, 'mediaAnalyses');
              const analysesSnapshot = await getDocs(analysesRef);
              analysesSnapshot.forEach(analysisDoc => {
                fetchedMediaAnalysesData.push({ id: analysisDoc.id, caseId: caseDoc.id, ...analysisDoc.data() } as MediaAnalysisRecord);
              });
            }
          });
          await Promise.all(analysesPromises);
        }
        
        // Restrict access to FIRs, complaints, and media analyses for non-admins
        if (user!.profile?.role === 'admin') {
          setAllCases(fetchedCases);
          setAllComplaints(fetchedComplaints);
          setAllMediaAnalyses(fetchedMediaAnalysesData);
        } else {
          setAllCases(fetchedCases.filter(c => c.userId === user!.uid));
          setAllComplaints(fetchedComplaints.filter(c => c.userId === user!.uid));
          setAllMediaAnalyses(fetchedMediaAnalysesData.filter(m => m.userId === user!.uid));
        }

      } catch (err: any) {
        console.error("Error fetching dashboard data:", err);
        if (err.code === 'permission-denied' || (err.message && err.message.toLowerCase().includes("permission"))) {
            setError("Failed to fetch dashboard data due to missing or insufficient Firestore permissions. Please check your Firestore security rules.");
        } else {
            setError(`Failed to fetch dashboard data. ${err.message}`);
        }
      } finally {
        setIsLoading(false);
      }
    };

    if (user) { 
      fetchDashboardData();
    } else if (!authProfileLoading && !user) { 
      setIsLoading(false);
      setError("User not authenticated. Please log in.");
    }
  }, [user, authProfileLoading]);

  const caseStatusData = useMemo(() => {
    if (!allCases.length) return [];
    const counts = allCases.reduce((acc, caseDoc) => {
      acc[caseDoc.status] = (acc[caseDoc.status] || 0) + 1;
      return acc;
    }, {} as Record<CaseStatus, number>);
    return Object.entries(counts).map(([status, count]) => ({
      name: status as CaseStatus,
      count: count,
      fill: statusColorsForChart[status as CaseStatus]?.color || "hsl(var(--muted))",
    }));
  }, [allCases]);


  const stationActivityData = useMemo(() => {
    const activity: Record<string, ActivityCounts> = {};

    allComplaints.forEach(c => {
      const station = c.officerStationName || 'Unknown Station';
      activity[station] = activity[station] || { complaints: 0, firs: 0, mediaAnalyses: 0 };
      activity[station].complaints++;
    });

    allCases.forEach(c => {
      const station = c.policeStation || 'Unknown Station';
      activity[station] = activity[station] || { complaints: 0, firs: 0, mediaAnalyses: 0 };
      activity[station].firs++;
    });

    allMediaAnalyses.forEach(ma => {
      const caseDoc = allCases.find(c => c.id === ma.caseId);
      const station = caseDoc?.policeStation || allUserProfiles[ma.userId!]?.stationName || 'Unknown Station';
      activity[station] = activity[station] || { complaints: 0, firs: 0, mediaAnalyses: 0 };
      activity[station].mediaAnalyses++;
    });
    
    const result = Object.entries(activity)
                         .map(([name, counts]) => ({ name, ...counts }))
                         .sort((a,b) => (b.complaints + b.firs + b.mediaAnalyses) - (a.complaints + a.firs + a.mediaAnalyses));
    
    return result;

  }, [allComplaints, allCases, allMediaAnalyses, allUserProfiles]);

  const officerActivityData = useMemo(() => {
    const activity: Record<string, OfficerActivity> = {};

    allComplaints.forEach(c => {
        const officerId = c.userId || 'unknown-uid';
        const officerProfile = allUserProfiles[officerId];
        const officerKey = officerProfile?.displayName || `UID: ${officerId}`;
        activity[officerKey] = activity[officerKey] || { name: officerKey, complaints: 0, firs: 0, mediaAnalyses: 0, station: officerProfile?.stationName || c.officerStationName || 'Unknown Station' };
        activity[officerKey].complaints++;
    });

    allCases.forEach(c => {
        const officerId = c.userId || 'unknown-uid';
        const officerProfile = allUserProfiles[officerId];
        const officerKey = officerProfile?.displayName || `UID: ${officerId}`;
        activity[officerKey] = activity[officerKey] || { name: officerKey, complaints: 0, firs: 0, mediaAnalyses: 0, station: officerProfile?.stationName || c.policeStation || 'Unknown Station' };
        activity[officerKey].firs++;
    });
    
    allMediaAnalyses.forEach(ma => {
        const officerId = ma.userId || 'unknown-uid';
        const officerProfile = allUserProfiles[officerId];
        const officerKey = officerProfile?.displayName || `UID: ${officerId}`;
        activity[officerKey] = activity[officerKey] || { name: officerKey, complaints: 0, firs: 0, mediaAnalyses: 0, station: officerProfile?.stationName || 'Unknown Station' };
        activity[officerKey].mediaAnalyses++;
    });

    const result = Object.values(activity)
                         .sort((a,b) => (b.complaints + b.firs + b.mediaAnalyses) - (a.complaints + a.firs + a.mediaAnalyses));
    return result;
  }, [allComplaints, allCases, allMediaAnalyses, allUserProfiles]);
  
  const analyticsChartConfig: ChartConfig = {
    complaints: { label: "Complaints", color: "hsl(var(--chart-1))", icon: ComplaintIcon },
    firs: { label: "FIRs", color: "hsl(var(--chart-2))", icon: FIRIcon },
    mediaAnalyses: { label: "Media Analyses", color: "hsl(var(--chart-3))", icon: MediaIcon },
  };

  if (isLoading || authProfileLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-muted-foreground">Loading dashboard data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] text-center">
        <AlertTriangle className="h-12 w-12 text-destructive mb-4" />
        <h2 className="text-xl font-semibold text-destructive">Error Fetching Data</h2>
        <p className="text-muted-foreground max-w-md">{error}</p>
        <Button onClick={() => window.location.reload()} className="mt-4">Try Again</Button>
         <p className="text-xs text-muted-foreground mt-4">
          Note: If this is a permission error, please ensure your Firestore security rules allow necessary read operations.
        </p>
      </div>
    );
  }
  
  const recentCasesToDisplay = allCases.slice(0, 4);
  const totalCasesCount = allCases.length;

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight font-headline">Welcome, {user?.profile?.displayName || user?.email || 'Officer'}!</h1>
          <p className="text-muted-foreground">
            Here's an overview of all cases and crime analytics.
          </p>
        </div>
        <Button asChild>
          <Link href="/cases/new">
            <PlusCircle className="mr-2 h-4 w-4" /> New Case / FIR
          </Link>
        </Button>
      </div>
      
      <section className="space-y-6">
        <h2 className="text-2xl font-semibold tracking-tight font-headline flex items-center">
          <PieChartIcon className="mr-3 h-7 w-7 text-primary" />
          Overall Case Status Overview
        </h2>
        <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="font-headline text-xl">Cases by Current Status</CardTitle>
              <CardDescription>Distribution of all registered cases.</CardDescription>
            </CardHeader>
            <CardContent>
              {caseStatusData.length > 0 ? (
                <ChartContainer config={statusColorsForChart} className="min-h-[250px] w-full">
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <ChartTooltip content={<ChartTooltipContent nameKey="name" />} />
                      <Pie data={caseStatusData} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={80} labelLine={false} label={({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
                            const RADIAN = Math.PI / 180;
                            const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                            const x = cx + radius * Math.cos(-midAngle * RADIAN);
                            const y = cy + radius * Math.sin(-midAngle * RADIAN);
                            return (
                              <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" fontSize="10px">
                                {`${(percent * 100).toFixed(0)}%`}
                              </text>
                            );
                          }}>
                        {caseStatusData.map((entry) => (
                          <Cell key={`cell-${entry.name}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <ChartLegend content={<ChartLegendContent nameKey="name" />} />
                    </PieChart>
                  </ResponsiveContainer>
                </ChartContainer>
              ) : (
                <p className="text-muted-foreground text-center py-10">No case data available for status chart.</p>
              )}
            </CardContent>
          </Card>
          <Card className="shadow-lg flex items-center justify-center min-h-[300px] bg-muted/30">
            <CardContent className="text-center">
              <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">More status analytics coming soon!</p>
              <p className="text-xs text-muted-foreground">(e.g., Aging of cases by status)</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="space-y-6">
        <h2 className="text-2xl font-semibold tracking-tight font-headline flex items-center">
            <Building className="mr-3 h-7 w-7 text-primary" />
            Station-wise Activity
        </h2>
        <Card className="shadow-lg">
            <CardHeader>
                <CardTitle className="font-headline text-xl">Activity Summary</CardTitle>
                <CardDescription>Complaints, FIRs, and Media Analyses recorded per station.</CardDescription>
            </CardHeader>
            <CardContent>
                {stationActivityData.length > 0 ? (
                  <ScrollArea className="h-[400px] w-full">
                    <ChartContainer config={analyticsChartConfig} className="min-h-[300px] w-full">
                        <ResponsiveContainer width="100%" height={Math.max(150, stationActivityData.length * 50)}>
                           <BarChart data={stationActivityData} layout="vertical" margin={{ right: 20, left: 100, bottom: 20 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis type="number" />
                                <YAxis dataKey="name" type="category" width={150} tick={{ fontSize: 10 }} interval={0} />
                                <ChartTooltip content={<ChartTooltipContent />} />
                                <ChartLegend content={<ChartLegendContent />} />
                                <Bar dataKey="complaints" fill="var(--color-complaints)" radius={4} barSize={10}/>
                                <Bar dataKey="firs" fill="var(--color-firs)" radius={4} barSize={10}/>
                                <Bar dataKey="mediaAnalyses" fill="var(--color-mediaAnalyses)" radius={4} barSize={10}/>
                            </BarChart>
                        </ResponsiveContainer>
                    </ChartContainer>
                  </ScrollArea>
                ) : (
                    <p className="text-muted-foreground text-center py-10">No station activity data available.</p>
                )}
            </CardContent>
        </Card>
      </section>
      
      <section className="space-y-6">
          <h2 className="text-2xl font-semibold tracking-tight font-headline flex items-center">
              <Users className="mr-3 h-7 w-7 text-primary" />
              Officer-wise Activity
          </h2>
          <Card className="shadow-lg">
              <CardHeader>
                  <CardTitle className="font-headline text-xl">Activity by Officer</CardTitle>
                  <CardDescription>Complaints, FIRs, and Media Analyses per officer.</CardDescription>
              </CardHeader>
              <CardContent>
                  {officerActivityData.length > 0 ? (
                    <ScrollArea className="h-[400px] w-full">
                        <ChartContainer config={analyticsChartConfig} className="min-h-[300px] w-full">
                           <ResponsiveContainer width="100%" height={Math.max(300, officerActivityData.length * 60)}>
                               <BarChart data={officerActivityData} layout="vertical" margin={{ right: 20, left: 150, bottom: 20 }}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis type="number" />
                                    <YAxis dataKey="name" type="category" width={200} tick={{ fontSize: 10 }} interval={0} 
                                     tickFormatter={(value, index) => {
                                         const officer = officerActivityData[index];
                                         return `${officer?.name || 'N/A'} (${officer?.station || 'N/A'})`;
                                     }}
                                    />
                                    <ChartTooltip 
                                      formatter={(value: number, name: string, props: any) => [`${value} ${analyticsChartConfig[name as keyof typeof analyticsChartConfig]?.label || name}`, props.payload.name]}
                                      labelFormatter={(label: string, payload: any[]) => {
                                        if (payload && payload.length > 0) {
                                          const officer = payload[0].payload;
                                          return `${officer?.name} (${officer?.station || 'N/A'})`;
                                        }
                                        return label;
                                      }}
                                    />
                                    <ChartLegend content={<ChartLegendContent />} />
                                    <Bar dataKey="complaints" stackId="a" fill="var(--color-complaints)" radius={[0, 4, 4, 0]} barSize={12} />
                                    <Bar dataKey="firs" stackId="a" fill="var(--color-firs)" barSize={12}/>
                                    <Bar dataKey="mediaAnalyses" stackId="a" fill="var(--color-mediaAnalyses)" radius={[0, 4, 4, 0]} barSize={12}/>
                                </BarChart>
                            </ResponsiveContainer>
                        </ChartContainer>
                      </ScrollArea>
                   ) : (
                     <p className="text-muted-foreground text-center py-10">No officer activity data available.</p>
                   )}
              </CardContent>
          </Card>
        </section>
      
      <section className="space-y-6">
         <h2 className="text-2xl font-semibold tracking-tight font-headline">
           Recent Cases
         </h2>
        {recentCasesToDisplay.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
            {recentCasesToDisplay.map((caseDoc) => (
              <FIRCard key={caseDoc.id} caseData={caseDoc} />
            ))}
          </div>
        ) : (
          <div className="text-center py-10 border-2 border-dashed rounded-lg">
              <p className="text-muted-foreground">No cases found.</p>
          </div>
        )}
        {totalCasesCount > recentCasesToDisplay.length && (
            <div className="text-center mt-6">
                <Button variant="outline" asChild>
                    <Link href="/cases">View All Cases ({totalCasesCount})</Link>
                </Button>
            </div>
        )}
      </section>
    </div>
  );
}
