
"use client";

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Settings as SettingsIcon, Save, Loader2, AlertCircle, DatabaseZap, UserCircle2, UploadCloud } from 'lucide-react';
import { useAuth, type AppUser } from '@/hooks/useAuth'; // Use AppUser from useAuth
import { useToast } from '@/hooks/use-toast';
import { doc, updateDoc, serverTimestamp, Timestamp, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { UserProfile, UserProfileAddress } from '@/types';
import Image from 'next/image'; // For displaying profile image

interface EditableProfileFields {
  displayName: string;
  phoneNumber: string;
  profilePhotoUrl: string;
}

const initialEditableFields: EditableProfileFields = {
  displayName: '',
  phoneNumber: '',
  profilePhotoUrl: '',
};

export default function SettingsPage() {
  const { user, loading: authLoading, profileLoading } = useAuth(); // authUser is AppUser type
  const { toast } = useToast();
  
  // State for profile data fetched from Firestore (part of AppUser)
  const [profileData, setProfileData] = useState<Partial<UserProfile>>({});
  // State for fields that are directly editable by the user on this page
  const [editableFields, setEditableFields] = useState<EditableProfileFields>(initialEditableFields);
  
  const [isSaving, setIsSaving] = useState(false);

  // Effect to initialize form fields when user or profile data changes
  useEffect(() => {
    if (user?.profile) {
      setProfileData(user.profile);
      setEditableFields({
        displayName: user.profile.displayName || user.displayName || '',
        phoneNumber: user.profile.phoneNumber || '',
        profilePhotoUrl: user.profile.profilePhotoUrl || user.photoURL || '',
      });
    } else if (user) { // Auth user exists, but no Firestore profile yet
      setProfileData({
        uid: user.uid,
        email: user.email || '',
        role: 'officer', // Default for new/incomplete profiles
      });
      setEditableFields({
        displayName: user.displayName || '',
        phoneNumber: user.phoneNumber || '',
        profilePhotoUrl: user.photoURL || '',
      });
    } else { // No user
      setProfileData({});
      setEditableFields(initialEditableFields);
    }
  }, [user]);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditableFields(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveChanges = async () => {
    if (!user) {
      toast({ variant: "destructive", title: "Not Authenticated" });
      return;
    }
    setIsSaving(true);
    try {
      const userDocRef = doc(db, 'users', user.uid);
      
      // Data to update/create in Firestore UserProfile
      const profileUpdateData: Partial<UserProfile> = {
        displayName: editableFields.displayName.trim() || null,
        phoneNumber: editableFields.phoneNumber.trim() || null,
        profilePhotoUrl: editableFields.profilePhotoUrl.trim() || null,
        updatedAt: serverTimestamp() as Timestamp,
      };

      if (user.profile) { // Profile exists, update it
        await updateDoc(userDocRef, profileUpdateData);
      } else { // Profile doesn't exist, create it with all available info
        const newProfile: UserProfile = {
          uid: user.uid,
          email: user.email || '',
          displayName: profileUpdateData.displayName,
          phoneNumber: profileUpdateData.phoneNumber,
          profilePhotoUrl: profileUpdateData.profilePhotoUrl,
          role: 'officer', // Default for a newly completed profile
          // These should be ideally set by admin or during a more detailed onboarding
          stationName: null, 
          district: null,
          rank: null,
          badgeNumber: null,
          employeeId: null,
          address: null,
          createdAt: serverTimestamp() as Timestamp,
          updatedAt: serverTimestamp() as Timestamp,
        };
        await setDoc(userDocRef, newProfile);
        // Optionally, update the AuthContext user state here if it doesn't auto-refresh
      }
      toast({ title: "Profile Updated", description: "Your changes have been saved." });
    } catch (error: any) {
      console.error("Error updating profile:", error);
      toast({ variant: "destructive", title: "Update Failed", description: error.message || "Could not save profile changes." });
    } finally {
      setIsSaving(false);
    }
  };
  
  const displayAddress = (address?: UserProfileAddress | null): string => {
    if (!address) return 'N/A';
    const parts = [address.street, address.city, address.state, address.postalCode, address.country].filter(Boolean);
    return parts.join(', ') || 'N/A';
  };
  
  const ProfileFieldDisplay = ({ label, value }: { label: string; value?: string | null | number }) => (
    <div>
      <Label className="text-sm text-muted-foreground">{label}</Label>
      <p className="text-md font-medium">{value || 'N/A'}</p>
    </div>
  );


  if (authLoading || profileLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-10rem)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-4 text-muted-foreground">Loading settings...</p>
      </div>
    );
  }
  
  if (!user) {
     return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-destructive">Access Denied</h1>
        <p className="text-muted-foreground">Please log in to view your settings.</p>
      </div>
    );
  }

  const currentProfile = user.profile;

  return (
    <div className="space-y-8">
      <div className="flex items-center">
        <SettingsIcon className="mr-3 h-8 w-8 text-primary" />
        <h1 className="text-3xl font-bold tracking-tight font-headline">Settings</h1>
      </div>
      <p className="text-muted-foreground">Manage your profile and application settings.</p>

      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-xl">User Profile</CardTitle>
          <CardDescription>View and update your personal information. Official details like Role, Station, and Rank are managed by administrators.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-4 mb-6 pb-6 border-b">
            {editableFields.profilePhotoUrl ? (
                <Image src={editableFields.profilePhotoUrl} alt="Profile" width={80} height={80} className="rounded-full object-cover border" />
            ) : (
                <UserCircle2 className="h-20 w-20 text-muted-foreground border rounded-full p-2" />
            )}
            <div>
                <h3 className="text-lg font-semibold">{editableFields.displayName || 'N/A'}</h3>
                <p className="text-sm text-muted-foreground">{currentProfile?.email || user.email || 'N/A'}</p>
                <p className="text-xs text-muted-foreground">UID: {user.uid}</p>
            </div>
          </div>

          <h3 className="text-md font-semibold text-primary border-b pb-2">Official Details (Read-only)</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <ProfileFieldDisplay label="Role" value={currentProfile?.role} />
            <ProfileFieldDisplay label="District" value={currentProfile?.district} />
            <ProfileFieldDisplay label="Station Name" value={currentProfile?.stationName} />
            <ProfileFieldDisplay label="Rank" value={currentProfile?.rank} />
            <ProfileFieldDisplay label="Badge Number" value={currentProfile?.badgeNumber} />
            <ProfileFieldDisplay label="Employee ID" value={currentProfile?.employeeId} />
            <ProfileFieldDisplay label="Registered Address" value={displayAddress(currentProfile?.address)} />
            <ProfileFieldDisplay label="Joined On" value={currentProfile?.createdAt ? (currentProfile.createdAt as Timestamp).toDate().toLocaleDateString() : 'N/A'} />
          </div>
          
          <hr className="my-6"/>

          <h3 className="text-md font-semibold text-primary border-b pb-2">Editable Information</h3>
          <div className="space-y-4">
            <div>
              <Label htmlFor="displayName">Display Name</Label>
              <Input id="displayName" name="displayName" placeholder="Your Name" value={editableFields.displayName} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="phoneNumber">Phone Number</Label>
              <Input id="phoneNumber" name="phoneNumber" type="tel" placeholder="Your contact number" value={editableFields.phoneNumber} onChange={handleInputChange} />
            </div>
            <div>
              <Label htmlFor="profilePhotoUrl">Profile Photo URL</Label>
              <Input id="profilePhotoUrl" name="profilePhotoUrl" type="url" placeholder="http://example.com/photo.jpg" value={editableFields.profilePhotoUrl} onChange={handleInputChange} />
              <p className="text-xs text-muted-foreground mt-1">Enter the URL of your profile image.</p>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleSaveChanges} disabled={isSaving || authLoading || profileLoading}>
            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </CardFooter>
      </Card>

      {currentProfile?.role === 'admin' && (
        <Card className="shadow-xl">
          <CardHeader>
            <CardTitle className="font-headline text-xl flex items-center"><DatabaseZap className="mr-2 h-5 w-5"/>AI Knowledge Base Management (Admin)</CardTitle>
            <CardDescription>Manage documents that power the AI's knowledge for grounded responses (RAG).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="knowledgeBaseFile">Upload Document Bundle (.zip, .pdf, .txt, .docx)</Label>
              <div className="flex items-center gap-2 mt-1">
                <Input id="knowledgeBaseFile" type="file" accept=".zip,.pdf,.txt,.docx,.md" disabled />
                <Button disabled>
                  <UploadCloud className="mr-2 h-4 w-4" /> Upload & Index (Soon)
                </Button>
              </div>
              <ul className="list-disc list-inside text-xs text-muted-foreground mt-2 space-y-1">
                <li>Upload documents to a specific folder (e.g., <code className="bg-muted px-1 rounded-sm">knowledge_base/</code>) in Firebase Storage.</li>
                <li>A backend process (e.g., Cloud Function) will be needed to:
                  <ul className="list-disc list-inside ml-4">
                    <li>Parse and chunk these documents.</li>
                    <li>Generate embeddings for each chunk.</li>
                    <li>Store embeddings in a vector database.</li>
                  </ul>
                </li>
                <li>This indexed knowledge will then be used by AI flows to provide more accurate answers.</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
      
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-xl">Preferences</CardTitle>
          <CardDescription>Customize your application experience. (Feature coming soon)</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-muted-foreground">Theme settings, notification preferences, etc. will be available here.</p>
        </CardContent>
      </Card>

    </div>
  );
}
