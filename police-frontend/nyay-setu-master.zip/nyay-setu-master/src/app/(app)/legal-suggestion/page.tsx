"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Loader2, AlertTriangle, Scale } from 'lucide-react';
import { legalSuggestion, type LegalSuggestionInput, type LegalSuggestionOutput } from '@/ai/flows/legal-suggestion';
import { useToast } from '@/hooks/use-toast';

export default function LegalSuggestionPage() {
  const [firDetails, setFirDetails] = useState('');
  const [incidentDetails, setIncidentDetails] = useState('');
  const [suggestion, setSuggestion] = useState<LegalSuggestionOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!firDetails.trim() || !incidentDetails.trim()) {
      toast({ variant: "destructive", title: "Input Missing", description: "Please enter both FIR and incident details." });
      return;
    }
    setIsLoading(true);
    setSuggestion(null);
    try {
      const input: LegalSuggestionInput = { firDetails, incidentDetails };
      const output = await legalSuggestion(input);
      setSuggestion(output);
      toast({ title: "Success", description: "Legal suggestions generated." });
    } catch (error) {
      console.error("Legal Suggestion Error:", error);
      toast({ variant: "destructive", title: "Error", description: "Failed to generate legal suggestions." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Scale className="mr-2 h-6 w-6" />Legal Section Suggester</CardTitle>
          <CardDescription>
            Provide FIR and incident details to get AI-powered suggestions for applicable legal sections under BNS, BNSS, BSA, and other special acts.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="firDetails" className="text-lg">FIR Details</Label>
            <Textarea
              id="firDetails"
              value={firDetails}
              onChange={(e) => setFirDetails(e.target.value)}
              placeholder="Enter comprehensive details from the First Information Report..."
              rows={8}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="incidentDetails" className="text-lg">Incident Details</Label>
            <Textarea
              id="incidentDetails"
              value={incidentDetails}
              onChange={(e) => setIncidentDetails(e.target.value)}
              placeholder="Describe the incident in detail, including sequence of events, actions taken, etc..."
              rows={8}
              className="mt-1"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Get Legal Suggestions
          </Button>
        </CardFooter>
      </Card>

      {isLoading && (
        <div className="flex justify-center items-center p-10">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
          <p className="ml-4 text-muted-foreground">Analyzing information and generating suggestions...</p>
        </div>
      )}

      {suggestion && (
        <Card className="shadow-xl mt-6">
          <CardHeader>
            <CardTitle className="font-headline text-xl">AI Legal Suggestions</CardTitle>
            <CardDescription>Review the suggested legal sections and reasoning. This is for informational purposes only.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="suggestedSections">Suggested Sections</Label>
              <Textarea id="suggestedSections" value={suggestion.suggestedSections} readOnly rows={4} className="mt-1 bg-muted/50" />
            </div>
            <div>
              <Label htmlFor="reasoning">Reasoning</Label>
              <Textarea id="reasoning" value={suggestion.reasoning} readOnly rows={8} className="mt-1 bg-muted/50" />
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-sm text-muted-foreground flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-yellow-500" />
              AI-generated content. Always consult with a legal expert for official advice.
            </p>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}
