
"use client";

import { useState, useRef, useEffect, type FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Paperclip, Send, Mic, Loader2, User, Bot, FileX2, Languages, ShieldQuestion, MessageCircle, BookCopy, UserCog, Square, Volume2, Download, CheckCircle2, Edit3, Save, FolderOpen, Play, Pause, FileText, StopCircle, Video, VideoOff } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { aiChatComplaint, type AiChatComplaintInput, type AiChatComplaintOutput } from '@/ai/flows/ai-chat-complaint';
import { saveComplaint, type SaveComplaintInput, type Message as FlowMessage } from '@/ai/flows/save-complaint-flow';
import { extractFirDetailsFromTranscript, type ExtractFirDetailsInput, type ExtractFirDetailsOutput } from '@/ai/flows/extract-fir-details';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import type { CaseDoc } from '@/types';
import { useAuth, type AppUser } from '@/hooks/useAuth';


interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  attachmentName?: string;
  attachmentType?: string;
}

type ChatMode = "complaintRecording" | "witnessStatement" | "witnessPreparation" | "normalChat" | "crimeSceneInvestigation";

// Languages available for the chat interface and AI text responses
const chatInterfaceLanguages = [
  { value: "en-US", label: "English (US)" },
  { value: "en-IN", label: "English (India)" },
  { value: "hi-IN", label: "हिन्दी (Hindi)" },
  { value: "te-IN", label: "తెలుగు (Telugu)" },
  { value: "bn-IN", label: "বাংলা (Bengali)" },
  { value: "gu-IN", label: "ગુજરાતી (Gujarati)" },
  { value: "kn-IN", label: "ಕನ್ನಡ (Kannada)" },
  { value: "ml-IN", label: "മലയാളം (Malayalam)" },
  { value: "mr-IN", label: "मराठी (Marathi)" },
  { value: "or-IN", label: "ଓଡ଼ିଆ (Odia)" },
  { value: "pa-IN", label: "ਪੰਜਾਬੀ (Punjabi)" },
  { value: "ta-IN", label: "தமிழ் (Tamil)" },
];

// Languages for which TTS playback of AI responses is enabled
const ttsPlaybackEnabledLanguages = ["en-US", "en-IN", "hi-IN"];

const chatModes: { value: ChatMode; label: string; icon: React.ElementType, description: string }[] = [
  { value: "complaintRecording", label: "Complaint Recording", icon: BookCopy, description: "Record a new complaint or incident report." },
  { value: "witnessStatement", label: "Witness Statement", icon: MessageCircle, description: "Record a statement from a witness for a specific FIR." },
  { value: "witnessPreparation", label: "Witness Preparation", icon: ShieldQuestion, description: "Conduct a mock trial to prepare a witness for testimony." },
  { value: "crimeSceneInvestigation", label: "Crime Scene Guide", icon: UserCog, description: "Get AI guidance for crime scene investigation steps." },
  { value: "normalChat", label: "Normal Chat", icon: Languages, description: "Ask general questions or seek clarifications." },
];

function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error("Failed to convert blob to Data URL."));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export default function AIChatPage() {
  const { user, profileLoading } = useAuth(); 
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [attachment, setAttachment] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const [selectedLanguage, setSelectedLanguage] = useState<string>(chatInterfaceLanguages[0].value);
  const [selectedMode, setSelectedMode] = useState<ChatMode>("complaintRecording");
  const [firNumber, setFirNumber] = useState('');
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  
  const [conversationEnded, setConversationEnded] = useState(false);
  const [finalFirNumber, setFinalFirNumber] = useState('');
  const [extractedUserSummary, setExtractedUserSummary] = useState<string | null>(null);
  const [isExtractingSummary, setIsExtractingSummary] = useState(false);

  const [isAsrRecording, setIsAsrRecording] = useState(false);
  const asrRecognitionRef = useRef<SpeechRecognition | null>(null); 
  const asrInterimTranscriptRef = useRef<string>('');
  const asrAudioStreamRef = useRef<MediaStream | null>(null);
  const userSpeechRecorderRef = useRef<MediaRecorder | null>(null);
  const currentAudioChunksRef = useRef<Blob[]>([]);
  const [userAudioClips, setUserAudioClips] = useState<Blob[]>([]);
  const [processedUserAudioBlob, setProcessedUserAudioBlob] = useState<Blob | null>(null);
  const [processedUserAudioBlobUrl, setProcessedUserAudioBlobUrl] = useState<string | null>(null);
  
  const [videoRecordingConsent, setVideoRecordingConsent] = useState<'pending' | 'granted' | 'denied'>('pending');
  const [showVideoConsentDialog, setShowVideoConsentDialog] = useState(false);
  const [isActuallyVideoRecording, setIsActuallyVideoRecording] = useState(false);
  const videoStreamRef = useRef<MediaStream | null>(null);
  const videoRecorderRef = useRef<MediaRecorder | null>(null);
  const videoChunksRef = useRef<Blob[]>([]);
  const [recordedVideoBlob, setRecordedVideoBlob] = useState<Blob | null>(null);
  const [recordedVideoUrl, setRecordedVideoUrl] = useState<string | null>(null);
  const videoElementRef = useRef<HTMLVideoElement>(null);

  const isInitialLoadRef = useRef(true);
  
  const currentWebSpeechUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [isWebSpeechApiSpeaking, setIsWebSpeechApiSpeaking] = useState(false);
  const currentWebSpeechMessageIdRef = useRef<string | null>(null);


  const [allCases, setAllCases] = useState<CaseDoc[]>([]);
  const [isLoadingCases, setIsLoadingCases] = useState(false);
  const [casesError, setCasesError] = useState<string | null>(null);

  const currentModeDetails = chatModes.find(m => m.value === selectedMode);
  const modesRequiringFir = ["witnessStatement", "witnessPreparation", "crimeSceneInvestigation"];
  const [initialContextText, setInitialContextText] = useState<string | undefined>(undefined);


  useEffect(() => {
    const fetchCases = async () => {
      setIsLoadingCases(true);
      setCasesError(null);
      try {
        const casesRef = collection(db, 'cases');
        const q = query(casesRef, orderBy('dateFiled', 'desc'));
        const querySnapshot = await getDocs(q);
        const fetchedCases: CaseDoc[] = [];
        querySnapshot.forEach((doc) => { fetchedCases.push({ id: doc.id, ...doc.data() } as CaseDoc); });
        setAllCases(fetchedCases);
      } catch (err: any) { setCasesError(`Failed to load FIRs. ${err.message}`);
      } finally { setIsLoadingCases(false); }
    };
    fetchCases();
  }, []);

  const scrollToBottom = () => {
    if (scrollAreaRef.current?.lastElementChild) {
       scrollAreaRef.current.lastElementChild.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  };

  useEffect(scrollToBottom, [messages]);
  
  const stopAllWebSpeechTTS = () => {
    if (window.speechSynthesis && currentWebSpeechUtteranceRef.current) {
      window.speechSynthesis.cancel();
    }
    setIsWebSpeechApiSpeaking(false);
    currentWebSpeechMessageIdRef.current = null;
    currentWebSpeechUtteranceRef.current = null;
  };

  const handlePlayTTS = (messageId: string, text: string) => {
    if (!text.trim() || isLoading || !ttsPlaybackEnabledLanguages.includes(selectedLanguage)) {
      if (ttsPlaybackEnabledLanguages.includes(selectedLanguage)) { 
        toast({ variant: "destructive", title: "TTS Issue", description: "Could not play audio." });
      }
      return;
    }

    if (!window.speechSynthesis) {
      toast({ variant: "destructive", title: "TTS Not Supported", description: "Your browser does not support Text-to-Speech." });
      return;
    }
    stopAllWebSpeechTTS(); 

    currentWebSpeechMessageIdRef.current = messageId;
    setIsWebSpeechApiSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = selectedLanguage; 
    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = voices.find(voice => voice.lang === selectedLanguage);
    if (selectedVoice) utterance.voice = selectedVoice;
    
    currentWebSpeechUtteranceRef.current = utterance;
    utterance.onend = () => { setIsWebSpeechApiSpeaking(false); currentWebSpeechMessageIdRef.current = null; currentWebSpeechUtteranceRef.current = null; };
    utterance.onerror = (event) => {
      toast({ variant: "destructive", title: "Web API TTS Error", description: event.error || "Could not play audio." });
      setIsWebSpeechApiSpeaking(false); currentWebSpeechMessageIdRef.current = null; currentWebSpeechUtteranceRef.current = null;
    };
    window.speechSynthesis.speak(utterance);
  };
  
  const fetchGreetingAndInitiateChat = async (mode: ChatMode, language: string, currentFirNum: string) => {
    if (isLoading) return; setIsLoading(true);
    try {
      const aiInput: AiChatComplaintInput = {
        userInput: '', chatHistory: '', language: language.split('-')[0], 
        mode: mode, firNumber: (modesRequiringFir.includes(mode)) ? currentFirNum : undefined,
        isGreetingRequest: true,
      };
      const result: AiChatComplaintOutput = await aiChatComplaint(aiInput);
      const aiGreetingMessage: Message = {
        id: Date.now().toString(), text: result.response, sender: 'ai', timestamp: new Date(),
      };
      setMessages([aiGreetingMessage]);
      if (result.response.trim() && ttsPlaybackEnabledLanguages.includes(language)) {
        handlePlayTTS(aiGreetingMessage.id, result.response);
      }
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: "Failed to get AI greeting." });
      const fallbackGreeting: Message = {
        id: Date.now().toString(),
        text: language.startsWith('hi') ? "नमस्ते! मैं आपकी कैसे सहायता कर सकता हूँ?" : "Hello! How can I assist you?",
        sender: 'ai', timestamp: new Date(),
      }
      setMessages([fallbackGreeting]);
      if (fallbackGreeting.text.trim() && ttsPlaybackEnabledLanguages.includes(language)) {
         handlePlayTTS(fallbackGreeting.id, fallbackGreeting.text);
      }
    } finally { setIsLoading(false); }
  };
  
  const resetAllAudioAndVideoStates = () => {
    if (userSpeechRecorderRef.current && userSpeechRecorderRef.current.state === "recording") userSpeechRecorderRef.current.stop();
    if (asrAudioStreamRef.current) { asrAudioStreamRef.current.getTracks().forEach(track => track.stop()); asrAudioStreamRef.current = null; }
    userSpeechRecorderRef.current = null; currentAudioChunksRef.current = []; setUserAudioClips([]);
    setProcessedUserAudioBlob(null); setProcessedUserAudioBlobUrl(null);

    if (videoRecorderRef.current && videoRecorderRef.current.state === "recording") videoRecorderRef.current.stop();
    if (videoStreamRef.current) { videoStreamRef.current.getTracks().forEach(track => track.stop()); videoStreamRef.current = null; }
    videoRecorderRef.current = null; videoChunksRef.current = []; setIsActuallyVideoRecording(false);
    setRecordedVideoBlob(null); setRecordedVideoUrl(null);
    setVideoRecordingConsent('pending');
  };

  const initiateChatSession = async () => {
    if (isLoading) return;
    if (selectedMode === 'crimeSceneInvestigation') {
      // Handled by sendInitialAIMessageAndActivate
    } else if (messages.length === 0) {
      await fetchGreetingAndInitiateChat(selectedMode, selectedLanguage, firNumber);
    }
  };
  
  const handleVideoConsentResponse = async (consent: 'granted' | 'denied') => {
    setShowVideoConsentDialog(false);
    setVideoRecordingConsent(consent);
    if (consent === 'granted') {
      try {
        videoStreamRef.current = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (videoElementRef.current) { videoElementRef.current.srcObject = videoStreamRef.current; }
        
        videoChunksRef.current = [];
        const options = { mimeType: 'video/webm;codecs=vp8,opus' };
        let recorder;
        try { recorder = new MediaRecorder(videoStreamRef.current, options); } 
        catch (e) {
          try { recorder = new MediaRecorder(videoStreamRef.current); } 
          catch (e2) {
            toast({variant: "destructive", title: "Video Recording Error", description: "MediaRecorder not supported."});
            if (videoStreamRef.current) videoStreamRef.current.getTracks().forEach(track => track.stop()); videoStreamRef.current = null;
            setVideoRecordingConsent('denied');
            await initiateChatSession(); 
            return;
          }
        }
        videoRecorderRef.current = recorder;
        videoRecorderRef.current.ondataavailable = (event) => { if (event.data.size > 0) videoChunksRef.current.push(event.data); };
        videoRecorderRef.current.onstop = () => {
          if (videoChunksRef.current.length > 0) {
            const videoBlob = new Blob(videoChunksRef.current, { type: videoRecorderRef.current?.mimeType || 'video/webm' });
            setRecordedVideoBlob(videoBlob); setRecordedVideoUrl(URL.createObjectURL(videoBlob));
          } else { setRecordedVideoBlob(null); setRecordedVideoUrl(null); }
          setIsActuallyVideoRecording(false); videoChunksRef.current = [];
          if (videoStreamRef.current) { videoStreamRef.current.getTracks().forEach(track => track.stop()); videoStreamRef.current = null; }
          if (videoElementRef.current) { videoElementRef.current.srcObject = null; }
        };
        videoRecorderRef.current.start(); setIsActuallyVideoRecording(true);
        toast({ title: "Video Recording Started", description: "Session video recording active. This will be stored in the case file." });
      } catch (err) {
        toast({ variant: "destructive", title: "Camera/Mic Error", description: "Video recording could not start. Check permissions." });
        setVideoRecordingConsent('denied');
      }
    }
    await initiateChatSession();
  };

  useEffect(() => {
    setConversationEnded(false); setFinalFirNumber(''); setInput('');
    resetAllAudioAndVideoStates();
    setExtractedUserSummary(null); setIsExtractingSummary(false);
    if (!modesRequiringFir.includes(selectedMode)) { setFirNumber(''); setSelectedCaseId(null); }
    stopAllWebSpeechTTS();
    if (asrRecognitionRef.current && isAsrRecording) { asrRecognitionRef.current.stop(); setIsAsrRecording(false); asrInterimTranscriptRef.current = ''; }
    
    setMessages([]);
    if (isInitialLoadRef.current) { isInitialLoadRef.current = false; return; }
    if (isLoading) return; 
    
    const shouldAskForVideo = videoRecordingConsent === 'pending' && 
                              ((modesRequiringFir.includes(selectedMode) && firNumber.trim()) || !modesRequiringFir.includes(selectedMode));
    
    if (shouldAskForVideo && selectedMode !== 'crimeSceneInvestigation') {
      setShowVideoConsentDialog(true);
    } else if (shouldAskForVideo && selectedMode === 'crimeSceneInvestigation') {
      // For CSI, consent is asked when "Start AI Guidance" is clicked
    } else if (videoRecordingConsent !== 'pending') {
      initiateChatSession();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMode, selectedLanguage, firNumber]);


  useEffect(() => {
    return () => {
      stopAllWebSpeechTTS();
      if (asrRecognitionRef.current) asrRecognitionRef.current.stop();
      resetAllAudioAndVideoStates();
      isInitialLoadRef.current = true; 
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSendMessage = async (e?: FormEvent) => {
    if (e) e.preventDefault(); if (!input.trim() && !attachment) return;
    if (modesRequiringFir.includes(selectedMode) && !firNumber.trim()) {
      toast({ variant: "destructive", title: "FIR Number Required" }); return;
    }
    if (videoRecordingConsent === 'pending' && selectedMode !== 'crimeSceneInvestigation') {
      setShowVideoConsentDialog(true);
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(), text: input, sender: 'user', timestamp: new Date(),
      attachmentName: attachment?.name, attachmentType: attachment?.type,
    };
    setMessages((prev) => [...prev, userMessage]);
    const currentInput = input; const currentAttachment = attachment;
    setInput(''); setAttachment(null); if (fileInputRef.current) fileInputRef.current.value = '';
    setIsLoading(true);

    try {
      let documentPayload: AiChatComplaintInput['document'];
      if (currentAttachment) {
        const dataUriFromFile = await blobToDataURL(currentAttachment);
        documentPayload = { dataUri: dataUriFromFile, contentType: currentAttachment.type || 'application/octet-stream' };
      }
      const allMessagesForHistory = [...messages, userMessage]; 
      const chatHistoryForAI = allMessagesForHistory.map(msg => {
        let historyLine = `${msg.sender === 'user' ? 'User' : 'AI'}: ${msg.text}`;
        if (msg.attachmentName) historyLine += ` (Attachment: ${msg.attachmentName})`;
        return historyLine;
      }).join('\n');
      const aiInput: AiChatComplaintInput = {
        userInput: currentInput, document: documentPayload, chatHistory: chatHistoryForAI, 
        language: selectedLanguage.split('-')[0], 
        mode: selectedMode, firNumber: (modesRequiringFir.includes(selectedMode)) ? firNumber : undefined,
        isGreetingRequest: false, 
      };
      const result: AiChatComplaintOutput = await aiChatComplaint(aiInput);
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(), text: result.response, sender: 'ai', timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMessage]);
      if (result.response.trim() && ttsPlaybackEnabledLanguages.includes(selectedLanguage)) {
        handlePlayTTS(aiMessage.id, result.response);
      }
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: "Failed to get AI response." });
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(), text: "Sorry, I couldn't process. Try again.", sender: 'ai', timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
      if (errorMessage.text.trim() && ttsPlaybackEnabledLanguages.includes(selectedLanguage)) {
        handlePlayTTS(errorMessage.id, errorMessage.text);
      }
    } finally { setIsLoading(false); }
  };

  const handleAttachmentChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { 
         toast({ variant: "destructive", title: "File Too Large", description: "Max 5MB." }); return;
      }
      setAttachment(file);
    }
  };

  const toggleAsrRecording = async () => {
    if (videoRecordingConsent === 'pending' && selectedMode !== 'crimeSceneInvestigation') {
        setShowVideoConsentDialog(true); return;
    }
    if (isAsrRecording) {
      asrRecognitionRef.current?.stop(); 
      if (userSpeechRecorderRef.current && userSpeechRecorderRef.current.state === "recording") userSpeechRecorderRef.current.stop();
      return;
    }
    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast({ variant: "destructive", title: "ASR Not Supported" }); return;
    }
    try {
      asrAudioStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      currentAudioChunksRef.current = [];
      const options = { mimeType: 'audio/webm;codecs=opus' };
      let recorder;
      try { recorder = new MediaRecorder(asrAudioStreamRef.current, options); }
      catch (e) { 
        try { recorder = new MediaRecorder(asrAudioStreamRef.current); }
        catch (e2) {
          toast({ variant: "destructive", title: "Recording Error", description: "MediaRecorder not supported." });
          if (asrAudioStreamRef.current) { asrAudioStreamRef.current.getTracks().forEach(track => track.stop()); asrAudioStreamRef.current = null; } return;
        }
      }
      userSpeechRecorderRef.current = recorder;
      userSpeechRecorderRef.current.ondataavailable = (event) => { if (event.data.size > 0) currentAudioChunksRef.current.push(event.data); };
      userSpeechRecorderRef.current.onstop = () => {
        if (currentAudioChunksRef.current.length > 0) {
          const audioBlob = new Blob(currentAudioChunksRef.current, { type: userSpeechRecorderRef.current?.mimeType || 'audio/webm' });
          setUserAudioClips(prev => [...prev, audioBlob]);
          currentAudioChunksRef.current = [];
        }
        if (asrAudioStreamRef.current) { asrAudioStreamRef.current.getTracks().forEach(track => track.stop()); asrAudioStreamRef.current = null; }
      };
      userSpeechRecorderRef.current.start();

      asrRecognitionRef.current = new SpeechRecognition(); const recognition = asrRecognitionRef.current;
      recognition.continuous = true; recognition.interimResults = true; recognition.lang = selectedLanguage;
      let currentFinalTranscript = input; asrInterimTranscriptRef.current = '';
      recognition.onresult = (event) => {
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            const finalChunk = event.results[i][0].transcript;
            currentFinalTranscript += (currentFinalTranscript.endsWith(' ') || finalChunk.startsWith(' ') ? '' : ' ') + finalChunk;
            asrInterimTranscriptRef.current = ''; 
          } else { interimTranscript += event.results[i][0].transcript; }
        }
        asrInterimTranscriptRef.current = interimTranscript; setInput(currentFinalTranscript + asrInterimTranscriptRef.current);
      };
      recognition.onerror = (event) => {
        toast({ variant: "destructive", title: "ASR Error", description: event.error || "Speech recognition failed." });
        if (userSpeechRecorderRef.current && userSpeechRecorderRef.current.state === "recording") userSpeechRecorderRef.current.stop();
        setIsAsrRecording(false);
      };
      recognition.onend = () => {
        if (userSpeechRecorderRef.current && userSpeechRecorderRef.current.state === "recording") userSpeechRecorderRef.current.stop();
        if (asrInterimTranscriptRef.current.trim()) {
            setInput(prev => {
                const base = prev.replace(asrInterimTranscriptRef.current, '').trim();
                return (base + (base.endsWith(' ') || asrInterimTranscriptRef.current.trim().startsWith(' ') ? '' : ' ') + asrInterimTranscriptRef.current.trim()).trim();
            });
        }
        asrInterimTranscriptRef.current = ''; setIsAsrRecording(false);
      };
      recognition.start(); setIsAsrRecording(true);
    } catch (err) {
      toast({ variant: "destructive", title: "Mic/Recording Error", description: "Could not access mic or start recording." });
      if (asrAudioStreamRef.current) { asrAudioStreamRef.current.getTracks().forEach(track => track.stop()); asrAudioStreamRef.current = null; }
      setIsAsrRecording(false);
    }
  };

  const handleEndConversation = async () => {
    setConversationEnded(true);
    stopAllWebSpeechTTS();
    if (asrRecognitionRef.current && isAsrRecording) { asrRecognitionRef.current.stop(); }
    if (userSpeechRecorderRef.current && userSpeechRecorderRef.current.state === "recording") { userSpeechRecorderRef.current.stop(); }
    if (videoRecorderRef.current && videoRecorderRef.current.state === "recording") { videoRecorderRef.current.stop(); }

    setFinalFirNumber(firNumber);
    
    if (userAudioClips.length > 0) {
      try {
        const combinedBlob = new Blob(userAudioClips, { type: userAudioClips[0].type });
        setProcessedUserAudioBlob(combinedBlob); setProcessedUserAudioBlobUrl(URL.createObjectURL(combinedBlob));
        toast({ title: "User Audio Processed", description: "User voice inputs combined." });
      } catch (e) {
        toast({ variant: "destructive", title: "Audio Combination Error" });
        setProcessedUserAudioBlob(null); setProcessedUserAudioBlobUrl(null);
      }
    } else { setProcessedUserAudioBlob(null); setProcessedUserAudioBlobUrl(null); }

    if (messages.length > 0) {
        setIsExtractingSummary(true); setExtractedUserSummary(null);
        const summaryTitleText = selectedMode === 'witnessStatement' ? "Summary of Witness Input" : "Summary of Your Input";
        toast({ title: `Processing ${summaryTitleText}`, description: `Generating ${summaryTitleText.toLowerCase()}...` });
        try {
            const fullConversationTranscript = messages
                .map(msg => {
                    // Regex to remove timestamps like (MM/DD/YY, HH:MM AM/PM): or (DD-MM-YYYY, HH:MM:SS):
 return `${msg.sender === 'user' ? 'User' : 'AI Assistant'}: ${msg.text}`;
                })
                .join('\n');

            if (fullConversationTranscript.trim().length > 0) { // Check if transcript is not empty after cleaning
                const extractInput: ExtractFirDetailsInput = { 
                  complaintTranscript: fullConversationTranscript,
                  language: selectedLanguage.split('-')[0] 
                };
                const extractedOutput: ExtractFirDetailsOutput = await extractFirDetailsFromTranscript(extractInput);
                
                if (extractedOutput && extractedOutput.complaintStatement) {
                    setExtractedUserSummary(extractedOutput.complaintStatement);
                    toast({ title: `${summaryTitleText} Generated`, description: `Review the ${summaryTitleText.toLowerCase()}.` });
                } else {
                    setExtractedUserSummary(`AI could not generate a summary from the conversation.`);
                    toast({ variant: "warning", title: `${summaryTitleText} Generation Issue` });
                }
            } else {
                setExtractedUserSummary("No conversation took place to summarize.");
                toast({ title: "No Conversation", description: "Cannot generate summary without a conversation." });
            }
        } catch (error) {
            console.error(`Error generating ${summaryTitleText.toLowerCase()}:`, error);
            toast({ variant: "destructive", title: `${summaryTitleText} Generation Failed` });
            setExtractedUserSummary(`Error during ${summaryTitleText.toLowerCase()} generation.`);
        } finally { setIsExtractingSummary(false); }
    } else { toast({ title: "Conversation Ended", description: "Review recordings (if any)." }); }
  };

  const handleDownloadTextTranscript = () => {
    const transcriptText = messages.map(msg => {
      let header = `${msg.sender === 'user' ? 'User' : 'NyayaSahayak AI'} (${msg.timestamp.toLocaleString([], {dateStyle: 'short', timeStyle: 'short'})}):`;
      if (msg.attachmentName) header += ` [Attached: ${msg.attachmentName} (${msg.attachmentType || 'unknown type'})]`;
      return `${header}\n${msg.text}\n`;
    }).join('\n---\n');
    const blob = new Blob([transcriptText], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob);
    link.download = `NyayaSahayak_Transcript_${selectedMode}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link); link.click(); document.body.removeChild(link);
    toast({ title: "Text Transcript Downloaded" });
  };

  const handleDownloadUserSummary = () => {
    if (!extractedUserSummary) return;
    const summaryFileTitle = selectedMode === 'witnessStatement' ? "Summary_of_Witness_Input" : "Summary_of_User_Input";
    const blob = new Blob([extractedUserSummary], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob);
    link.download = `${summaryFileTitle}_${finalFirNumber || selectedMode}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link); link.click(); document.body.removeChild(link);
    toast({ title: `${selectedMode === 'witnessStatement' ? "Witness Input Summary" : "User Input Summary"} Downloaded` });
  };
  
  const handleSaveToCase = async () => {
    if (!user || profileLoading) { 
        toast({ variant: "destructive", title: "User Info Loading or Not Logged In", description: "Please wait or log in." }); 
        return; 
    }

    if (messages.length === 0 && !processedUserAudioBlob && !recordedVideoBlob) {
        toast({ variant: "destructive", title: "Cannot Save", description: "Empty transcript & recordings." }); return;
    }
    setIsSaving(true);
    const flowMessages: FlowMessage[] = messages.map(m => ({
      id: m.id, text: m.text, sender: m.sender, timestamp: m.timestamp.toISOString(),
      attachmentName: m.attachmentName, attachmentType: m.attachmentType,
    }));
    
    let audioDetailsPayload: SaveComplaintInput['audioDetails'];
    if (processedUserAudioBlob) {
        try {
            const dataUri = await blobToDataURL(processedUserAudioBlob);
            audioDetailsPayload = {
                dataUri: dataUri,
                fileName: `user_speech_${Date.now()}.${processedUserAudioBlob.type.split('/')[1] || 'webm'}`,
                contentType: processedUserAudioBlob.type || 'audio/webm',
            };
        } catch (error) { toast({variant: "destructive", title: "Audio Error", description: "Could not process user audio."}); setIsSaving(false); return; }
    }

    let videoDetailsPayload: SaveComplaintInput['videoDetails'];
    if (recordedVideoBlob) {
        try {
            const dataUri = await blobToDataURL(recordedVideoBlob);
            videoDetailsPayload = {
                dataUri: dataUri,
                fileName: `session_video_${Date.now()}.${recordedVideoBlob.type.split('/')[1] || 'webm'}`,
                contentType: recordedVideoBlob.type || 'video/webm',
            };
        } catch (error) { toast({variant: "destructive", title: "Video Error", description: "Could not process video recording."}); setIsSaving(false); return; }
    }

    let activityTypeDescription = `${currentModeDetails?.label || 'Chat Session'} logged.`;
    if (selectedMode === 'witnessStatement' && finalFirNumber) {
        activityTypeDescription = `Witness Statement for FIR ${finalFirNumber} logged.`;
    } else if (selectedMode === 'crimeSceneInvestigation' && finalFirNumber) {
        activityTypeDescription = `Crime Scene Guidance for FIR ${finalFirNumber} logged.`;
    } else if (finalFirNumber) {
        activityTypeDescription = `${currentModeDetails?.label || 'Chat Session'} for FIR/ID ${finalFirNumber} logged.`;
    } else {
        activityTypeDescription = `${currentModeDetails?.label || 'Chat Session'} logged. New Complaint ID will be: (auto-generated)`;
    }

    const inputForFlow: SaveComplaintInput = {
      complaintId: finalFirNumber.trim() || undefined, 
      messages: flowMessages.length > 0 ? flowMessages : undefined,
      englishSummary: (selectedMode === 'complaintRecording' && extractedUserSummary) ? extractedUserSummary : undefined,
      audioDetails: audioDetailsPayload,
      videoDetails: videoDetailsPayload,
      userId: user.uid, 
      officerStationName: user.profile?.stationName || undefined,
      officerDistrict: user.profile?.district || undefined,
      activityType: activityTypeDescription,
      caseReferenceId: selectedCaseId || undefined, 
    };
    try {
      const result = await saveComplaint(inputForFlow);
      if (result.success) {
        toast({ title: "Case Saved", description: `Complaint ID: ${result.complaintId}.` });
        setConversationEnded(false); setMessages([]); setFinalFirNumber(''); setInput('');
        resetAllAudioAndVideoStates(); isInitialLoadRef.current = true; 
        setExtractedUserSummary(null); setIsExtractingSummary(false);
        if ((modesRequiringFir.includes(selectedMode) && firNumber.trim()) || !modesRequiringFir.includes(selectedMode)) {
            setMessages([]); isInitialLoadRef.current = false; 
        } else { setMessages([]); }
      } else { toast({ variant: "destructive", title: "Save Failed", description: result.error || result.message }); }
    } catch (error: any) { toast({ variant: "destructive", title: "Error Saving Case", description: error.message });
    } finally { setIsSaving(false); }
  };

  const summaryTitle = selectedMode === 'witnessStatement' ? "Summary of Witness Input" : "Summary of Your Input";
  const summaryDownloadButtonLabel = selectedMode === 'witnessStatement' ? "Download Witness Input Summary" : "Download User Input Summary";

  const handleStartCsiGuidance = () => {
    const relatedCase = allCases.find(c => c.firNumber === firNumber);
    setInitialContextText(relatedCase?.complaintStatement || relatedCase?.title);
    
    if (videoRecordingConsent === 'pending') {
      setShowVideoConsentDialog(true);
    } else {
      sendInitialCsiMessageAndActivate();
    }
  };

  const sendInitialCsiMessageAndActivate = async () => {
    if (isLoading || !firNumber) return;
    setIsLoading(true); setMessages([]); 
    let greetingUserInput = `Start guiding me for the crime scene investigation of FIR: ${firNumber} (Case: "${allCases.find(c => c.firNumber === firNumber)?.title || 'Untitled Case'}").`;
    if (initialContextText) greetingUserInput += `\n\nRelevant context: "${initialContextText}"\n\nBased on this, what should I focus on?`;
    else greetingUserInput += `\nWhat are the general first steps?`;
    
    try {
      const aiInput: AiChatComplaintInput = {
        userInput: greetingUserInput, chatHistory: '', language: selectedLanguage.split('-')[0], 
        mode: 'crimeSceneInvestigation', firNumber: firNumber, isGreetingRequest: false,
      };
      const result: AiChatComplaintOutput = await aiChatComplaint(aiInput);
      const aiMessage: Message = { id: Date.now().toString(), text: result.response, sender: 'ai', timestamp: new Date() };
      setMessages([aiMessage]);
      if (result.response.trim() && ttsPlaybackEnabledLanguages.includes(selectedLanguage)) {
        handlePlayTTS(aiMessage.id, result.response);
      }
    } catch (error) {
      toast({ variant: "destructive", title: "AI Error", description: "Failed to get initial guidance." });
      setMessages([{ id: Date.now().toString(), text: "Sorry, error initializing. Try sending a message.", sender: 'ai', timestamp: new Date() }]);
    } finally { setIsLoading(false); }
  };
  
  useEffect(() => {
    if (videoElementRef.current && videoStreamRef.current && isActuallyVideoRecording) {
      videoElementRef.current.srcObject = videoStreamRef.current;
    }
  }, [isActuallyVideoRecording]);


  return (
    <div className="h-[calc(100vh-10rem)] flex flex-col">
      <Card className="flex-1 flex flex-col shadow-xl">
        <CardHeader className="border-b pb-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
                {currentModeDetails?.icon && <currentModeDetails.icon className="h-6 w-6 text-primary" />}
                <CardTitle className="font-headline text-2xl">{currentModeDetails?.label || "AI Chat Assistant"}</CardTitle>
            </div>
            { !conversationEnded && (
              <div className="flex items-center gap-1 sm:gap-2 flex-wrap justify-start sm:justify-end w-full sm:w-auto">
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage} disabled={isLoading || (messages.length > 0 && !conversationEnded) || isAsrRecording || isActuallyVideoRecording || showVideoConsentDialog}>
                  <SelectTrigger className="h-9 w-auto text-xs sm:text-sm flex-grow sm:flex-grow-0 sm:w-[160px]"><SelectValue placeholder="Language" /></SelectTrigger>
                  <SelectContent>{chatInterfaceLanguages.map(lang => (<SelectItem key={lang.value} value={lang.value}>{lang.label}</SelectItem>))}</SelectContent>
                </Select>
                <Select value={selectedMode} onValueChange={(value) => setSelectedMode(value as ChatMode)} disabled={isLoading || (messages.length > 0 && !conversationEnded) || isAsrRecording || isActuallyVideoRecording || showVideoConsentDialog}>
                  <SelectTrigger className="h-9 w-auto text-xs sm:text-sm flex-grow sm:flex-grow-0 sm:w-[180px]"><SelectValue placeholder="Mode" /></SelectTrigger>
                  <SelectContent>{chatModes.map(mode => (<SelectItem key={mode.value} value={mode.value}><div className="flex items-center gap-2"><mode.icon className="h-4 w-4" />{mode.label}</div></SelectItem>))}</SelectContent>
                </Select>
                {modesRequiringFir.includes(selectedMode) && (
                   isLoadingCases ? (<div className="h-9 flex items-center text-xs text-muted-foreground"><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading FIRs...</div>)
                   : casesError ? (<div className="h-9 flex items-center text-xs text-destructive">Error loading FIRs.</div>)
                   : (<Select value={firNumber} onValueChange={(value) => {
                        setFirNumber(value); const selected = allCases.find(c => c.firNumber === value); setSelectedCaseId(selected?.id || null);
                      }} disabled={isLoading || (messages.length > 0 && !conversationEnded) || isAsrRecording || isActuallyVideoRecording || allCases.length === 0 || showVideoConsentDialog}>
                        <SelectTrigger className="h-9 w-auto text-xs sm:text-sm flex-grow sm:flex-grow-0 sm:min-w-[200px] max-w-[300px]"><SelectValue placeholder={allCases.length === 0 ? "No FIRs available" : "Select FIR"} /></SelectTrigger>
                        <SelectContent>{allCases.length === 0 ? (<SelectItem value="no-firs" disabled>No FIRs registered yet.</SelectItem>) : (allCases.map(caseDoc => (<SelectItem key={caseDoc.id} value={caseDoc.firNumber!}>{caseDoc.firNumber} - {caseDoc.title}</SelectItem>)))}</SelectContent>
                      </Select>)
                )}
                {messages.length > 0 && (<Button onClick={handleEndConversation} variant="outline" size="sm" className="h-9 px-2 sm:px-3" disabled={isLoading || isExtractingSummary || isAsrRecording || isSaving}><CheckCircle2 className="mr-1 sm:mr-2 h-4 w-4" /><span className="hidden sm:inline">End</span><span className="sm:hidden">End</span></Button>)}
              </div>
            )}
          </div>
          <CardDescription className="mt-2 text-xs sm:text-sm">
            { (messages.length === 0 || conversationEnded) && currentModeDetails && <span className="mr-1">{currentModeDetails.description}</span>}
            Conversation in {chatInterfaceLanguages.find(l => l.value === selectedLanguage)?.label || "English"}. 
            {ttsPlaybackEnabledLanguages.includes(selectedLanguage) ? "TTS available." : "TTS not available for this language."}
            {(modesRequiringFir.includes(selectedMode) && firNumber && !conversationEnded) && ` For FIR: ${firNumber}.`}
            {isAsrRecording && !conversationEnded && <span className="text-green-600 font-medium ml-1">(ASR Recording User Input)</span>}
            {isActuallyVideoRecording && !conversationEnded && <span className="text-red-600 font-medium ml-1">(Session Video Recording Active)</span>}
            {showVideoConsentDialog && <span className="text-blue-600 font-medium ml-1">(Awaiting video preference...)</span>}
          </CardDescription>
          {isActuallyVideoRecording && <video ref={videoElementRef} className="w-24 h-18 rounded-md border bg-black fixed bottom-4 right-4 z-50" autoPlay muted playsInline />}
        </CardHeader>
        
        <AlertDialog open={showVideoConsentDialog} onOpenChange={setShowVideoConsentDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center"><Video className="mr-2 h-5 w-5 text-primary"/> Enable Video Recording?</AlertDialogTitle>
              <AlertDialogDescription>
              We can also record a video of you during this session. This video will capture your spoken statements and facial expressions, ensuring transparency and completeness. Do you want to start recording your video now?
              This video will only be stored in the case file and used for official documentation.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => handleVideoConsentResponse('denied')}>No, Proceed Audio-Only</AlertDialogCancel>
              <AlertDialogAction onClick={() => handleVideoConsentResponse('granted')}>Yes, Start Video Recording</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {conversationEnded ? (
            <CardContent className="flex-1 flex flex-col overflow-hidden">
                 <ScrollArea className="flex-auto p-1">
                    <div className="p-4 space-y-4">
                        <Alert><CheckCircle2 className="h-4 w-4" /><AlertTitle>Session Ended & Processed</AlertTitle>
                        <AlertDescription>
                            {isExtractingSummary ? `Generating ${summaryTitle.toLowerCase()}...` : (extractedUserSummary ? `Review transcript, ${summaryTitle.toLowerCase()}, user audio & video. Save to case file.` : "Review transcript, user audio & video. User input summary generation may have had issues.")}
                        </AlertDescription>
                        </Alert>
                        <div className="border rounded-md p-2 flex flex-col">
                            <h3 className="text-lg font-semibold mb-2">Session Transcript</h3>
                            <ScrollArea className="flex-grow bg-muted/30 p-3 rounded-md mb-4 max-h-60">
                                {messages.map(msg => (<div key={`transcript-${msg.id}`} className="mb-3 text-sm"><p className={`font-semibold ${msg.sender === 'user' ? 'text-primary' : 'text-accent-foreground'}`}>{msg.sender === 'user' ? 'User' : 'NyayaSahayak AI'} ({msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}):{msg.attachmentName && <span className="font-normal text-xs"> (Attachment: {msg.attachmentName})</span>}</p><p className="whitespace-pre-wrap pl-2 text-foreground">{msg.text}</p></div>))}
                                {messages.length === 0 && <p className="text-muted-foreground text-center py-4">No messages.</p>}
                            </ScrollArea>
                            {isExtractingSummary && ( <div className="mb-4 flex items-center text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin mr-2" /> Generating {summaryTitle.toLowerCase()}...</div> )}
                            {extractedUserSummary && !isExtractingSummary && (
                                <div className="mb-4">
                                <h4 className="text-md font-semibold mb-1">{summaryTitle}:</h4>
                                <ScrollArea className="h-32 bg-muted/30 p-3 rounded-md text-sm whitespace-pre-wrap"> {extractedUserSummary} </ScrollArea>
                                </div>
                            )}
                            {processedUserAudioBlobUrl && (<div className="mb-4"><h4 className="text-md font-semibold mb-1">Combined User Voice Input (ASR):</h4><audio src={processedUserAudioBlobUrl} controls className="w-full" /></div>)}
                            {recordedVideoUrl && (
                                <div className="mb-4">
                                    <h4 className="text-md font-semibold mb-1">Full Session Video Recording:</h4>
                                    <video src={recordedVideoUrl} controls className="w-full rounded-md border" />
                                </div>
                            )}
                            <div className="flex flex-wrap gap-2 items-center">
                                <Button onClick={handleDownloadTextTranscript} variant="outline" disabled={messages.length === 0}><Download className="mr-2 h-4 w-4"/> Text Transcript</Button>
                                {extractedUserSummary && !isExtractingSummary && !extractedUserSummary.startsWith("AI could not generate") && !extractedUserSummary.startsWith("Error during summary") && (
                                    <Button onClick={handleDownloadUserSummary} variant="outline"><FileText className="mr-2 h-4 w-4"/> {summaryDownloadButtonLabel}</Button>
                                )}
                                {processedUserAudioBlobUrl && (<Button asChild variant="outline"><a href={processedUserAudioBlobUrl} download={`UserVoiceInput_${selectedMode}_${new Date().toISOString().split('T')[0]}.${processedUserAudioBlob?.type.split('/')[1] || 'webm'}`}><Download className="mr-2 h-4 w-4"/> User Voice (ASR)</a></Button>)}
                                {recordedVideoUrl && (<Button asChild variant="outline"><a href={recordedVideoUrl} download={`NyayaSahayak_Video_Recording_FIR_${finalFirNumber || 'NA'}_${selectedMode}_${new Date().toISOString().split('T')[0]}.webm`}><Download className="mr-2 h-4 w-4"/> Session Video</a></Button>)}
                                <Button onClick={() => { setConversationEnded(false); setExtractedUserSummary(null); setVideoRecordingConsent('pending'); isInitialLoadRef.current = true; if ((modesRequiringFir.includes(selectedMode) && firNumber.trim()) || !modesRequiringFir.includes(selectedMode) ) { setMessages([]); isInitialLoadRef.current = false; } else { setMessages([]); resetAllAudioAndVideoStates(); }}} variant="outline" disabled={isExtractingSummary}><Edit3 className="mr-2 h-4 w-4"/> Resume/New Chat</Button>
                            </div>
                        </div>
                        <Card>
                            <CardHeader><CardTitle className="text-xl">Save to Case File</CardTitle><CardDescription>Enter FIR/Complaint ID. If blank, auto-ID. Transcript, ASR audio & video (if recorded) will be saved.</CardDescription></CardHeader>
                            <CardContent className="space-y-2">
                                <Label htmlFor="final-fir-number">Official FIR Number / Complaint ID (Optional)</Label>
                                <Input id="final-fir-number" value={finalFirNumber} onChange={(e) => setFinalFirNumber(e.target.value)} placeholder="E.g., CR-STN-YYYY-NNNNN or leave blank"/>
                            </CardContent>
                            <CardFooter><Button onClick={handleSaveToCase} disabled={isSaving || isExtractingSummary || (messages.length === 0 && !processedUserAudioBlob && !recordedVideoBlob) || profileLoading }>{(isSaving || isExtractingSummary) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}<Save className="mr-2 h-4 w-4" /> Save Data</Button></CardFooter>
                        </Card>
                    </div>
                </ScrollArea>
            </CardContent>
        ) : (
            <CardContent className="flex-1 flex flex-col overflow-hidden p-0">
            {selectedMode === 'crimeSceneInvestigation' && messages.length === 0 && videoRecordingConsent !== 'pending' && !isLoading && (
              <div className="p-4 border-b flex flex-col items-center justify-center">
                <Button onClick={handleStartCsiGuidance} disabled={isLoading || !firNumber || showVideoConsentDialog}>
                  <Play className="mr-2 h-4 w-4" /> Start AI Guidance for FIR: {firNumber}
                </Button>
                <p className="text-xs text-muted-foreground mt-1">AI will guide you through crime scene documentation.</p>
              </div>
            )}
            <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
                <div className="space-y-4">
                {messages.length === 0 && !isLoading && videoRecordingConsent !== 'pending' && selectedMode !== 'crimeSceneInvestigation' && (<div className="text-center text-muted-foreground py-10"><MessageCircle size={48} className="mx-auto mb-2" /><p>{ (modesRequiringFir.includes(selectedMode)) && !firNumber.trim() ? "Select FIR to begin." : "AI is ready. Type your message or use the mic."}</p></div>)}
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                    {msg.sender === 'ai' && (<Avatar className="h-8 w-8 self-start"><AvatarFallback><Bot size={20} /></AvatarFallback></Avatar>)}
                    <div className={`max-w-[70%] rounded-lg p-3 shadow-md flex flex-col ${msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`}>
                        <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                        {msg.attachmentName && (<div className="mt-2 text-xs opacity-80 flex items-center"><Paperclip size={12} className="mr-1" /> {msg.attachmentName} ({msg.attachmentType || 'unknown'})</div>)}
                        <div className="flex justify-between items-center mt-1">
                            <p className={`text-xs ${msg.sender === 'user' ? 'text-primary-foreground/80' : 'text-muted-foreground/80'} `}>{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                            {msg.sender === 'ai' && msg.text.trim() && ttsPlaybackEnabledLanguages.includes(selectedLanguage) && (
                                <Button variant="ghost" size="icon" className={`h-6 w-6 p-0 ml-2 ${currentWebSpeechMessageIdRef.current === msg.id && isWebSpeechApiSpeaking ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`} onClick={() => handlePlayTTS(msg.id, msg.text)} title={currentWebSpeechMessageIdRef.current === msg.id && isWebSpeechApiSpeaking ? "Stop" : "Play"}>
                                    {currentWebSpeechMessageIdRef.current === msg.id && isWebSpeechApiSpeaking ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                                </Button>
                            )}
                        </div>
                    </div>
                    {msg.sender === 'user' && (<Avatar className="h-8 w-8"><AvatarFallback><User size={20} /></AvatarFallback></Avatar>)}
                    </div>
                ))}
                {isLoading && messages.length === 0 && ( <div className="flex justify-center items-center p-10"><Loader2 className="h-12 w-12 animate-spin text-primary" /><p className="ml-4 text-muted-foreground">AI preparing...</p></div>)}
                {isLoading && messages.length > 0 && ( <div className="flex items-end gap-2"><Avatar className="h-8 w-8"><AvatarFallback><Bot size={20} /></AvatarFallback></Avatar><div className="max-w-[70%] rounded-lg p-3 shadow-md bg-muted"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div></div>)}
                </div>
            </ScrollArea>
            <form onSubmit={handleSendMessage} className="border-t p-4 bg-background">
                {attachment && (<div className="mb-2 text-sm text-muted-foreground flex items-center"><Paperclip size={16} className="mr-2" /><span>{attachment.name}</span><Button variant="ghost" size="sm" className="ml-2 h-6 w-6 p-0" onClick={() => { setAttachment(null); if(fileInputRef.current) fileInputRef.current.value = ''; }}><FileX2 className="h-4 w-4" /></Button></div>)}
                <div className="flex items-center gap-2">
                <Button type="button" variant="outline" size="icon" onClick={() => fileInputRef.current?.click()} title="Attach file" disabled={isLoading || conversationEnded || videoRecordingConsent === 'pending' || showVideoConsentDialog }><Paperclip className="h-5 w-5" /><span className="sr-only">Attach</span></Button>
                <input type="file" ref={fileInputRef} onChange={handleAttachmentChange} className="hidden" />
                <Button type="button" variant={isAsrRecording ? "destructive" : "outline"} size="icon" onClick={toggleAsrRecording} title={isAsrRecording ? "Stop ASR & User Voice Recording" : "Start ASR & User Voice Recording"} disabled={isLoading || conversationEnded || videoRecordingConsent === 'pending' || showVideoConsentDialog || (modesRequiringFir.includes(selectedMode) && !firNumber.trim() && messages.length === 0)}>{isAsrRecording ? <Square className="h-5 w-5" /> : <Mic className="h-5 w-5" />}<span className="sr-only">{isAsrRecording ? "Stop" : "ASR"}</span></Button>
                <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder={(modesRequiringFir.includes(selectedMode) && !firNumber.trim() && messages.length === 0 && selectedMode !== 'crimeSceneInvestigation') ? "Select FIR first..." : (showVideoConsentDialog ? "Please respond to video prompt..." : "Type message...")} className="flex-1 resize-none" rows={1} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage();}}} disabled={isLoading || conversationEnded || videoRecordingConsent === 'pending' || showVideoConsentDialog || (modesRequiringFir.includes(selectedMode) && !firNumber.trim() && messages.length === 0 && selectedMode !== 'crimeSceneInvestigation') || (selectedMode === 'crimeSceneInvestigation' && messages.length === 0 && !isLoading)} />
                <Button type="submit" disabled={isLoading || conversationEnded || videoRecordingConsent === 'pending' || showVideoConsentDialog || (!input.trim() && !attachment) || (modesRequiringFir.includes(selectedMode) && !firNumber.trim() && messages.length === 0 && selectedMode !== 'crimeSceneInvestigation') || (selectedMode === 'crimeSceneInvestigation' && messages.length === 0 && !isLoading)} title="Send"><Send className="h-5 w-5" /><span className="sr-only">Send</span></Button>
                </div>
            </form>
            </CardContent>
        )}
      </Card>
    </div>
  );
}
