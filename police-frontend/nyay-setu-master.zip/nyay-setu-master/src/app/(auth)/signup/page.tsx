
"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createUserWithEmailAndPassword, signInWithPopup, updateProfile as updateAuthProfile } from 'firebase/auth';
import { auth, googleProvider, db } from '@/lib/firebase';
import { doc, setDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Chrome, UserPlus, Building, Briefcase, Shield, Hash, UserSquare } from 'lucide-react';
import type { UserProfile } from '@/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Simplified list for example, replace with your actual dynamic lists or fetched data
const districtOptions = ["District A", "District B", "Eluru", "Another District"];
const eluruPoliceStations = [
    "Eluru I Town", "Eluru II Town", "Eluru III Town", "Eluru Rural", "Women Eluru", "Traffic Eluru",
    "Denduluru", "Pedavegi", "Polavaram", "Koyyalagudem", "Chintalapudi", "Jeelugumilli",
    "Nuzvid Rural", "Nuzvid Town", "Kaikaluru Rural", "Kaikaluru Town", "Kalidindi", "Mandavalli",
    "Mudinepalli", "Ganapavaram", "Chebrole", "Dwaraka Tirumala", "Lakkavaram", "Tadikala Pudi",
    "Nidamarru", "Buttaigudem", "Agiripalli", "Musunur", "Chatrai", "T Narasapuram",
    "Dharmajigudem", "Kukunoor", "Velairpad", "Special Branch Eluru", "CCS Eluru"
  ];
const policeStationOptions: { [key: string]: string[] } = {
    "District A": ["PS A1", "PS A2"],
    "District B": ["PS B1", "PS B2"],
    "Eluru": eluruPoliceStations,
    "Another District": ["PS C1"],
    "": [] 
};
const rankOptions = ["Constable", "Head Constable", "ASI", "SI", "Inspector", "DSP", "ASP", "SP"];


export default function SignupPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [stationName, setStationName] = useState('');
  const [district, setDistrict] = useState('');
  const [rank, setRank] = useState('');
  const [badgeNumber, setBadgeNumber] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast({ variant: "destructive", title: 'Signup Failed', description: 'Passwords do not match.' });
      return;
    }
    if (!displayName.trim() || !district.trim() || !stationName.trim() || !rank.trim()) {
      toast({ variant: "destructive", title: 'Signup Failed', description: 'Please fill in all required profile fields (Name, District, Station, Rank).' });
      return;
    }
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Update Firebase Auth profile (optional, but good for display name consistency)
      await updateAuthProfile(user, { displayName: displayName.trim() });

      // Create user profile document in Firestore
      const userProfileData: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: displayName.trim(),
        stationName: stationName.trim(),
        district: district.trim(),
        rank: rank.trim(),
        badgeNumber: badgeNumber.trim() || null,
        employeeId: employeeId.trim() || null,
        role: 'officer', // Default role
        createdAt: serverTimestamp() as Timestamp,
        updatedAt: serverTimestamp() as Timestamp,
        // Optional fields can be null or omitted if not collected
        phoneNumber: null,
        profilePhotoUrl: null,
        address: null,
      };
      await setDoc(doc(db, 'users', user.uid), userProfileData);

      toast({ title: 'Signup Successful', description: 'Profile created. Redirecting to dashboard...' });
      router.push('/dashboard');
    } catch (error: any) {
      toast({ variant: "destructive", title: 'Signup Failed', description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignup = async () => {
    setGoogleLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;

      // Check if user profile already exists (e.g., from a previous Google sign-in)
      const userDocRef = doc(db, 'users', user.uid);
      const userDocSnap = await getDoc(userDocRef);

      if (!userDocSnap.exists()) {
        // For Google Sign-up, we typically don't have station/rank etc. immediately.
        // We can either redirect to a "complete profile" page or create a basic profile.
        // For now, create a basic profile and they can update in settings.
        const basicUserProfile: UserProfile = {
          uid: user.uid,
          email: user.email || '',
          displayName: user.displayName || user.email?.split('@')[0] || 'Google User',
          profilePhotoUrl: user.photoURL || null,
          role: 'officer', // Default role
          createdAt: serverTimestamp() as Timestamp,
          updatedAt: serverTimestamp() as Timestamp,
          // Other fields will be null or default
          stationName: null,
          district: null,
          rank: null,
          badgeNumber: null,
          employeeId: null,
          phoneNumber: user.phoneNumber || null,
          address: null,
        };
        await setDoc(doc(db, 'users', user.uid), basicUserProfile);
        toast({ title: 'Google Signup Successful', description: 'Basic profile created. Please complete your details in Settings. Redirecting...' });
      } else {
        toast({ title: 'Welcome Back!', description: 'Logged in with Google. Redirecting...' });
      }
      
      router.push('/dashboard');
    } catch (error: any) {
      toast({ variant: "destructive", title: 'Google Signup Failed', description: error.message });
    } finally {
      setGoogleLoading(false);
    }
  };
  
  const handleDistrictChange = (value: string) => {
    setDistrict(value);
    setStationName(''); // Reset station when district changes
  };


  return (
    <div className="space-y-4 md:space-y-6">
      <div className="text-center">
        <h1 className="text-xl md:text-2xl font-bold text-foreground font-headline flex items-center justify-center">
            <UserPlus className="mr-2 h-6 w-6"/>Create NyayaSahayak Account
        </h1>
        <p className="text-sm text-muted-foreground">Join to streamline your police work.</p>
      </div>
      <form onSubmit={handleSignup} className="space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="displayName">Full Name <span className="text-destructive">*</span></Label>
              <Input id="displayName" value={displayName} onChange={(e) => setDisplayName(e.target.value)} required placeholder="Your full name" />
            </div>
            <div>
              <Label htmlFor="email">Email Address <span className="text-destructive">*</span></Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="you@example.com" />
            </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="district">District <span className="text-destructive">*</span></Label>
                <Select value={district} onValueChange={handleDistrictChange} required>
                    <SelectTrigger id="district"><SelectValue placeholder="Select District" /></SelectTrigger>
                    <SelectContent>
                        {districtOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
            <div>
              <Label htmlFor="stationName">Police Station <span className="text-destructive">*</span></Label>
                <Select value={stationName} onValueChange={setStationName} required disabled={!district}>
                    <SelectTrigger id="stationName"><SelectValue placeholder="Select Police Station" /></SelectTrigger>
                    <SelectContent>
                        {(policeStationOptions[district] || []).map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <Label htmlFor="rank">Rank <span className="text-destructive">*</span></Label>
                <Select value={rank} onValueChange={setRank} required>
                    <SelectTrigger id="rank"><SelectValue placeholder="Select Rank" /></SelectTrigger>
                    <SelectContent>
                        {rankOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
            <div>
              <Label htmlFor="badgeNumber">Badge Number</Label>
              <Input id="badgeNumber" value={badgeNumber} onChange={(e) => setBadgeNumber(e.target.value)} placeholder="Your badge number" />
            </div>
            <div>
              <Label htmlFor="employeeId">Employee ID</Label>
              <Input id="employeeId" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} placeholder="Your employee ID" />
            </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label htmlFor="password">Password <span className="text-destructive">*</span></Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required placeholder="••••••••" />
            </div>
            <div>
              <Label htmlFor="confirmPassword">Confirm Password <span className="text-destructive">*</span></Label>
              <Input id="confirmPassword" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required placeholder="••••••••" />
            </div>
        </div>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Create Account
        </Button>
      </form>
      <div className="relative my-3">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">
            Or sign up with
          </span>
        </div>
      </div>
      <Button variant="outline" className="w-full" onClick={handleGoogleSignup} disabled={googleLoading}>
         {googleLoading ? (
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <Chrome className="mr-2 h-4 w-4" />
        )}
        Google
      </Button>
      <p className="text-center text-sm text-muted-foreground">
        Already have an account?{' '}
        <Link href="/login" className="font-medium text-primary hover:underline">
          Log in
        </Link>
      </p>
    </div>
  );
}
