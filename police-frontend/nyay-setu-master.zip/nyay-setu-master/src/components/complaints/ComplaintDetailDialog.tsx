
"use client";

import type { SavedComplaint } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Download, FileText, Volume2, FileSignature } from 'lucide-react';
import { format } from 'date-fns';

interface ComplaintDetailDialogProps {
  isOpen: boolean;
  onClose: () => void;
  complaint: SavedComplaint | null;
}

function formatTimestamp(timestamp: any): string {
  if (!timestamp) return 'N/A';
  // Firestore Timestamps have toDate() method
  if (timestamp.toDate) {
    return format(timestamp.toDate(), "PPpp");
  }
  // If it's already a Date object or a string
  try {
    return format(new Date(timestamp), "PPpp");
  } catch (e) {
    return String(timestamp);
  }
}

export default function ComplaintDetailDialog({ isOpen, onClose, complaint }: ComplaintDetailDialogProps) {
  if (!complaint) return null;

  const handleDownloadTextTranscript = () => {
    if (!complaint.transcript) return;
    const transcriptText = complaint.transcript.map(msg => {
      let header = `${msg.sender === 'user' ? 'User' : 'NyayaSahayak AI'} (${formatTimestamp(msg.timestamp)}):`;
      if (msg.attachmentName) {
        header += ` [Attached: ${msg.attachmentName} (${msg.attachmentType || 'unknown type'})]`;
      }
      return `${header}\n${msg.text}\n`;
    }).join('\n---\n');
    const blob = new Blob([transcriptText], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Complaint_Transcript_${complaint.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadStatement = () => {
    if (!complaint.englishSummary) return;
    const blob = new Blob([complaint.englishSummary], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Complaint_Statement_${complaint.id}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="font-headline text-2xl">Complaint Details: {complaint.id}</DialogTitle>
          <DialogDescription>
            Recorded on: {formatTimestamp(complaint.createdAt)}
            {complaint.updatedAt && complaint.createdAt.seconds !== complaint.updatedAt.seconds && (
              ` | Last updated: ${formatTimestamp(complaint.updatedAt)}`
            )}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex-grow overflow-y-auto space-y-4 pr-2">
          {complaint.englishSummary && (
             <div>
              <h3 className="text-lg font-semibold mb-2">Complaint Statement Summary</h3>
              <ScrollArea className="h-40 w-full rounded-md border p-3 bg-muted/30">
                <pre className="text-sm whitespace-pre-wrap">{complaint.englishSummary}</pre>
              </ScrollArea>
            </div>
          )}

          {complaint.transcript && complaint.transcript.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-2">Full Transcript</h3>
              <ScrollArea className="h-72 w-full rounded-md border p-3 bg-muted/30">
                {complaint.transcript.map((msg) => (
                  <div key={msg.id} className="mb-3 text-sm">
                    <p className={`font-semibold ${msg.sender === 'user' ? 'text-primary' : 'text-accent-foreground'}`}>
                      {msg.sender === 'user' ? 'User' : 'NyayaSahayak AI'} ({formatTimestamp(msg.timestamp)}):
                      {msg.attachmentName && <span className="font-normal text-xs"> (Attachment: {msg.attachmentName} - {msg.attachmentType || 'unknown'})</span>}
                    </p>
                    <p className="whitespace-pre-wrap pl-2 text-foreground">{msg.text}</p>
                  </div>
                ))}
              </ScrollArea>
            </div>
          )}

          {complaint.audioDownloadUrl && (
            <div>
              <h3 className="text-lg font-semibold mb-2">ASR Audio Recording</h3>
              <audio controls src={complaint.audioDownloadUrl} className="w-full">
                Your browser does not support the audio element.
              </audio>
            </div>
          )}
           {complaint.videoDownloadUrl && (
            <div>
              <h3 className="text-lg font-semibold mb-2">Session Video Recording</h3>
              <video controls src={complaint.videoDownloadUrl} className="w-full rounded-md border">
                Your browser does not support the video element.
              </video>
            </div>
          )}


          {!complaint.englishSummary && !complaint.transcript?.length && !complaint.audioDownloadUrl && !complaint.videoDownloadUrl && (
            <p className="text-muted-foreground">No transcript, statement, or recordings found for this complaint.</p>
          )}
        </div>
        
        <DialogFooter className="mt-auto pt-4 border-t flex-wrap gap-2">
          {complaint.englishSummary && (
            <Button variant="outline" onClick={handleDownloadStatement}>
              <FileSignature className="mr-2 h-4 w-4" /> Download Statement
            </Button>
          )}
          {complaint.transcript && complaint.transcript.length > 0 && (
            <Button variant="outline" onClick={handleDownloadTextTranscript}>
              <FileText className="mr-2 h-4 w-4" /> Download Transcript
            </Button>
          )}
          {complaint.audioDownloadUrl && (
             <Button variant="outline" asChild>
                <a href={complaint.audioDownloadUrl} download={`Complaint_${complaint.id}_ASR_Audio.webm`} target="_blank" rel="noopener noreferrer">
                    <Volume2 className="mr-2 h-4 w-4" /> Download ASR Audio
                </a>
            </Button>
          )}
          {complaint.videoDownloadUrl && (
             <Button variant="outline" asChild>
                <a href={complaint.videoDownloadUrl} download={`Complaint_${complaint.id}_Session_Video.webm`} target="_blank" rel="noopener noreferrer">
                    <Download className="mr-2 h-4 w-4" /> Download Session Video
                </a>
            </Button>
          )}
          <DialogClose asChild>
            <Button variant="secondary">Close</Button>
          </DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

