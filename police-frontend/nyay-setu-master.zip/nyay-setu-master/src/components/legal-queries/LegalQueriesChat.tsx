"use client";

import { useState, useRef, useEffect, ChangeEvent, FormEvent } from "react";
import type { LegalQueryMessage } from "@/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Send, User, Bot, Loader2, Mic, Paperclip, MessageSquare } from "lucide-react";
import { format } from "date-fns";

interface LegalQueriesChatProps {
  messages: LegalQueryMessage[];
  onSendMessage: (
    messageText: string,
    language?: string,
    fileUrl?: string,
    fileType?: string
  ) => Promise<void>;
  isLoadingReply: boolean;
  currentSessionId: string | null;
  idToken: string; // Firebase Auth ID token for API calls
}

const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "hi", label: "Hindi" },
  { code: "ta", label: "Tamil" },
  { code: "te", label: "Telugu" },
  { code: "bn", label: "Bengali" },
  { code: "gu", label: "Gujarati" },
  { code: "ml", label: "Malayalam" },
  { code: "mr", label: "Marathi" },
  { code: "pa", label: "Punjabi" },
  { code: "ur", label: "Urdu" },
  // Add more as needed
];

export default function LegalQueriesChat({
  messages,
  onSendMessage,
  isLoadingReply,
  currentSessionId,
  idToken,
}: LegalQueriesChatProps) {
  const [input, setInput] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState<string>("en");
  const [isRecording, setIsRecording] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Voice input
  const startVoiceInput = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = selectedLanguage + "-IN";
    recognition.onresult = (event: any) => {
      setInput(event.results[0][0].transcript);
    };
    recognition.onend = () => setIsRecording(false);
    recognition.start();
    setIsRecording(true);
  };

  // File upload
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFile(file);
  };

  const handleFormSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoadingReply || !currentSessionId) return;
    let fileUrl: string | null = null,
      fileType: string | null = null;
    if (file) {
      // Upload file to backend
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload-legal-file", {
        method: "POST",
        headers: { Authorization: `Bearer ${idToken}` },
        body: formData,
      });
      const data = await res.json();
      fileUrl = data.fileUrl;
      fileType = file ? file.type : null;
      setFile(null);
    }
    await onSendMessage(
      input,
      selectedLanguage,
      fileUrl ?? undefined,
      fileType ?? undefined
    );
    setInput("");
  };

  useEffect(() => {
    if (scrollAreaRef.current?.lastElementChild) {
      scrollAreaRef.current.lastElementChild.scrollIntoView({
        behavior: "smooth",
        block: "end",
      });
    }
  }, [messages]);

  if (!currentSessionId) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-background p-6 text-center">
        <MessageSquare className="h-16 w-16 text-muted-foreground mb-4" />
        <p className="text-lg text-muted-foreground">
          Select a query or start a new one.
        </p>
        <p className="text-sm text-muted-foreground">
          Your legal questions will be answered here.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-background overflow-hidden">
      <ScrollArea className="flex-1 p-4 sm:p-6" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-end gap-2 ${
                msg.sender === "user" ? "justify-end" : ""
              }`}
            >
              {msg.sender === "ai" && (
                <Avatar className="h-8 w-8 self-start border">
                  <AvatarFallback>
                    <Bot size={18} />
                  </AvatarFallback>
                </Avatar>
              )}
              <div
                className={`max-w-[75%] rounded-lg p-3 shadow-md text-sm ${
                  msg.sender === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-card text-card-foreground border"
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
                {msg.fileUrl && (
                  <a
                    href={msg.fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block mt-2 text-xs text-blue-600 underline"
                  >
                    {msg.fileType?.startsWith("audio")
                      ? "Audio File"
                      : msg.fileType?.startsWith("image")
                      ? "Image"
                      : "File"}
                  </a>
                )}
                <p
                  className={`mt-1 text-xs ${
                    msg.sender === "user"
                      ? "text-primary-foreground/70 text-right"
                      : "text-muted-foreground"
                  }`}
                >
                  {(() => {
                    let date: Date | null = null;
                    if (msg.timestamp) {
                      if (typeof msg.timestamp.toDate === 'function') {
                        date = msg.timestamp.toDate(); // Firestore Timestamp
                      } else if (typeof msg.timestamp === 'string' || typeof msg.timestamp === 'number') {
                        date = new Date(msg.timestamp);
                      } else if (msg.timestamp instanceof Date) {
                        date = msg.timestamp;
                      }
                    }
                    return date && !isNaN(date.getTime())
                      ? format(date, "p, MMM d")
                      : "Invalid date";
                  })()}
                </p>
              </div>
              {msg.sender === "user" && (
                <Avatar className="h-8 w-8 self-start border">
                  <AvatarFallback>
                    <User size={18} />
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
          {isLoadingReply && (
            <div className="flex items-end gap-2">
              <Avatar className="h-8 w-8 self-start border">
                <AvatarFallback>
                  <Bot size={18} />
                </AvatarFallback>
              </Avatar>
              <div className="max-w-[75%] rounded-lg p-3 shadow-md bg-card text-card-foreground border">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
              </div>
            </div>
          )}
          {messages.length === 0 && !isLoadingReply && (
            <div className="text-center text-muted-foreground py-10">
              <MessageSquare size={32} className="mx-auto mb-2" />
              <p>Ask your legal question to begin.</p>
            </div>
          )}
        </div>
      </ScrollArea>
      <form onSubmit={handleFormSubmit} className="border-t bg-card p-3 sm:p-4">
        <div className="flex items-center gap-2">
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="border rounded px-2 py-1 text-sm"
          >
            {LANGUAGES.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.label}
              </option>
            ))}
          </select>
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your legal question here..."
            className="flex-1 resize-none min-h-[40px]"
            rows={1}
            onKeyDown={(e) => {
              if (
                e.key === "Enter" &&
                !e.shiftKey &&
                !isLoadingReply &&
                input.trim()
              ) {
                e.preventDefault();
                handleFormSubmit(e as any);
              }
            }}
            disabled={isLoadingReply}
          />
          <Button
            type="button"
            onClick={startVoiceInput}
            disabled={isRecording || isLoadingReply}
          >
            <Mic className="h-4 w-4" />
          </Button>
          <input
            type="file"
            onChange={handleFileChange}
            className="hidden"
            id="file-upload"
          />
          <label htmlFor="file-upload">
            <Button type="button" disabled={isLoadingReply}>
              <Paperclip className="h-4 w-4" />
            </Button>
          </label>
          <Button type="submit" disabled={isLoadingReply || !input.trim()}>
            {isLoadingReply ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
            <span className="sr-only">Send</span>
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1.5">
          AI responses are for informational purposes only and not legal advice.
        </p>
      </form>
    </div>
  );
}
