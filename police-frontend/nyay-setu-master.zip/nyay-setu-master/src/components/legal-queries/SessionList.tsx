"use client";

import type { LegalQueryChat } from '@/types';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PlusCircle, MessageSquareText, Loader2 } from 'lucide-react';
import { formatDistanceToNowStrict } from 'date-fns';
import { cn } from '@/lib/utils';
import type { Timestamp } from 'firebase/firestore';

interface SessionListProps {
  sessions: LegalQueryChat[];
  currentSessionId: string | null;
  onSelectSession: (sessionId: string) => void;
  onNewSession: () => void;
  isLoadingSessions: boolean;
}

export default function SessionList({
  sessions,
  currentSessionId,
  onSelectSession,
  onNewSession,
  isLoadingSessions
}: SessionListProps) {
  return (
    <div className="flex flex-col border-r bg-muted/40 h-full w-full md:w-80 lg:w-96">
      <div className="p-3 border-b">
        <Button onClick={onNewSession} className="w-full" variant="outline">
          <PlusCircle className="mr-2 h-4 w-4" /> New Legal Query
        </Button>
      </div>
      <ScrollArea className="flex-1">
        {isLoadingSessions ? (
          <div className="flex items-center justify-center p-4">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            <span className="ml-2 text-sm text-muted-foreground">Loading sessions...</span>
          </div>
        ) : sessions.length === 0 ? (
          <div className="p-4 text-center text-sm text-muted-foreground">
            No past queries. Start a new one!
          </div>
        ) : (
          <nav className="grid gap-1 p-2">
            {sessions.map((session) => (
              <Button
                key={session.id}
                variant="ghost"
                className={cn(
                  "w-full justify-start text-left h-auto py-2.5 px-3 group",
                  currentSessionId === session.id ? "bg-primary text-primary-foreground hover:bg-primary/90" : "hover:bg-accent hover:text-accent-foreground"
                )}
                onClick={() => onSelectSession(session.id)}
              >
                <MessageSquareText className={cn(
                  "h-4 w-4 mr-2 shrink-0",
                  currentSessionId === session.id ? "text-primary-foreground" : "text-muted-foreground group-hover:text-accent-foreground"
                )} />
                <div className="flex-1 truncate">
                  <p className={cn(
                    "text-sm font-medium truncate",
                     currentSessionId === session.id ? "text-primary-foreground" : "text-foreground"
                  )}>
                    {session.title || `Query from ${session.createdAt && typeof (session.createdAt as unknown as Timestamp).toDate === 'function' ? (session.createdAt as unknown as Timestamp).toDate().toLocaleDateString() : 'recent'}`}
                  </p>
                  <p className={cn(
                    "text-xs truncate",
                    currentSessionId === session.id ? "text-primary-foreground/80" : "text-muted-foreground"
                  )}>
                    {session.messageCount} message(s) - Last active: {session.lastMessageAt && typeof (session.lastMessageAt as unknown as Timestamp).toDate === 'function' ? formatDistanceToNowStrict((session.lastMessageAt as unknown as Timestamp).toDate(), { addSuffix: true }) : "Just now"}
                  </p>
                </div>
              </Button>
            ))}
          </nav>
        )}
      </ScrollArea>
    </div>
  );
}
