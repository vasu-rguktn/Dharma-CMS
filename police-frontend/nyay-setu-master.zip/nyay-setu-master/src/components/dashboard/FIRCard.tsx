import Link from 'next/link';
import type { CaseDoc } from '@/types'; // Use CaseDoc
import { CaseStatus } from '@/types';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';

interface FIRCardProps {
  caseData: CaseDoc; // Changed from fir to caseData of type CaseDoc
}

const statusColors: Record<CaseStatus, string> = {
  [CaseStatus.New]: 'bg-blue-500 hover:bg-blue-600',
  [CaseStatus.UnderInvestigation]: 'bg-orange-500 hover:bg-orange-600',
  [CaseStatus.PendingTrial]: 'bg-yellow-500 hover:bg-yellow-600 text-black',
  [CaseStatus.Resolved]: 'bg-green-500 hover:bg-green-600',
  [CaseStatus.Closed]: 'bg-gray-500 hover:bg-gray-600',
};

// Helper to format Firestore Timestamp or string date
const formatDate = (dateInput: any): string => {
  if (!dateInput) return 'N/A';
  if (dateInput.toDate && typeof dateInput.toDate === 'function') {
    return format(dateInput.toDate(), 'MMM d, yyyy');
  }
  try {
    return format(new Date(dateInput), 'MMM d, yyyy');
  } catch (e) {
    return String(dateInput); // Fallback
  }
};


export default function FIRCard({ caseData }: FIRCardProps) {
  return (
    <Card className="flex flex-col h-full shadow-lg hover:shadow-xl transition-shadow duration-200">
      <CardHeader>
        <div className="flex items-center justify-between mb-2">
          <FileText className="h-6 w-6 text-primary" />
          <Badge className={`${statusColors[caseData.status]} text-white px-2.5 py-0.5 text-xs`}>{caseData.status}</Badge>
        </div>
        <CardTitle className="font-headline text-xl leading-tight truncate" title={caseData.title}>{caseData.title}</CardTitle>
        <CardDescription>
          FIR No: {caseData.firNumber} | PS: {caseData.policeStation || 'N/A'} | Filed: {formatDate(caseData.dateFiled)}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-sm text-muted-foreground mb-1">Complainant: {caseData.complainantName || 'N/A'}</p>
        <p className="text-sm text-foreground line-clamp-3" title={caseData.incidentDetails}>{caseData.incidentDetails}</p>
      </CardContent>
      <CardFooter className="flex justify-between items-center pt-4">
        <p className="text-xs text-muted-foreground">Last Updated: {formatDate(caseData.lastUpdated)}</p>
        <Button variant="outline" size="sm" asChild>
          <Link href={`/cases/${caseData.id}`}>
            View Details <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
