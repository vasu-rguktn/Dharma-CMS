
"use client";

import { useState, useRef, useEffect, type FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Loader2, Bot, User, MessageCircle, Mic, Square, Volume2, Languages, Play, Pause, CheckCircle2, Download, Save, Edit3, StopCircle } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { aiChatComplaint, type AiChatComplaintInput, type AiChatComplaintOutput } from '@/ai/flows/ai-chat-complaint';
import { saveComplaint, type SaveComplaintInput, type Message as FlowMessage } from '@/ai/flows/save-complaint-flow';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth'; 

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface EmbeddedCrimeSceneChatProps {
  firNumber: string;
  caseTitle: string;
  caseId: string; 
  initialContextText?: string; 
}

const indianLanguages = [ 
  { value: "en-US", label: "English (US)" },
  { value: "en-IN", label: "English (India)" },
  { value: "hi-IN", label: "हिन्दी (Hindi)" },
];

function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error("Failed to convert blob to Data URL."));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export default function EmbeddedCrimeSceneChat({ firNumber, caseTitle, caseId, initialContextText }: EmbeddedCrimeSceneChatProps) {
  const { user } = useAuth(); 
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  const [chatActive, setChatActive] = useState(false); 
  const [conversationEnded, setConversationEnded] = useState(false);
  const [finalFirNumberForSave, setFinalFirNumberForSave] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const [selectedLanguage, setSelectedLanguage] = useState<string>(indianLanguages[0].value);
  
  const [isAsrRecording, setIsAsrRecording] = useState(false);
  const asrRecognitionRef = useRef<SpeechRecognition | null>(null); 
  const asrInterimTranscriptRef = useRef<string>(''); // To accumulate interim results

  const [isSessionRecording, setIsSessionRecording] = useState(false);
  const sessionMediaRecorderRef = useRef<MediaRecorder | null>(null);
  const sessionAudioChunksRef = useRef<Blob[]>([]);
  const [sessionAudioBlob, setSessionAudioBlob] = useState<Blob | null>(null);
  const [sessionAudioBlobUrl, setSessionAudioBlobUrl] = useState<string | null>(null);

  const currentTTSUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [isTTSSpeaking, setIsTTSSpeaking] = useState(false);
  const currentTTSMessageIdRef = useRef<string | null>(null);


  const scrollToBottom = () => {
    if (scrollAreaRef.current?.lastElementChild) {
      scrollAreaRef.current.lastElementChild.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  };

  useEffect(scrollToBottom, [messages]);

  const handlePlayTTS = (messageId: string, text: string) => {
    if (!text.trim() || isLoading || !window.speechSynthesis) {
        if (!window.speechSynthesis) toast({ variant: "destructive", title: "TTS Not Supported" });
        return;
    }
    if (isTTSSpeaking) {
        window.speechSynthesis.cancel();
        setIsTTSSpeaking(false);
        if (currentTTSMessageIdRef.current === messageId) {
            currentTTSMessageIdRef.current = null;
            return;
        }
    }
    currentTTSMessageIdRef.current = messageId;
    setIsTTSSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = selectedLanguage;
    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = voices.find(voice => voice.lang === selectedLanguage);
    if (selectedVoice) utterance.voice = selectedVoice;

    currentTTSUtteranceRef.current = utterance;
    utterance.onend = () => { setIsTTSSpeaking(false); currentTTSMessageIdRef.current = null; currentTTSUtteranceRef.current = null; };
    utterance.onerror = (event) => {
      toast({ variant: "destructive", title: "TTS Error", description: event.error || "Could not play audio." });
      setIsTTSSpeaking(false); currentTTSMessageIdRef.current = null; currentTTSUtteranceRef.current = null;
    };
    window.speechSynthesis.speak(utterance);
  };

  const startFullSessionAudioRecording = async () => {
    if (isSessionRecording || conversationEnded) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      sessionAudioChunksRef.current = []; setSessionAudioBlob(null); setSessionAudioBlobUrl(null);
      const options = { mimeType: 'audio/webm;codecs=opus' };
      let recorder;
      try { recorder = new MediaRecorder(stream, options); } 
      catch (e) { 
        try { recorder = new MediaRecorder(stream); } 
        catch (e2) { toast({variant: "destructive", title: "Recording Error", description: "MediaRecorder not supported."}); return; }
      }
      sessionMediaRecorderRef.current = recorder;
      sessionMediaRecorderRef.current.ondataavailable = (event) => { if (event.data.size > 0) sessionAudioChunksRef.current.push(event.data); };
      sessionMediaRecorderRef.current.onstop = () => {
        if (sessionAudioChunksRef.current.length > 0) {
          const audioBlob = new Blob(sessionAudioChunksRef.current, { type: sessionMediaRecorderRef.current?.mimeType || 'audio/webm' });
          setSessionAudioBlob(audioBlob); setSessionAudioBlobUrl(URL.createObjectURL(audioBlob));
        } else { setSessionAudioBlob(null); setSessionAudioBlobUrl(null); }
        setIsSessionRecording(false); sessionAudioChunksRef.current = [];
        if (stream) stream.getTracks().forEach(track => track.stop());
      };
      sessionMediaRecorderRef.current.start(); setIsSessionRecording(true);
    } catch (err) { toast({ variant: "destructive", title: "Recording Error", description: "Could not start audio recording." }); }
  };

  const stopFullSessionAudioRecording = () => {
    if (isSessionRecording && sessionMediaRecorderRef.current && sessionMediaRecorderRef.current.state === "recording") {
      sessionMediaRecorderRef.current.stop();
    }
  };
  
  const sendInitialAIMessageAndActivate = async () => {
    if (isLoading || !firNumber) return;
    setIsLoading(true); setChatActive(true); setMessages([]); 
    let greetingUserInput = `Start guiding me for the crime scene investigation of FIR: ${firNumber} (Case: "${caseTitle}").`;
    if (initialContextText) greetingUserInput += `\n\nRelevant context: "${initialContextText}"\n\nBased on this, what should I focus on?`;
    else greetingUserInput += `\nWhat are the general first steps?`;
    try {
      const aiInput: AiChatComplaintInput = {
        userInput: greetingUserInput, chatHistory: '', language: selectedLanguage.split('-')[0], 
        mode: 'crimeSceneInvestigation', firNumber: firNumber, isGreetingRequest: false,
      };
      const result: AiChatComplaintOutput = await aiChatComplaint(aiInput);
      const aiMessage: Message = { id: Date.now().toString(), text: result.response, sender: 'ai', timestamp: new Date() };
      setMessages([aiMessage]);
      if (result.response.trim()) handlePlayTTS(aiMessage.id, result.response);
      await startFullSessionAudioRecording();
    } catch (error) {
      toast({ variant: "destructive", title: "AI Error", description: "Failed to get initial guidance." });
      setMessages([{ id: Date.now().toString(), text: "Sorry, error initializing. Try sending a message.", sender: 'ai', timestamp: new Date() }]);
      setChatActive(false); 
    } finally { setIsLoading(false); }
  };

  const resetChatStates = () => {
    setMessages([]); setInput(''); setIsLoading(false); setChatActive(false); setConversationEnded(false);
    setFinalFirNumberForSave(''); setIsSaving(false);
    if (window.speechSynthesis && currentTTSUtteranceRef.current) { window.speechSynthesis.cancel(); setIsTTSSpeaking(false); currentTTSMessageIdRef.current = null; currentTTSUtteranceRef.current = null; }
    if (asrRecognitionRef.current && isAsrRecording) { asrRecognitionRef.current.stop(); setIsAsrRecording(false); asrInterimTranscriptRef.current = ''; }
    stopFullSessionAudioRecording(); setSessionAudioBlob(null); setSessionAudioBlobUrl(null);
  };

  useEffect(() => { resetChatStates(); 
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firNumber, selectedLanguage]); 

  useEffect(() => { return () => { 
      if (window.speechSynthesis && currentTTSUtteranceRef.current) { window.speechSynthesis.cancel(); }
      if (asrRecognitionRef.current) asrRecognitionRef.current.stop();
      stopFullSessionAudioRecording();
    };}, []);

  const handleSendMessage = async (e?: FormEvent) => {
    if (e) e.preventDefault(); if (!input.trim() || !chatActive || conversationEnded) return;
    const userMessage: Message = { id: Date.now().toString(), text: input, sender: 'user', timestamp: new Date() };
    setMessages((prev) => [...prev, userMessage]);
    const currentInput = input; setInput(''); setIsLoading(true);
    try {
      const chatHistoryForAI = [...messages, userMessage].map(msg => `${msg.sender === 'user' ? 'Officer' : 'Assistant'}: ${msg.text}`).join('\n');
      const aiInputPayload: AiChatComplaintInput = {
        userInput: currentInput, chatHistory: chatHistoryForAI, language: selectedLanguage.split('-')[0], 
        mode: 'crimeSceneInvestigation', firNumber: firNumber,
      };
      const result: AiChatComplaintOutput = await aiChatComplaint(aiInputPayload);
      const aiResponseMessage: Message = { id: (Date.now() + 1).toString(), text: result.response, sender: 'ai', timestamp: new Date() };
      setMessages((prev) => [...prev, aiResponseMessage]);
      if (result.response.trim()) handlePlayTTS(aiResponseMessage.id, result.response);
    } catch (error) {
      toast({ variant: "destructive", title: "AI Error", description: "Failed to get AI response." });
      setMessages((prev) => [...prev, { id: (Date.now() + 1).toString(), text: "Sorry, error processing.", sender: 'ai', timestamp: new Date() }]);
    } finally { setIsLoading(false); }
  };
  
  const toggleAsrRecording = () => {
    if (isAsrRecording) { 
        asrRecognitionRef.current?.stop();
        // setIsAsrRecording(false); // onend will handle this
        return;
    }
    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
        toast({ variant: "destructive", title: "ASR Not Supported" }); return;
    }
    asrRecognitionRef.current = new SpeechRecognition();
    const recognition = asrRecognitionRef.current;
    recognition.continuous = true; 
    recognition.interimResults = true; 
    recognition.lang = selectedLanguage;
    
    let currentFinalTranscript = input; // Start with existing input
    asrInterimTranscriptRef.current = '';

    recognition.onresult = (event) => {
        let interimTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                const finalChunk = event.results[i][0].transcript;
                currentFinalTranscript += finalChunk;
                asrInterimTranscriptRef.current = ''; // Reset interim when a final chunk is received
            } else {
                interimTranscript += event.results[i][0].transcript;
            }
        }
        asrInterimTranscriptRef.current = interimTranscript;
        setInput(currentFinalTranscript + asrInterimTranscriptRef.current);
    };
    recognition.onerror = (event) => {
        toast({ variant: "destructive", title: "ASR Error", description: event.error });
        setIsAsrRecording(false);
    };
    recognition.onend = () => {
      if (asrInterimTranscriptRef.current.trim()) {
        setInput(prev => prev.replace(asrInterimTranscriptRef.current, '').trim() + ' ' + asrInterimTranscriptRef.current.trim());
      }
      asrInterimTranscriptRef.current = '';
      setIsAsrRecording(false);
    };
    try { recognition.start(); setIsAsrRecording(true); }
    catch (e) { toast({ variant: "destructive", title: "ASR Start Error" }); setIsAsrRecording(false); }
  };

  const handleStopGuidance = () => { 
    if (window.speechSynthesis && currentTTSUtteranceRef.current) { window.speechSynthesis.cancel(); setIsTTSSpeaking(false); }
    if (asrRecognitionRef.current && isAsrRecording) { asrRecognitionRef.current.stop(); setIsAsrRecording(false); asrInterimTranscriptRef.current = '';}
    stopFullSessionAudioRecording(); currentTTSMessageIdRef.current = null; currentTTSUtteranceRef.current = null;
    setConversationEnded(true); setChatActive(false); 
    toast({ title: "Guidance Session Ended", description: "Review transcript and recording." });
  };

  const handleDownloadTextTranscript = () => {
    const transcriptText = messages.map(msg => `${msg.sender === 'user' ? 'Officer' : 'Assistant'} (${msg.timestamp.toLocaleString([], {dateStyle: 'short', timeStyle: 'short'})}):\n${msg.text}\n`).join('\n---\n');
    const blob = new Blob([transcriptText], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob);
    link.download = `CrimeSceneGuidance_FIR_${firNumber}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link); link.click(); document.body.removeChild(link);
    toast({ title: "Text Transcript Downloaded" });
  };

  const handleSaveToCase = async () => {
    if (!user) { toast({ variant: "destructive", title: "Not Logged In"}); return; }
    if (messages.length === 0 && !sessionAudioBlob) { toast({ variant: "destructive", title: "Cannot Save", description: "Empty data." }); return; }
    setIsSaving(true);
    const flowMessages: FlowMessage[] = messages.map(m => ({ id: m.id, text: m.text, sender: m.sender, timestamp: m.timestamp.toISOString() }));
    let audioDetailsPayload: SaveComplaintInput['audioDetails'];
    if (sessionAudioBlob) {
      try {
        const dataUri = await blobToDataURL(sessionAudioBlob);
        audioDetailsPayload = {
          dataUri: dataUri,
          fileName: `csi_audio_${firNumber}_${Date.now()}.${sessionAudioBlob.type.split('/')[1] || 'webm'}`,
          contentType: sessionAudioBlob.type || 'audio/webm',
        };
      } catch (error) { toast({variant: "destructive", title: "Audio Error", description: "Could not process audio."}); setIsSaving(false); return; }
    }
    const complaintIdToSave = finalFirNumberForSave.trim() || `${firNumber}_csi_guidance_${Date.now()}`;
    const inputForFlow: SaveComplaintInput = {
      complaintId: complaintIdToSave,
      messages: flowMessages.length > 0 ? flowMessages : undefined,
      audioDetails: audioDetailsPayload,
      officerUid: user.uid, 
      activityType: `Crime Scene AI Guidance for FIR ${firNumber}`, 
      caseReferenceId: caseId, 
    };
    try {
      const result = await saveComplaint(inputForFlow);
      if (result.success) { toast({ title: "Guidance Saved", description: `Data saved with ID: ${result.complaintId}. Journal entry created for case ${caseId}.` }); resetChatStates(); } 
      else { toast({ variant: "destructive", title: "Save Failed", description: result.error || result.message }); }
    } catch (error: any) { toast({ variant: "destructive", title: "Error Saving", description: error.message }); } 
    finally { setIsSaving(false); }
  };
  
  const handleRestartGuidance = () => { resetChatStates(); };

  return (
    <Card className="flex-1 flex flex-col shadow-md min-h-[300px] max-h-[600px] h-full">
      <CardHeader className="py-3 px-4 border-b">
        <div className="flex items-center justify-between">
            <CardTitle className="text-md font-semibold flex items-center"><MessageCircle className="mr-2 h-5 w-5 text-primary" />Crime Scene AI Assistant</CardTitle>
            <div className="flex items-center gap-2">
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage} disabled={isLoading || isAsrRecording || chatActive || conversationEnded}>
                    <SelectTrigger className="h-8 w-auto min-w-[120px] text-xs"><Languages className="h-3 w-3 mr-1" /><SelectValue placeholder="Lang" /></SelectTrigger>
                    <SelectContent>{indianLanguages.map(lang => (<SelectItem key={lang.value} value={lang.value} className="text-xs">{lang.label}</SelectItem>))}</SelectContent>
                </Select>
            </div>
        </div>
        <CardDescription className="text-xs mt-1">
            For FIR: {firNumber} ({caseTitle}). 
            {!chatActive && !conversationEnded && " Click Start to begin."}
            {chatActive && !conversationEnded && <span className="text-green-600 font-medium ml-1">(Guidance Active{isSessionRecording ? " & Recording" : ""})</span>}
            {conversationEnded && <span className="text-blue-600 font-medium ml-1">(Session Ended - Review)</span>}
        </CardDescription>
      </CardHeader>

      {!chatActive && !conversationEnded && (
        <CardContent className="flex-1 flex flex-col items-center justify-center p-4">
          <Button onClick={sendInitialAIMessageAndActivate} disabled={isLoading || !firNumber}><Play className="mr-2 h-4 w-4" /> Start AI Guidance</Button>
          <p className="text-xs text-muted-foreground mt-2">AI will guide you through crime scene documentation.</p>
        </CardContent>
      )}

      {chatActive && !conversationEnded && (
        <CardContent className="flex-1 flex flex-col overflow-hidden p-0">
          <div className="p-2 border-b">
             <Button onClick={handleStopGuidance} variant="outline" size="sm" className="w-full" disabled={isLoading}><StopCircle className="mr-2 h-4 w-4 text-destructive" /> Stop AI Guidance & Review</Button>
          </div>
          <ScrollArea className="flex-1 p-3" ref={scrollAreaRef}>
            <div className="space-y-3">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex items-end gap-2 text-sm ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                  {msg.sender === 'ai' && (<Avatar className="h-7 w-7 self-start"><AvatarFallback><Bot size={16} /></AvatarFallback></Avatar>)}
                  <div className={`max-w-[80%] rounded-md p-2 shadow-sm flex flex-col ${msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`}>
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <div className="flex justify-between items-center mt-1">
                      <p className={`text-xs ${msg.sender === 'user' ? 'text-primary-foreground/70' : 'text-muted-foreground/70'}`}>{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                      {msg.sender === 'ai' && msg.text.trim() && (
                        <Button variant="ghost" size="icon" className={`h-5 w-5 p-0 ml-1 ${currentTTSMessageIdRef.current === msg.id && isTTSSpeaking ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`} onClick={() => handlePlayTTS(msg.id, msg.text)} title={currentTTSMessageIdRef.current === msg.id && isTTSSpeaking ? "Stop" : "Play"}>
                          {currentTTSMessageIdRef.current === msg.id && isTTSSpeaking ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                        </Button>
                      )}
                    </div>
                  </div>
                  {msg.sender === 'user' && (<Avatar className="h-7 w-7"><AvatarFallback><User size={16} /></AvatarFallback></Avatar>)}
                </div>
              ))}
              {isLoading && messages.length > 0 && ( <div className="flex items-end gap-2"><Avatar className="h-7 w-7"><AvatarFallback><Bot size={16} /></AvatarFallback></Avatar><div className="max-w-[80%] rounded-md p-2 shadow-sm bg-muted"><Loader2 className="h-4 w-4 animate-spin text-primary" /></div></div>)}
            </div>
          </ScrollArea>
          <form onSubmit={handleSendMessage} className="border-t p-2 bg-background">
            <div className="flex items-center gap-2">
              <Button type="button" variant={isAsrRecording ? "destructive" : "outline"} size="icon" className="h-9 w-9" onClick={toggleAsrRecording} title={isAsrRecording ? "Stop ASR" : "Start ASR"} disabled={isLoading || !firNumber || !chatActive || conversationEnded}>{isAsrRecording ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />} <span className="sr-only">{isAsrRecording ? "Stop" : "ASR"}</span></Button>
              <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask for guidance or describe..." className="flex-1 resize-none text-sm h-9 py-1.5" rows={1} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); }}} disabled={isLoading || !firNumber || !chatActive || conversationEnded || isAsrRecording}/>
              <Button type="submit" size="icon" className="h-9 w-9" disabled={isLoading || !input.trim() || !firNumber || !chatActive || conversationEnded} title="Send"><Send className="h-4 w-4" /><span className="sr-only">Send</span></Button>
            </div>
          </form>
        </CardContent>
      )}

      {conversationEnded && (
        <CardContent className="flex-1 flex flex-col overflow-hidden p-0">
          <ScrollArea className="flex-auto p-3">
            <div className="space-y-3">
              <Alert><CheckCircle2 className="h-4 w-4" /><AlertTitle>Guidance Session Ended</AlertTitle><AlertDescription>Review transcript & audio. Save session to case file.</AlertDescription></Alert>
              <div className="border rounded-md p-2">
                <h3 className="text-md font-semibold mb-1">Guidance Transcript</h3>
                <ScrollArea className="flex-grow bg-muted/30 p-2 rounded-md mb-2 max-h-48">
                  {messages.map(msg => (<div key={`transcript-${msg.id}`} className="mb-2 text-xs"><p className={`font-semibold ${msg.sender === 'user' ? 'text-primary' : 'text-accent-foreground'}`}>{msg.sender === 'user' ? 'Officer' : 'Assistant'} ({msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}):</p><p className="whitespace-pre-wrap pl-1 text-foreground">{msg.text}</p></div>))}
                  {messages.length === 0 && <p className="text-muted-foreground text-center py-3">No messages.</p>}
                </ScrollArea>
                {sessionAudioBlobUrl && (<div className="mb-2"><h4 className="text-sm font-semibold mb-1">Recorded Session Audio:</h4><audio src={sessionAudioBlobUrl} controls className="w-full h-10" /></div>)}
                <div className="flex flex-wrap gap-2 items-center justify-start">
                  <Button onClick={handleDownloadTextTranscript} variant="outline" size="sm" disabled={messages.length === 0}><Download className="mr-1 h-3 w-3"/> Text</Button>
                  {sessionAudioBlobUrl && (<Button asChild variant="outline" size="sm"><a href={sessionAudioBlobUrl} download={`CrimeSceneGuidance_Audio_FIR_${firNumber}_${new Date().toISOString().split('T')[0]}.${sessionAudioBlob?.type.split('/')[1] || 'webm'}`}><Download className="mr-1 h-3 w-3"/> Audio</a></Button>)}
                  <Button onClick={handleRestartGuidance} variant="outline" size="sm"><Edit3 className="mr-1 h-3 w-3"/> New Guidance</Button>
                </div>
              </div>
              <Card>
                <CardHeader className="p-3"><CardTitle className="text-md">Save Guidance to Case File</CardTitle><CardDescription className="text-xs">Associate this guidance with FIR. ID auto-generated if blank.</CardDescription></CardHeader>
                <CardContent className="space-y-1 p-3">
                  <Label htmlFor="finalFirNumberForSave" className="text-xs">Official FIR Number / Session ID (Optional)</Label>
                  <Input id="finalFirNumberForSave" value={finalFirNumberForSave} onChange={(e) => setFinalFirNumberForSave(e.target.value)} placeholder={`Default: ${firNumber}_csi_guidance_...`} className="h-8 text-xs" />
                </CardContent>
                <CardFooter className="p-3"><Button onClick={handleSaveToCase} size="sm" disabled={isSaving || (messages.length === 0 && !sessionAudioBlob)}>{isSaving && <Loader2 className="mr-1 h-3 w-3 animate-spin" />} <Save className="mr-1 h-3 w-3" /> Save Session</Button></CardFooter>
              </Card>
            </div>
          </ScrollArea>
        </CardContent>
      )}
    </Card>
  );
}
