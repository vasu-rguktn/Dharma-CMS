
"use client";

import { useState, useEffect, type FormEvent } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, PlusCircle, Trash2, FileImage, UploadCloud } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { doc, setDoc, getDoc, Timestamp, serverTimestamp } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from '@/hooks/useAuth';
import type { CrimeDetails, Witness, CaseDoc } from '@/types';

interface CrimeDetailsFormProps {
  caseData: CaseDoc; 
  existingCrimeDetails?: CrimeDetails | null; 
  onSaveSuccess: (data: CrimeDetails) => void; 
}

const initialWitness: Witness = { id: Date.now().toString(), name: '', address: '', contactNumber: '' };

export default function CrimeDetailsForm({ caseData, existingCrimeDetails, onSaveSuccess }: CrimeDetailsFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [formData, setFormData] = useState<Partial<CrimeDetails>>({
    firNumber: caseData.firNumber,
    witnesses: [{ ...initialWitness }],
    crimeType: '',
    majorHead: '',
    minorHead: '',
    languageDialectUsed: '',
    specialFeatures: '',
    conveyanceUsed: '',
    characterAssumedByOffender: '',
    methodUsed: '',
    placeOfOccurrenceDescription: '',
    dateTimeOfSceneVisit: '',
    physicalEvidenceDescription: '',
    motiveOfCrime: '',
    sketchOrMapUrl: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (existingCrimeDetails) {
      setFormData({
        ...existingCrimeDetails,
        dateTimeOfSceneVisit: existingCrimeDetails.dateTimeOfSceneVisit 
            ? new Date(existingCrimeDetails.dateTimeOfSceneVisit).toISOString().substring(0, 16) 
            : '',
        witnesses: existingCrimeDetails.witnesses && existingCrimeDetails.witnesses.length > 0 
            ? existingCrimeDetails.witnesses.map(w => ({...w, id: w.id || Date.now().toString() + Math.random() }))
            : [{ ...initialWitness }],
      });
    } else {
      setFormData({
        firNumber: caseData.firNumber,
        witnesses: [{ ...initialWitness }],
        crimeType: '', majorHead: '', minorHead: '', languageDialectUsed: '', specialFeatures: '',
        conveyanceUsed: '', characterAssumedByOffender: '', methodUsed: '', placeOfOccurrenceDescription: '',
        dateTimeOfSceneVisit: '', physicalEvidenceDescription: '', motiveOfCrime: '', sketchOrMapUrl: '',
      });
    }
  }, [existingCrimeDetails, caseData.firNumber]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleDateTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleWitnessChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const updatedWitnesses = formData.witnesses ? [...formData.witnesses] : [];
    if (updatedWitnesses[index]) {
      updatedWitnesses[index] = { ...updatedWitnesses[index], [name]: value };
      setFormData(prev => ({ ...prev, witnesses: updatedWitnesses }));
    }
  };

  const addWitness = () => {
    setFormData(prev => ({
      ...prev,
      witnesses: [...(prev.witnesses || []), { ...initialWitness, id: Date.now().toString() }],
    }));
  };

  const removeWitness = (index: number) => {
    setFormData(prev => ({
      ...prev,
      witnesses: prev.witnesses?.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({ variant: "destructive", title: "Authentication Error", description: "You must be logged in." });
      return;
    }
    if (!caseData.id) {
      toast({ variant: "destructive", title: "Case ID Missing", description: "Cannot save crime details without a valid case ID." });
      return;
    }

    if (!formData.crimeType?.trim() || !formData.placeOfOccurrenceDescription?.trim()) {
      toast({ variant: "destructive", title: "Missing Required Fields", description: "Please fill in Crime Type and Place of Occurrence Description." });
      return;
    }

    setIsLoading(true);
    const crimeDetailsToSave: CrimeDetails = {
      ...formData,
      id: caseData.id, 
      firNumber: caseData.firNumber,
      userId: user.uid, 
      createdAt: existingCrimeDetails?.createdAt || serverTimestamp(), 
      updatedAt: serverTimestamp(), 
      dateTimeOfSceneVisit: formData.dateTimeOfSceneVisit ? new Date(formData.dateTimeOfSceneVisit).toISOString() : '',
      witnesses: formData.witnesses?.filter(w => w.name?.trim() || w.address?.trim() || w.contactNumber?.trim()), 
    } as CrimeDetails; 

    try {
      const crimeDocRef = doc(db, 'crimeDetails', caseData.id); 
      await setDoc(crimeDocRef, crimeDetailsToSave, { merge: true }); 
      toast({ title: "Success", description: "Crime scene details saved." });
      onSaveSuccess(crimeDetailsToSave);
    } catch (error: any) {
      console.error("Error saving crime details:", error);
      toast({ variant: "destructive", title: "Save Failed", description: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="font-headline text-xl">
          {existingCrimeDetails ? "Edit Crime Scene & Details" : "Add Crime Scene & Details"}
        </CardTitle>
        <CardDescription>
          Record specifics about the crime scene, methods, evidence, and witnesses for FIR: {caseData.firNumber}.
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label htmlFor="crimeType">Crime Type <span className="text-destructive">*</span></Label><Input id="crimeType" name="crimeType" value={formData.crimeType || ''} onChange={handleInputChange} required /></div>
            <div><Label htmlFor="majorHead">Major Head</Label><Input id="majorHead" name="majorHead" value={formData.majorHead || ''} onChange={handleInputChange} /></div>
            <div><Label htmlFor="minorHead">Minor Head</Label><Input id="minorHead" name="minorHead" value={formData.minorHead || ''} onChange={handleInputChange} /></div>
            <div><Label htmlFor="dateTimeOfSceneVisit">Date/Time of Scene Visit</Label><Input id="dateTimeOfSceneVisit" name="dateTimeOfSceneVisit" type="datetime-local" value={formData.dateTimeOfSceneVisit || ''} onChange={handleDateTimeChange} /></div>
          </div>

          <div><Label htmlFor="placeOfOccurrenceDescription">Place of Occurrence Description <span className="text-destructive">*</span></Label><Textarea id="placeOfOccurrenceDescription" name="placeOfOccurrenceDescription" value={formData.placeOfOccurrenceDescription || ''} onChange={handleInputChange} rows={3} required /></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label htmlFor="languageDialectUsed">Language/Dialect Used by Offender</Label><Input id="languageDialectUsed" name="languageDialectUsed" value={formData.languageDialectUsed || ''} onChange={handleInputChange} /></div>
            <div><Label htmlFor="specialFeatures">Special Features of Offence</Label><Input id="specialFeatures" name="specialFeatures" value={formData.specialFeatures || ''} onChange={handleInputChange} /></div>
            <div><Label htmlFor="conveyanceUsed">Conveyance Used</Label><Input id="conveyanceUsed" name="conveyanceUsed" value={formData.conveyanceUsed || ''} onChange={handleInputChange} /></div>
            <div><Label htmlFor="characterAssumedByOffender">Character Assumed by Offender</Label><Input id="characterAssumedByOffender" name="characterAssumedByOffender" value={formData.characterAssumedByOffender || ''} onChange={handleInputChange} /></div>
          </div>

          <div><Label htmlFor="methodUsed">Method Used in Offence</Label><Textarea id="methodUsed" name="methodUsed" value={formData.methodUsed || ''} onChange={handleInputChange} rows={3} /></div>
          <div><Label htmlFor="physicalEvidenceDescription">Physical Evidence Found/Collected</Label><Textarea id="physicalEvidenceDescription" name="physicalEvidenceDescription" value={formData.physicalEvidenceDescription || ''} onChange={handleInputChange} rows={3} /></div>
          <div><Label htmlFor="motiveOfCrime">Suspected Motive of Crime</Label><Textarea id="motiveOfCrime" name="motiveOfCrime" value={formData.motiveOfCrime || ''} onChange={handleInputChange} rows={2} /></div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <Label className="text-lg font-medium">Witnesses</Label>
              <Button type="button" variant="outline" size="sm" onClick={addWitness}><PlusCircle className="mr-2 h-4 w-4" />Add Witness</Button>
            </div>
            {formData.witnesses?.map((witness, index) => (
              <Card key={witness.id || index} className="mb-3 p-4 space-y-2 relative bg-muted/30">
                {formData.witnesses && formData.witnesses.length > 1 && (
                   <Button type="button" variant="ghost" size="icon" className="absolute top-1 right-1 text-destructive hover:bg-destructive/10 h-7 w-7" onClick={() => removeWitness(index)}>
                      <Trash2 className="h-4 w-4" />
                   </Button>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div><Label htmlFor={`witnessName-${index}`}>Name</Label><Input id={`witnessName-${index}`} name="name" value={witness.name || ''} onChange={(e) => handleWitnessChange(index, e)} /></div>
                    <div><Label htmlFor={`witnessAddress-${index}`}>Address</Label><Input id={`witnessAddress-${index}`} name="address" value={witness.address || ''} onChange={(e) => handleWitnessChange(index, e)} /></div>
                    <div><Label htmlFor={`witnessContact-${index}`}>Contact</Label><Input id={`witnessContact-${index}`} name="contactNumber" value={witness.contactNumber || ''} onChange={(e) => handleWitnessChange(index, e)} /></div>
                </div>
              </Card>
            ))}
            {(!formData.witnesses || formData.witnesses.length === 0) && <p className="text-sm text-muted-foreground">No witnesses added yet.</p>}
          </div>
          
          <div>
            <Label htmlFor="sketchOrMapUrl">Sketch/Map URL (Placeholder)</Label>
            <div className="flex items-center gap-2 mt-1">
                <Input id="sketchOrMapUrl" name="sketchOrMapUrl" value={formData.sketchOrMapUrl || ''} onChange={handleInputChange} placeholder="Enter URL of uploaded sketch/map" />
                <Button type="button" variant="outline" disabled>
                    <UploadCloud className="mr-2 h-4 w-4" /> Upload (Soon)
                </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Actual file upload functionality will be added later. For now, paste a URL if available.</p>
          </div>

        </CardContent>
        <CardFooter className="border-t pt-6">
          <Button type="submit" disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {existingCrimeDetails ? "Update Scene Details" : "Save Scene Details"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
    