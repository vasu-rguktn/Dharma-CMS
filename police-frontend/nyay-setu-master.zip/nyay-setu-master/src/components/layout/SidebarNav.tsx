
"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  MessageSquare,
  Scale,
  FileEdit,
  FilePlus2,
  FileCheck2,
  Users,
  FolderOpen,
  Settings,
  BookOpen,
  Archive,
  Search,
  Brain // Icon for Legal Queries
  // PencilRuler // Icon for Suspect Sketching - Temporarily removed
} from 'lucide-react';
import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
} from '@/components/ui/sidebar';


const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  {
    groupLabel: 'AI Tools',
    items: [
      { href: '/chat', label: 'AI Chat', icon: MessageSquare },
      { href: '/legal-queries', label: 'Legal Queries', icon: Brain },
      { href: '/legal-suggestion', label: 'Legal Suggestion', icon: Scale },
      { href: '/document-drafting', label: 'Document Drafting', icon: FileEdit },
      { href: '/chargesheet-generation', label: 'Chargesheet Gen', icon: FilePlus2 },
      { href: '/chargesheet-vetting', label: 'Chargesheet Vetting', icon: FileCheck2 },
      { href: '/witness-preparation', label: 'Witness Prep', icon: Users },
      { href: '/media-analysis', label: 'Media Analysis', icon: Search },
      // { href: '/suspect-sketching', label: 'Suspect Sketching', icon: PencilRuler }, // Link removed
    ],
  },
  {
    groupLabel: 'Case Management',
    items: [
      { href: '/cases', label: 'All Cases', icon: FolderOpen },
      { href: '/complaints', label: 'My Saved Complaints', icon: Archive },

      { href: '/case-journal-example', label: 'Case Journal', icon: BookOpen },
    ],
  },
  { href: '/settings', label: 'Settings', icon: Settings },
];

export default function SidebarNav() {
  const pathname = usePathname();

  return (
    <SidebarMenu>
      {navItems.map((item, index) => {
        if ('groupLabel' in item) {
          return (
            <SidebarGroup key={`group-${index}`}>
              <SidebarGroupLabel>{item.groupLabel}</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {item.items.map((subItem) => (
                    <SidebarMenuItem key={subItem.href}>
                      <Link href={subItem.href} passHref legacyBehavior>
                        <SidebarMenuButton
                          asChild
                          isActive={pathname === subItem.href || (subItem.href === "/media-analysis" && pathname.startsWith("/media-analysis")) || (subItem.href === "/legal-queries" && pathname.startsWith("/legal-queries"))}
                          tooltip={subItem.label}
                        >
                          <a>
                            <subItem.icon />
                            <span>{subItem.label}</span>
                          </a>
                        </SidebarMenuButton>
                      </Link>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          );
        }
        return (
          <SidebarMenuItem key={item.href}>
             <Link href={item.href} passHref legacyBehavior>
              <SidebarMenuButton
                asChild
                isActive={pathname === item.href}
                tooltip={item.label}
              >
                <a>
                  <item.icon />
                  <span>{item.label}</span>
                </a>
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        );
      })}
    </SidebarMenu>
  );
}

    