import { Gavel } from 'lucide-react'; // Using Gavel as a placeholder icon

export default function Logo() {
  return (
    <div className="flex items-center gap-2">
      <Gavel className="h-8 w-8 text-primary" />
      <h1 className="text-2xl font-bold text-primary font-headline">NyayaSahayak</h1>
    </div>
  );
}
