
"use client";

import type { User } from 'firebase/auth';
import { onAuthStateChanged } from 'firebase/auth';
import type { ReactNode } from 'react';
import { createContext, useEffect, useState } from 'react';
import { auth, db } from '@/lib/firebase'; 
import { doc, getDoc, Timestamp } from 'firebase/firestore';
import type { UserProfile } from '@/types';
import { Loader2 } from 'lucide-react';

// Extend the Firebase User type to include our custom profile
export interface AppUser extends User {
  profile?: UserProfile | null; // Profile can be null if not yet created or fetched
}

interface AuthContextType {
  user: AppUser | null;
  loading: boolean;
  profileLoading: boolean; // To indicate profile fetching status
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  profileLoading: true,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true); // Firebase Auth loading state
  const [profileLoading, setProfileLoading] = useState(true); // Firestore profile loading state

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setProfileLoading(true);
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        try {
          const userDocSnap = await getDoc(userDocRef);
          if (userDocSnap.exists()) {
            const profileData = userDocSnap.data() as UserProfile;
            // Ensure timestamps are correctly handled if they come from Firestore
            const fullProfile: UserProfile = {
                ...profileData,
                createdAt: profileData.createdAt instanceof Timestamp ? profileData.createdAt : Timestamp.now(), // Fallback if needed
                updatedAt: profileData.updatedAt instanceof Timestamp ? profileData.updatedAt : Timestamp.now(), // Fallback
            };
            setUser({ ...firebaseUser, profile: fullProfile });
          } else {
            // Profile doesn't exist in Firestore. This might be a new Google sign-up
            // or an old user. For now, set profile to null.
            // A "complete profile" step could be triggered elsewhere in the app.
            setUser({ ...firebaseUser, profile: null });
            console.warn(`User profile not found in Firestore for UID: ${firebaseUser.uid}. User might need to complete profile setup.`);
          }
        } catch (error) {
          console.error("Error fetching user profile from Firestore:", error);
          setUser({ ...firebaseUser, profile: null }); // Set with null profile on error
        } finally {
          setProfileLoading(false);
        }
      } else {
        setUser(null);
        setProfileLoading(false); // No profile to load if no user
      }
      setLoading(false); // Firebase Auth state determined
    });

    return () => unsubscribe();
  }, []);

  if (loading) { // Initial auth check
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
        <p className="ml-2">Authenticating...</p>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, loading, profileLoading }}>
      {children}
    </AuthContext.Provider>
  );
}
