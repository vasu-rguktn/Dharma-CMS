import { getStorage } from 'firebase-admin/storage';
import { getAuth } from 'firebase-admin/auth';
import { NextApiRequest, NextApiResponse } from 'next';
import formidable from 'formidable';
import fs from 'fs';

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();

  const token = req.headers.authorization?.split('Bearer ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const decoded = await getAuth().verifyIdToken(token);
  const userId = decoded.uid;

  const form = new formidable.IncomingForm();
  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: 'File upload error' });
    const file = files.file as formidable.File;
    const storage = getStorage().bucket();
    const dest = `legal_queries/${userId}/${file.originalFilename}`;
    await storage.upload(file.filepath, { destination: dest });
    const fileUrl = await storage.file(dest).getSignedUrl({ action: 'read', expires: '03-09-2491' });
    res.status(200).json({ fileUrl: fileUrl[0] });
    fs.unlinkSync(file.filepath); // Clean up temp file
  });
}
