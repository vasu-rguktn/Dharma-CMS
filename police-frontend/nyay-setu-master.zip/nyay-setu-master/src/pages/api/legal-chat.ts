import type { NextApiRequest, NextApiResponse } from 'next';
import OpenAI from 'openai';
import { db } from '@/lib/firebase'; // Assuming you have this for Firestore
import { doc, collection, addDoc, updateDoc, serverTimestamp, Timestamp, runTransaction, getDoc } from 'firebase/firestore'; // Import runTransaction and getDoc
import type { LegalQueryMessage, LegalQueryChat } from '@/types';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const ASSISTANT_ID = process.env.OPENAI_ASSISTANT_ID;

type Data = {
  reply?: string;
  newMessage?: LegalQueryMessage; // Send back the saved AI message
  error?: string;
};

// Helper function to poll for run completion
async function pollRunStatus(threadId: string, runId: string): Promise<OpenAI.Beta.Threads.Runs.Run> {
  let run = await openai.beta.threads.runs.retrieve(threadId, runId);
  while (run.status === 'queued' || run.status === 'in_progress' || run.status === 'requires_action') {
    if (run.status === 'requires_action') {
      // This example doesn't handle tool calls, but you would add logic here if your assistant uses them
      console.warn('OpenAI Assistant Run requires action (e.g., tool calls), which is not handled in this basic implementation.');
      // For simplicity, we'll just cancel the run if it requires action and we're not set up for it.
      // Or, you could submit empty tool outputs if that's appropriate for your assistant.
      // For now, let's break and let it timeout or error.
      // await openai.beta.threads.runs.cancel(threadId, runId);
      // throw new Error('Run requires action, but tool call handling is not implemented.');
      // For demo, let's just wait, maybe it resolves or we catch a timeout.
    }
    await new Promise(resolve => setTimeout(resolve, 1000)); // Poll every 1 second
    run = await openai.beta.threads.runs.retrieve(threadId, runId);
  }
  return run;
}


export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Data>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  if (!ASSISTANT_ID) {
    console.error('OPENAI_ASSISTANT_ID is not set.');
    return res.status(500).json({ error: 'OpenAI Assistant not configured on server.' });
  }
  if (!process.env.OPENAI_API_KEY) {
    console.error('OPENAI_API_KEY is not set.');
    return res.status(500).json({ error: 'OpenAI API Key not configured on server.' });
  }

  const { sessionId, userId, messageText, openaiThreadId: currentOpenaiThreadId } = req.body;

  if (!sessionId || !userId || !messageText) {
    return res.status(400).json({ error: 'Missing sessionId, userId, or messageText' });
  }

  // Debug: Log incoming request
  console.log('Incoming request:', req.body);

  // Extra check: userId must be a non-empty string
  if (typeof userId !== 'string' || !userId.trim()) {
    return res.status(400).json({ error: 'Invalid or missing userId' });
  }

  try {
    // 1. Save user message to Firestore
    const userMessageData: Omit<LegalQueryMessage, 'id'> = {
      sessionId,
      userId,
      text: messageText,
      sender: 'user',
      timestamp: serverTimestamp() as Timestamp,
    };
    console.log('Saving user message to Firestore:', userMessageData);
    const userMessageRef = await addDoc(collection(db, 'legal_queries_chats', sessionId, 'messages'), userMessageData);

    // 2. Update chat session metadata (lastMessageAt, messageCount)
    const sessionDocRef = doc(db, 'legal_queries_chats', sessionId);
    await updateDoc(sessionDocRef, {
      lastMessageAt: serverTimestamp(),
      // Use runTransaction correctly
      messageCount: await runTransaction(db, async (transaction) => {
        const sessionDoc = await transaction.get(sessionDocRef);
        if (!sessionDoc.exists()) {
          throw new Error("Session not found for update");
        }
        return (sessionDoc.data()?.messageCount || 0) + 1;
      }),
    });

    let threadIdToUse = currentOpenaiThreadId;

    // 3. Interact with OpenAI Assistant
    if (!threadIdToUse) {
      // Create a new thread if one doesn't exist for this session
      const thread = await openai.beta.threads.create({});
      threadIdToUse = thread.id;
      // Save the new thread ID to the session document in Firestore
      await updateDoc(sessionDocRef, { openaiThreadId: threadIdToUse });
    }

    // Add message to the thread
    await openai.beta.threads.messages.create(threadIdToUse, {
      role: 'user',
      content: messageText,
    });

    // Create a run
    let run = await openai.beta.threads.runs.create(threadIdToUse, {
      assistant_id: ASSISTANT_ID,
      // Instructions can be overridden here if needed:
      // instructions: "Please address the user as Jane Doe. The user has a premium account."
    });

    // Poll for run completion
    run = await pollRunStatus(threadIdToUse, run.id);

    if (run.status === 'completed') {
      const messages = await openai.beta.threads.messages.list(threadIdToUse, {
        limit: 1, // Get the latest message which should be the assistant's reply
        order: 'desc',
      });

      const aiReplyContent = messages.data[0]?.content;
      let aiReplyText = "Sorry, I couldn't get a specific response.";

      if (aiReplyContent && aiReplyContent[0]?.type === 'text') {
        aiReplyText = aiReplyContent[0].text.value;
      } else if (aiReplyContent) {
        console.warn("AI reply was not in simple text format:", aiReplyContent);
        aiReplyText = "Received a complex response type I can't display directly.";
      }

      // 4. Save AI response to Firestore
      const aiMessageData: Omit<LegalQueryMessage, 'id'> = {
        sessionId,
        userId,
        text: aiReplyText,
        sender: 'ai',
        timestamp: serverTimestamp(),
      };
      console.log('Saving AI message to Firestore:', aiMessageData);
      const aiMessageRef = await addDoc(collection(db, 'legal_queries_chats', sessionId, 'messages'), aiMessageData);

      // 5. Update chat session metadata again for AI message
       await updateDoc(sessionDocRef, {
        lastMessageAt: serverTimestamp(),
        // Use runTransaction correctly
        messageCount: await runTransaction(db, async (transaction) => {
            const sessionDoc = await transaction.get(sessionDocRef);
            if (!sessionDoc.exists()) {
             throw new Error("Session not found for AI message update");
            }
            return (sessionDoc.data()?.messageCount || 0) + 1;
        }),
        title: messageText.substring(0, 50) + (messageText.length > 50 ? "..." : "") // Update title with first user message if it's the first user message of a new chat
      });


      const savedAiMessage: LegalQueryMessage = {
        id: aiMessageRef.id,
        ...aiMessageData,
        timestamp: Timestamp.now() // Approximate client-side for immediate response
      };
      
      res.status(200).json({ reply: aiReplyText, newMessage: savedAiMessage });

    } else if (run.status === 'failed' || run.status === 'cancelled' || run.status === 'expired') {
      console.error('OpenAI Run failed or was cancelled:', run.last_error || run.status);
      throw new Error(`OpenAI Run ended with status: ${run.status}. ${run.last_error?.message || ''}`);
    } else {
      console.error('OpenAI Run ended with unexpected status:', run.status);
      throw new Error(`OpenAI Run ended with unexpected status: ${run.status}`);
    }

    const chatDoc = await getDoc(doc(db, 'legal_queries_chats', sessionId));
    console.log('Chat doc:', chatDoc.exists(), chatDoc.data());

  } catch (error: any) {
    console.error('Legal Chat API Error:', error);
    res.status(500).json({ error: error.message || 'Unable to fetch reply. Please try again.' });
  }
}
