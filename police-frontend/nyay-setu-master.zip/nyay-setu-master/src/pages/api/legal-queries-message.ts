import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { NextApiRequest, NextApiResponse } from 'next';
import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();

  const { chatId, text, language, fileUrl, fileType } = req.body;
  const token = req.headers.authorization?.split('Bearer ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  const decoded = await getAuth().verifyIdToken(token);
  const userId = decoded.uid;

  const db = getFirestore();
  const chatRef = db.collection('legal_queries_chats').doc(chatId);
  const chatDoc = await chatRef.get();
  if (!chatDoc.exists || chatDoc.data().userId !== userId) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  // Add user message
  const userMsgRef = await chatRef.collection('messages').add({
    sender: 'user',
    text,
    timestamp: new Date(),
    userId,
    language: language || 'en',
    fileUrl: fileUrl || null,
    fileType: fileType || null,
  });

  // Prepare OpenAI prompt/context
  const openaiMessages: { role: 'user' | 'assistant'; content: string }[] = [
    { role: 'user', content: text },
  ];
  if (fileUrl) {
    openaiMessages.push({ role: 'user', content: `Attached file: ${fileUrl}` });
  }

  // Call OpenAI Assistant (add language context if needed)
  const aiReply = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: openaiMessages,
  } as any);

  // Add AI message
  const aiMsgRef = await chatRef.collection('messages').add({
    sender: 'ai',
    text: aiReply.choices[0].message.content,
    timestamp: new Date(),
    userId,
    language: language || 'en',
  });

  res.status(200).json({
    userMessage: { id: userMsgRef.id, sender: 'user', text, timestamp: new Date(), userId, language, fileUrl, fileType },
    aiMessage: { id: aiMsgRef.id, sender: 'ai', text: aiReply.choices[0].message.content, timestamp: new Date(), userId, language },
  });
}
