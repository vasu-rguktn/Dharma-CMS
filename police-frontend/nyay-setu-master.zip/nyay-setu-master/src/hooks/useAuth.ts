
"use client";

import { useContext } from 'react';
import { AuthContext, type AppUser } from '@/contexts/AuthContext'; // Ensure AppUser is exported from context

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Re-export AppUser if it's defined in AuthContext and needed elsewhere
export type { AppUser };
