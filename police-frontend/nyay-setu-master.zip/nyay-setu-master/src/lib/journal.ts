
import { addDoc, collection, doc, getDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { db } from './firebase';
import type { UserProfile, CaseJournalEntry } from '@/types';

/**
 * Adds an entry to the case journal for a specific case.
 * It fetches officer details (name, rank) using the officerUid.
 *
 * @param caseId - The ID of the case (FIR) this journal entry belongs to.
 * @param officerUid - The UID of the officer making the entry.
 * @param activityType - A string categorizing the activity (e.g., "FIR Registered").
 * @param entryText - The descriptive text for the journal entry.
 * @param relatedDocumentId - Optional ID of a document related to this journal entry.
 * @returns Promise<void>
 */
export async function addCaseJournalEntry(
  caseId: string,
  officerUid: string,
  activityType: string,
  entryText: string,
  relatedDocumentId?: string
): Promise<void> {
  if (!caseId || !officerUid || !activityType || !entryText) {
    console.error("Missing required parameters for addCaseJournalEntry.");
    // Potentially throw an error or return a status
    return;
  }

  let officerName = 'Unknown Officer';
  let officerRank = 'N/A Rank';

  try {
    const userDocRef = doc(db, 'users', officerUid);
    const userDocSnap = await getDoc(userDocRef);

    if (userDocSnap.exists()) {
      const userProfile = userDocSnap.data() as UserProfile;
      officerName = userProfile.displayName || userProfile.email || 'Officer';
      officerRank = userProfile.rank || 'N/A';
    } else {
      console.warn(`User profile not found for UID: ${officerUid}. Using default values for journal entry.`);
    }
  } catch (error) {
    console.error("Error fetching user profile for journal entry:", error);
    // Continue with default officer details
  }

  const journalEntryData: Omit<CaseJournalEntry, 'id' | 'dateTime'> & { dateTime: any } = {
    caseId,
    officerUid,
    officerName,
    officerRank,
    activityType,
    entryText,
    dateTime: serverTimestamp(), // Firestore will set this on the server
  };

  if (relatedDocumentId) {
    journalEntryData.relatedDocumentId = relatedDocumentId;
  }

  try {
    const journalCollectionRef = collection(db, 'caseJournalEntries');
    await addDoc(journalCollectionRef, journalEntryData);
    console.log(`Case journal entry added for case ${caseId} by officer ${officerUid}. Activity: ${activityType}`);
  } catch (error) {
    console.error("Error adding document to caseJournalEntries collection:", error);
    // Handle the error appropriately, e.g., by logging or notifying the user/system
  }
}
