
import { z } from 'genkit';
import { ai } from '@/ai/genkit';

export const GreetingRequestSchema = z.object({
  language: z.string().optional().default('en').describe('The selected language for the conversation (e.g., "en", "hi").'),
  mode: z.enum(['complaintRecording', 'witnessStatement', 'witnessPreparation', 'normalChat', 'crimeSceneInvestigation']).describe('The operational mode of the chat assistant.'),
  firNumber: z.string().optional().describe('The FIR number, relevant for witness statement, preparation, and crime scene investigation modes.'),
});

export const GreetingResponseSchema = z.object({
  response: z.string().describe('The AI-generated greeting message.'),
});

export const greetingPrompt = ai.definePrompt({
  name: 'greetingPrompt',
  input: { schema: GreetingRequestSchema },
  output: { schema: GreetingResponseSchema },
  prompt: `
    You are NyayaSahayak, an AI assistant for police personnel.
    This is an initial greeting request. Provide a suitable opening message for the selected mode ({{mode}}) and language ({{language}}).
    Do not ask a question yet, just greet the user and state your purpose.

    - For "complaintRecording" in English: "Hello, I am NyayaSahayak, your AI assistant. I am ready to help you record your complaint. Please tell me what happened."
    - For "complaintRecording" in Hindi: "नमस्ते, मैं न्यायसहायक हूँ, आपका AI सहायक। मैं आपकी शिकायत दर्ज करने में मदद करने के लिए तैयार हूँ। कृपया बताएं कि क्या हुआ।"

    - For "witnessStatement" in English: "Hello, I am NyayaSahayak. I am here to record your statement for FIR number {{firNumber}}. Please state what you saw or heard."
    - For "witnessStatement" in Hindi: "नमस्कार, मैं न्यायसहायक हूँ। मैं FIR नंबर {{firNumber}} के लिए आपका बयान दर्ज करने के लिए यहाँ हूँ। कृपया बताएं कि आपने क्या देखा या सुना।"

    - For "witnessPreparation" in English: "Welcome. This is a witness preparation session for FIR {{firNumber}}. I will ask you some questions as a defense lawyer might. Are you ready to begin?"
    - For "witnessPreparation" in Hindi: "आपका स्वागत है। यह FIR नंबर {{firNumber}} के लिए एक गवाह तैयारी सत्र है। मैं आपसे कुछ प्रश्न पूछूंगा जैसे एक बचाव पक्ष का वकील पूछ सकता है। क्या आप शुरू करने के लिए तैयार हैं?"

    - For "normalChat" in English: "Hello! I am NyayaSahayak. How can I assist you today?"
    - For "normalChat" in Hindi: "नमस्ते! मैं न्यायसहायक हूँ। मैं आज आपकी कैसे सहायता कर सकता हूँ?"

    - For "crimeSceneInvestigation" in English: "Hello Officer, I am NyayaSahayak. I'm ready to assist you with documenting the crime scene investigation for FIR number {{firNumber}}. Please describe your initial observations upon arrival."
    - For "crimeSceneInvestigation" in Hindi: "नमस्ते अधिकारी, मैं न्यायसहायक हूँ। मैं FIR नंबर {{firNumber}} के लिए अपराध स्थल की जांच का दस्तावेजीकरण करने में आपकी सहायता के लिए तैयार हूँ। कृपया आगमन पर अपने प्रारंभिक अवलोकन का वर्णन करें।"

    Generate the greeting for the specified mode and language.
  `,
});
