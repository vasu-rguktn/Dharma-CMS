
import { z } from 'genkit';

/**
 * Defines the base schema for chat-related prompts.
 * This ensures consistency across different chat mode prompts.
 */
export const BaseChatPromptSchema = z.object({
  userInput: z
    .string()
    .describe('The user input in the chat, could be voice converted to text or text directly.'),
  document: z.object({
      dataUri: z.string().describe("The document data URI (Base64 encoded)."),
      contentType: z.string().describe("The MIME type of the document.")
    }).optional()
    .describe('Optional document attached by the user.'),
  chatHistory: z.string().optional().describe('The history of the chat.'),
  language: z.string().optional().default('en').describe('The language for the conversation.'),
  firNumber: z.string().optional().describe('The FIR number, if relevant.'),
  knowledgeBaseContext: z.string().optional().describe("Relevant information from a knowledge base."),
});

/**
 * Defines the schema for the response from a chat prompt.
 */
export const ChatResponseSchema = z.object({
  response: z.string().describe('The AI response to the user input.'),
});
