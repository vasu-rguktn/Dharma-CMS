
import { config } from 'dotenv';
config();

// import '@/ai/flows/fir-autofill.ts'; // Removed
import '@/ai/flows/legal-suggestion.ts';
import '@/ai/flows/witness-preparation.ts';
import '@/ai/flows/chargesheet-vetting.ts';
import '@/ai/flows/chargesheet-generation.ts';
import '@/ai/flows/ai-chat-complaint.ts';
import '@/ai/flows/document-drafting.ts';
import '@/ai/flows/save-complaint-flow.ts'; 
import '@/ai/flows/extract-fir-details.ts';
import '@/ai/flows/media-analysis-flow.ts'; 
// import '@/ai/flows/generate-suspect-sketch-flow.ts'; // Suspect sketch flow import commented out
// import '@/ai/flows/generate-tts-flow.ts'; // TTS flow no longer used, reverting to Web Speech API
    

    






    