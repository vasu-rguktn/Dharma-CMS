
'use server';

/**
 * @fileOverview This file contains the Genkit flow for witness preparation.
 *
 * - witnessPreparation - A function that initiates the mock trial experience for witness preparation.
 * - WitnessPreparationInput - The input type for the witnessPreparation function.
 * - WitnessPreparationOutput - The return type for the witnessPreparation function.
 */

import {ai} from '@/ai/genkit';
import {z}from 'genkit';

const WitnessPreparationInputSchema = z.object({
  caseDetails: z
    .string()
    .describe('Comprehensive details of the case, including charges, evidence, and known facts.'),
  witnessStatement: z
    .string()
    .describe('The witness statement to be used as the basis for the mock trial.'),
  witnessName: z.string().describe('The name of the witness being prepared.'),
  knowledgeBaseContext: z.string().optional().describe("Relevant information retrieved from the knowledge base (e.g., common cross-examination questions, typical defense strategies for this type of case, legal points to be aware of) to enhance the mock trial realism and feedback."),
});
export type WitnessPreparationInput = z.infer<typeof WitnessPreparationInputSchema>;

const WitnessPreparationOutputSchema = z.object({
  mockTrialTranscript: z
    .string()
    .describe('A transcript of the mock trial experience, including questions and responses.'),
  potentialWeaknesses: z
    .string()
    .describe('Identified potential weaknesses in the witness statement or preparedness.'),
  suggestedImprovements: z
    .string()
    .describe('Suggestions for improving the witness statement and overall preparedness.'),
});
export type WitnessPreparationOutput = z.infer<typeof WitnessPreparationOutputSchema>;

export async function witnessPreparation(input: WitnessPreparationInput): Promise<WitnessPreparationOutput> {
  return witnessPreparationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'witnessPreparationPrompt',
  input: {schema: WitnessPreparationInputSchema},
  output: {schema: WitnessPreparationOutputSchema},
  prompt: `You are an AI assistant specialized in conducting mock trials for witness preparation.
  {{#if knowledgeBaseContext}}
  Before formulating your questions and feedback, consult the following relevant information retrieved from our internal knowledge base. This information (e.g., common defense attorney tactics, crucial aspects of witness testimony for this type of case, points of law) should be prioritized to make the mock trial more effective:
  <knowledge_base_context>
  {{{knowledgeBaseContext}}}
  </knowledge_base_context>
  Always critically evaluate the knowledge base context against the specific case details and witness statement.
  {{/if}}

  Your goal is to help the witness be better prepared for potential cross-examination questions.

  Here are the details of the case:
  {{caseDetails}}

  Here is the witness statement:
  {{witnessStatement}}

  The witness name is:
  {{witnessName}}

  Conduct a mock trial, asking questions that a defense attorney might ask. Identify potential weaknesses in the witness's statement or preparedness and suggest improvements.

  Ensure the mock trial transcript is detailed and realistic.

  Output should include:
  - mockTrialTranscript: A transcript of the mock trial experience, including questions and responses.
  - potentialWeaknesses: Identified potential weaknesses in the witness statement or preparedness.
  - suggestedImprovements: Suggestions for improving the witness statement and overall preparedness.`,
});

const witnessPreparationFlow = ai.defineFlow(
  {
    name: 'witnessPreparationFlow',
    inputSchema: WitnessPreparationInputSchema,
    outputSchema: WitnessPreparationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
