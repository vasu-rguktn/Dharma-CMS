
'use server';
/**
 * @fileOverview A Genkit flow to save complaint transcripts and optional audio/video recordings to Firestore & Firebase Storage,
 * and log the activity to the case journal.
 *
 * - saveComplaint - Saves a complaint transcript, audio, and video, then logs to journal.
 * - SaveComplaintInput - Input type for saveComplaint.
 * - SaveComplaintOutput - Output type for saveComplaint.
 */

import {ai} from '@/ai/genkit';
import {z} from 'zod';
import {getFirestore, doc, setDoc, collection, Timestamp} from 'firebase/firestore';
import {getStorage, ref as storageRef, uploadString, getDownloadURL} from 'firebase/storage';
import {app} from '@/lib/firebase';
import { addCaseJournalEntry } from '@/lib/journal'; 

const db = getFirestore(app);
const storage = getStorage(app);

// Zod schema for individual messages, mirroring the frontend's Message interface
const MessageSchema = z.object({
  id: z.string(),
  text: z.string(),
  sender: z.enum(['user', 'ai']),
  timestamp: z.string().describe("ISO string format of the timestamp"),
  attachmentName: z.string().optional(),
  attachmentType: z.string().optional(),
});
export type Message = z.infer<typeof MessageSchema>;

const AudioDetailsSchema = z.object({
    dataUri: z.string().describe("Base64 encoded Data URI of the audio recording. Expected format: 'data:audio/<mimetype>;base64,<encoded_data>'."),
    fileName: z.string().describe("The desired file name for the audio in storage (e.g., 'session_audio.webm')."),
    contentType: z.string().describe("The MIME type of the audio (e.g., 'audio/webm')."),
});

const VideoDetailsSchema = z.object({
    dataUri: z.string().describe("Base64 encoded Data URI of the video recording. Expected format: 'data:video/<mimetype>;base64,<encoded_data>'."),
    fileName: z.string().describe("The desired file name for the video in storage (e.g., 'session_video.webm')."),
    contentType: z.string().describe("The MIME type of the video (e.g., 'video/webm')."),
});

const SaveComplaintInputSchema = z.object({
  complaintId: z.string().optional().describe("The user-provided FIR number or other ID. If empty or whitespace, an ID will be auto-generated. This will be used as caseId for journal entries if it's an FIR ID."),
  messages: z.array(MessageSchema).optional(),
  englishSummary: z.string().optional().describe("The English translation of the user's statement summary."),
  audioDetails: AudioDetailsSchema.optional().describe("Details for ASR-only user voice recording."),
  videoDetails: VideoDetailsSchema.optional().describe("Details for full session video recording."),
  userId: z.string().describe("UID of the officer performing the action, for journal logging and ownership."),
  officerStationName: z.string().optional().describe("Station name of the officer recording the complaint."),
  officerDistrict: z.string().optional().describe("District of the officer recording the complaint."),
  activityType: z.string().describe("Description of the activity for the journal entry (e.g., 'Complaint Recorded', 'Witness Statement Logged')."),
  caseReferenceId: z.string().optional().describe("The actual Case ID (FIR document ID from 'cases' collection) to associate the journal entry with, if different from complaintId or if complaintId is just a temporary/session ID."),
}).refine(data => (data.messages && data.messages.length > 0) || data.audioDetails || data.videoDetails, {
  message: "Either a non-empty transcript (messages), audio details, or video details must be provided.",
});
export type SaveComplaintInput = z.infer<typeof SaveComplaintInputSchema>;

const SaveComplaintOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
  complaintId: z.string().describe("The ID under which the complaint was saved."),
  audioDownloadUrl: z.string().optional().describe("Download URL of the saved ASR audio file from Firebase Storage, if audio was provided."),
  videoDownloadUrl: z.string().optional().describe("Download URL of the saved session video file from Firebase Storage, if video was provided."),
  error: z.string().optional().describe("Specific error message if the save operation failed."),
});
export type SaveComplaintOutput = z.infer<typeof SaveComplaintOutputSchema>;


export async function saveComplaint(input: SaveComplaintInput): Promise<SaveComplaintOutput> {
  return saveComplaintFlow(input);
}

const saveComplaintFlow = ai.defineFlow(
  {
    name: 'saveComplaintFlow',
    inputSchema: SaveComplaintInputSchema,
    outputSchema: SaveComplaintOutputSchema,
  },
  async (input: SaveComplaintInput): Promise<SaveComplaintOutput> => {
    let finalComplaintId: string;
    let journalCaseId: string; 

    try {
      if (!(input.messages && input.messages.length > 0) && !input.audioDetails && !input.videoDetails) {
        return {
          success: false,
          message: 'No content (transcript, audio, or video) provided to save.',
          complaintId: input.complaintId || "not_saved_no_content",
          error: 'No content provided.'
        };
      }

      let rawComplaintId = input.complaintId;
      if (!rawComplaintId || rawComplaintId.trim() === "") {
        const tempDocRef = doc(collection(db, 'complaints_temp_for_id_generation'));
        finalComplaintId = tempDocRef.id;
      } else {
        let sanitizedId = rawComplaintId.trim().replace(/\//g, '_');
        if (!sanitizedId || sanitizedId === "." || sanitizedId === "..") {
            const tempDocRef = doc(collection(db, 'complaints_temp_for_id_generation'));
            finalComplaintId = tempDocRef.id;
        } else {
            finalComplaintId = sanitizedId;
        }
      }
      if (!finalComplaintId) { 
          throw new Error("Complaint ID (for saving transcript/media) could not be determined or was invalid after sanitization.");
      }

      journalCaseId = input.caseReferenceId || finalComplaintId;

      const dataToSave: any = {
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
        userId: input.userId, 
      };

      if (input.officerStationName) dataToSave.officerStationName = input.officerStationName;
      if (input.officerDistrict) dataToSave.officerDistrict = input.officerDistrict;

      if (input.messages && input.messages.length > 0) {
        dataToSave.transcript = input.messages.map(msg => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
        }));
      }

      if (input.englishSummary) {
        dataToSave.englishSummary = input.englishSummary;
      }

      let audioStorageDownloadUrl: string | undefined = undefined;
      if (input.audioDetails) {
        const audioPath = `complaint_audio/${finalComplaintId}/${input.audioDetails.fileName}`;
        const audioFileRef = storageRef(storage, audioPath);
        const uploadResult = await uploadString(audioFileRef, input.audioDetails.dataUri, 'data_url', { contentType: input.audioDetails.contentType });
        audioStorageDownloadUrl = await getDownloadURL(uploadResult.ref);
        dataToSave.audioDownloadUrl = audioStorageDownloadUrl;
      }

      let videoStorageDownloadUrl: string | undefined = undefined;
      if (input.videoDetails) {
        const videoPath = `complaint_video/${finalComplaintId}/${input.videoDetails.fileName}`;
        const videoFileRef = storageRef(storage, videoPath);
        const uploadResult = await uploadString(videoFileRef, input.videoDetails.dataUri, 'data_url', { contentType: input.videoDetails.contentType });
        videoStorageDownloadUrl = await getDownloadURL(uploadResult.ref);
        dataToSave.videoDownloadUrl = videoStorageDownloadUrl;
      }
      
      const complaintRef = doc(db, 'complaints', finalComplaintId);
      await setDoc(complaintRef, dataToSave, { merge: true });

      try {
        let journalEntryText = `${input.activityType}. Transcript ID: ${finalComplaintId}.`;
        if (input.englishSummary) journalEntryText += " English summary saved.";
        if (audioStorageDownloadUrl) journalEntryText += " ASR audio saved.";
        else if (input.audioDetails) journalEntryText += " ASR audio provided but failed to save URL.";
        
        if (videoStorageDownloadUrl) journalEntryText += " Session video saved.";
        else if (input.videoDetails) journalEntryText += " Session video provided but failed to save URL.";
        
        if (!audioStorageDownloadUrl && !input.audioDetails && !videoStorageDownloadUrl && !input.videoDetails) {
            journalEntryText += " No audio/video recording provided.";
        }
         if (input.officerStationName) journalEntryText += ` Station: ${input.officerStationName}.`;
        
        await addCaseJournalEntry( journalCaseId, input.userId, input.activityType, journalEntryText, finalComplaintId ); 
      } catch (journalError: any) {
          console.error("Failed to add case journal entry:", journalError);
      }

      return {
        success: true,
        message: 'Complaint data saved successfully. Journal entry attempted.',
        complaintId: finalComplaintId,
        audioDownloadUrl: audioStorageDownloadUrl,
        videoDownloadUrl: videoStorageDownloadUrl,
      };
    } catch (error: any) {
      console.error("Error saving complaint:", error);
      return {
        success: false,
        message: 'Failed to save complaint data.',
        complaintId: input.complaintId ? input.complaintId.trim().replace(/\//g, '_') : "unknown_due_to_error",
        error: error.message || 'An unknown error occurred during save.',
      };
    }
  }
);

    