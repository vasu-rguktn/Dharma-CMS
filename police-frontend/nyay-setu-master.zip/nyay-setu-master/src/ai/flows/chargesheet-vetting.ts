
'use server';

/**
 * @fileOverview This file defines a Genkit flow for vetting a charge sheet and suggesting improvements.
 *
 * - chargesheetVetting - A function that takes a charge sheet as input and returns suggestions for improvement.
 * - ChargesheetVettingInput - The input type for the chargesheetVetting function.
 * - ChargesheetVettingOutput - The return type for the chargesheetVetting function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ChargesheetVettingInputSchema = z.object({
  chargesheet: z.string().describe('The content of the charge sheet to be vetted.'),
  knowledgeBaseContext: z.string().optional().describe("Relevant information retrieved from the knowledge base (e.g., common charge sheet errors, best practices, legal precedents for similar cases) to aid in the vetting process."),
});
export type ChargesheetVettingInput = z.infer<typeof ChargesheetVettingInputSchema>;

const ChargesheetVettingOutputSchema = z.object({
  suggestions: z.string().describe('Suggestions for improving the charge sheet.'),
});
export type ChargesheetVettingOutput = z.infer<typeof ChargesheetVettingOutputSchema>;

export async function chargesheetVetting(input: ChargesheetVettingInput): Promise<ChargesheetVettingOutput> {
  return chargesheetVettingFlow(input);
}

const chargesheetVettingPrompt = ai.definePrompt({
  name: 'chargesheetVettingPrompt',
  input: {schema: ChargesheetVettingInputSchema},
  output: {schema: ChargesheetVettingOutputSchema},
  prompt: `You are an expert legal consultant specializing in charge sheet vetting.
  {{#if knowledgeBaseContext}}
  Before formulating your response, consult the following relevant information retrieved from our internal knowledge base. This information (e.g., common charge sheet deficiencies, examples of strong arguments, relevant legal points) should be prioritized and used to ensure your vetting suggestions are thorough and insightful:
  <knowledge_base_context>
  {{{knowledgeBaseContext}}}
  </knowledge_base_context>
  Always critically evaluate the knowledge base context against the specific charge sheet provided.
  {{/if}}

  Review the provided charge sheet and provide suggestions for improvement to improve the chances of conviction.

Charge Sheet:
{{{chargesheet}}}`,
});

const chargesheetVettingFlow = ai.defineFlow(
  {
    name: 'chargesheetVettingFlow',
    inputSchema: ChargesheetVettingInputSchema,
    outputSchema: ChargesheetVettingOutputSchema,
  },
  async input => {
    const {output} = await chargesheetVettingPrompt(input);
    return output!;
  }
);
