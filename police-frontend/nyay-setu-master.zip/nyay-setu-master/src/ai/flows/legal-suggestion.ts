
'use server';

/**
 * @fileOverview This file contains the Genkit flow for providing legal suggestions based on FIR details,
 * incorporating RAG principles and simulated web search for accuracy, focusing exclusively on new Indian criminal laws.
 *
 * - legalSuggestion - A function that takes FIR details and returns suggested legal sections.
 * - LegalSuggestionInput - The input type for the legalSuggestion function.
 * - LegalSuggestionOutput - The return type for the legalSuggestion function.
 */

import {ai} from '@/ai/genkit';
import {z}from 'genkit';

const LegalSuggestionInputSchema = z.object({
  firDetails: z
    .string()
    .describe('The details of the First Information Report (FIR).'),
  incidentDetails: z.string().describe('The details of the incident.'),
  knowledgeBaseContext: z.string().optional().describe("Relevant information retrieved from the knowledge base (e.g., summaries of new laws, interpretations, applicability criteria for sections) to aid in suggesting legal sections."),
});
export type LegalSuggestionInput = z.infer<typeof LegalSuggestionInputSchema>;

const LegalSuggestionOutputSchema = z.object({
  suggestedSections: z
    .string()
    .describe(
      'Suggested sections EXCLUSIVELY from the new Indian criminal laws: Bharatiya Nyaya Sanhita (BNS), Bharatiya Nagarik Suraksha Sanhita (BNSS), Bharatiya Sakshya Adhiniyam (BSA), and other current special acts applicable to the case. Each section should be clearly listed with Act name and section number (e.g., "BNS Section 101"). DO NOT include sections from old/repealed laws like IPC, CrPC, or Indian Evidence Act. If no sections are applicable, state "No applicable sections found under the new laws based on the provided details."'
    ),
  reasoning: z
    .string()
    .describe('Detailed reasoning for why each suggested legal section (from BNS, BNSS, BSA, or current special acts) is applicable, linking facts from the FIR/incident to the legal provisions of the NEW laws. If no sections are suggested, this should explain why.'),
});
export type LegalSuggestionOutput = z.infer<typeof LegalSuggestionOutputSchema>;

export async function legalSuggestion(input: LegalSuggestionInput): Promise<LegalSuggestionOutput> {
  return legalSuggestionFlow(input);
}

const legalSuggestionPrompt = ai.definePrompt({
  name: 'legalSuggestionPrompt',
  model: 'googleai/gemini-1.5-pro-latest', // Use a more advanced model for this specific task
  input: {schema: LegalSuggestionInputSchema},
  output: {schema: LegalSuggestionOutputSchema},
  prompt: `You are an expert legal AI assistant specializing in Indian Criminal Laws. Your knowledge is current and you are fully aware of the recent implementation of the Bharatiya Nyaya Sanhita (BNS), Bharatiya Nagarik Suraksha Sanhita (BNSS), and Bharatiya Sakshya Adhiniyam (BSA), which have replaced the old Indian Penal Code (IPC), Code of Criminal Procedure (CrPC), and Indian Evidence Act, respectively.

  {{#if knowledgeBaseContext}}
  Before formulating your response, consult the following relevant information retrieved from our internal knowledge base. This information (e.g., detailed explanations of BNS/BNSS/BSA sections, applicability notes, comparisons with old laws for understanding context) should be prioritized and used to ensure your suggestions are accurate and well-founded:
  <knowledge_base_context>
  {{{knowledgeBaseContext}}}
  </knowledge_base_context>
  Always critically evaluate the knowledge base context against the specific FIR and incident details provided.
  {{/if}}

Your task is to analyze the provided FIR details and incident description to suggest applicable legal sections.
To ensure accuracy and up-to-date legal applicability, you must simulate using tool-calling or search features (like plugin search, RAG-based retrieval, or connected legal knowledge base) to refer to the official text of new criminal laws.

**CRITICAL INSTRUCTIONS:**
1.  **New Laws Only**: Your suggestions MUST exclusively be from the new laws: Bharatiya Nyaya Sanhita (BNS), Bharatiya Nagarik Suraksha Sanhita (BNSS), Bharatiya Sakshya Adhiniyam (BSA), and any relevant *current* special acts (e.g., POCSO Act, SC/ST (Prevention of Atrocities) Act, Dowry Prohibition Act, IT Act, NDPS Act, etc.).
2.  **No Repealed Laws**: DO NOT, under any circumstances, suggest sections from the old, repealed laws such as the Indian Penal Code (IPC), Code of Criminal Procedure (CrPC), or the Indian Evidence Act, 1872.
3.  **Confirm and Match**: Suggest only those sections that are confirmed by your (simulated) search and clearly match the incident described in the FIR and incident details.
4.  **Required Details per Section**: For each suggested section, you MUST provide:
    *   The Act name (short form like BNS, BNSS, BSA, POCSO Act, etc.)
    *   The specific section number (including subsections if applicable, e.g., BNS 103(1)).
    *   A brief description of the section’s content and clearly explain *why* it applies to the facts of this case.
5.  **No Fact Inference**: Do not infer or hallucinate any facts that are not explicitly stated in the provided FIR details or incident details.
6.  **Empty List for No Match**: If, after thorough analysis, no applicable sections are found under the new laws based on the provided details, the 'suggestedSections' field should clearly state "No applicable sections found under the new laws based on the provided details." and the 'reasoning' field should explain why.

FIR Details:
{{{firDetails}}}

Incident Details:
{{{incidentDetails}}}

Based on a thorough analysis of these details, and leveraging your extensive knowledge of the *current and effective* Indian criminal law:

Format your response strictly as per the output schema.
`,
});

const legalSuggestionFlow = ai.defineFlow(
  {
    name: 'legalSuggestionFlow',
    inputSchema: LegalSuggestionInputSchema,
    outputSchema: LegalSuggestionOutputSchema,
  },
  async input => {
    const {output} = await legalSuggestionPrompt(input);
    if (!output) {
        // Handle cases where the prompt might fail or return unexpected null
        return {
            suggestedSections: "Error: AI was unable to generate legal suggestions. Please check the input or try again.",
            reasoning: "The AI model did not return a valid response structure.",
        };
    }
    // If the AI is forced to return "No applicable sections..." due to the prompt and min(1) on schema isn't there,
    // this check is less critical. But it's good for robustness.
    if (!output.suggestedSections && !output.reasoning) {
         return {
            suggestedSections: "No applicable sections found under the new laws based on the provided details.",
            reasoning: "After careful analysis, no specific sections from the new Indian criminal laws (BNS, BNSS, BSA) or relevant special acts appear to directly apply to the facts as presented.",
        };
    }
    return output;
  }
);

