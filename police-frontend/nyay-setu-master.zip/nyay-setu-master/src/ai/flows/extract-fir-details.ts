
'use server';
import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ExtractFirDetailsInputSchema = z.object({
  complaintTranscript: z.string().describe("The full text transcript of the conversation, including both 'User:' and 'AI Assistant:' lines. The AI should focus on the 'User:' lines to extract details and synthesize the user's narrative."),
  language: z.string().optional().default('en').describe('The original language of the conversation (e.g., "en", "hi").'),
  knowledgeBaseContext: z.string().optional().describe("Relevant legal information to aid in suggesting legal sections."),
});
export type ExtractFirDetailsInput = z.infer<typeof ExtractFirDetailsInputSchema>;

const ExtractFirDetailsOutputSchema = z.object({
  title: z.string().optional().describe("A concise title for the case in English (e.g., 'Theft of Vehicle', 'Assault Incident')."),
  
  complainantName: z.string().optional().describe("Full name of the complainant."),
  complainantGender: z.enum(["Male", "Female", "Other", "Unknown"]).optional(),
  complainantAge: z.string().optional().describe("Age of the complainant in years."),
  complainantFatherHusbandName: z.string().optional().describe("Father's or Husband's name of the complainant."),
  complainantAddress_streetVillage: z.string().optional().describe("Complainant's street/village."),
  complainantAddress_cityDistrict: z.string().optional().describe("Complainant's city/district."),
  complainantMobileNumber: z.string().optional().describe("Complainant's mobile number."),
  
  occurrenceDateTimeFrom: z.string().optional().describe("Date and time incident started (YYYY-MM-DDTHH:MM)."),
  occurrenceDay: z.string().optional().describe("Day of the week."),
  occurrencePlace_streetVillage: z.string().optional().describe("Incident street/village."),
  occurrencePlace_areaMandal: z.string().optional().describe("Incident area/mandal."),
  occurrencePlace_cityDistrict: z.string().optional().describe("Incident city/district."),

  complaintStatement: z.string().min(1, "The complaint statement narrative is required and cannot be empty if dialogue is present.").describe("A concise, first-person factual narrative summary of the incident based ONLY on the 'User:' portions of the provided '{{{complaintTranscript}}}'. This summary should be in the original language ('{{{language}}}') and from the user's (complainant/witness) point of view, detailing what happened. This is NOT a list of Q&A or a simple concatenation of user inputs; it is their story."),
  translatedEnglishComplaintStatement: z.string().min(1, "The translated English complaint statement is required and cannot be empty if dialogue is present.").describe("An English translation of the complaintStatement. This is for official records and should accurately reflect the user's narrative summary derived from their statements in the dialogue."),

  accusedName: z.string().optional().describe("Name of the accused person."),
  accusedGender: z.enum(["Male", "Female", "Other", "Unknown"]).optional(),
  accusedAge: z.string().optional().describe("Age of the accused."),
  accusedAddress_streetVillage: z.string().optional().describe("Accused's street/village."),

  victimName: z.string().optional().describe("Full name of the victim, if different from the complainant."),
  victimGender: z.enum(["Male", "Female", "Other", "Unknown"]).optional(),
  victimAge: z.string().optional().describe("Age of the victim."),

  propertiesInvolvedDetails: z.string().optional().describe("Description of property involved."),
  propertiesTotalValueStolen: z.string().optional().describe("Total value of stolen property in INR."),

  actsAndSectionsInvolved: z.string().optional().describe("Applicable sections from new Indian laws (BNS, BNSS, BSA, Special Acts). Format: 'Act Section: Description'."),
  typeOfInformation: z.enum(["Written", "Oral", "Unknown"]).optional().describe("Inferred type of original complaint."),
});
export type ExtractFirDetailsOutput = z.infer<typeof ExtractFirDetailsOutputSchema>;

export async function extractFirDetailsFromTranscript(input: ExtractFirDetailsInput): Promise<ExtractFirDetailsOutput> {
  return extractFirDetailsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'extractFirDetailsPrompt',
  input: { schema: ExtractFirDetailsInputSchema },
  output: { schema: ExtractFirDetailsOutputSchema },
  prompt: `
      You are an expert police assistant extracting information from a conversation transcript to pre-fill an FIR form.
      The provided '{{{complaintTranscript}}}' contains a DIALOGUE between a 'User' (complainant/witness) and an 'AI Assistant'.
      Extract all details based ONLY on the 'User:' lines from this provided dialogue. Do not infer details not present in the user's statements.
      All extracted fields, except for 'complaintStatement', should be in English.

      **Critical Instructions for 'complaintStatement' (This field is MANDATORY and must not be empty if user input exists):**
      1.  Analyze the '{{{complaintTranscript}}}' (which contains both 'User:' and 'AI Assistant:' lines) carefully.
      2.  Focus EXCLUSIVELY on the lines starting with 'User:'.
      3.  Synthesize a concise, **first-person factual narrative summary** of the incident as described BY THE USER in their statements. This should be a coherent statement from the user's (complainant's/witness's) point of view, detailing what happened, when, where, and to whom/what, based *only* on their contributions to the dialogue.
      4.  This summary MUST be in the original language of the conversation, specified as '{{{language}}}'. If no specific user narrative is found, you must state that clearly in the specified language.
      5.  This is the user's version of events for the FIR (Section 10: Complaint / Statement of Complainant/Informant) or a witness statement. It should read like a story they are telling.
      6.  Do NOT include any 'AI Assistant:' lines (questions, prompts, or conversational fillers) in the final 'complaintStatement'.

      **Critical Instructions for 'translatedEnglishComplaintStatement' (This field is MANDATORY and must not be empty if user input exists):**
      1.  Translate the 'complaintStatement' you generated above (which is based only on user inputs) into English. This is for official records and should accurately reflect the user's narrative summary. If the original complaintStatement indicates no narrative was found, translate that statement.

      {{#if knowledgeBaseContext}}
      For suggesting 'actsAndSectionsInvolved', use this legal context. Ensure all sections are from new Indian laws (BNS, BNSS, BSA, Special Acts).
      <knowledge_base_context>
      {{{knowledgeBaseContext}}}
      </knowledge_base_context>
      {{/if}}

      Full Conversation Transcript to Analyze (Focus on 'User:' lines for narrative):
      \`\`\`
      {{{complaintTranscript}}}
      \`\`\`

      Extract the following details. If information is not available in the USER'S statements, leave the field null for optional fields. The 'complaintStatement' and 'translatedEnglishComplaintStatement' are REQUIRED.
      - title: (Concise case title in English, based on user's information)
      - complainantName
      - complainantGender
      - complainantAge
      - complainantFatherHusbandName
      - complainantAddress_streetVillage
      - complainantAddress_cityDistrict
      - complainantMobileNumber
      - occurrenceDateTimeFrom: (YYYY-MM-DDTHH:MM, from user's statements)
      - occurrenceDay
      - occurrencePlace_streetVillage
      - occurrencePlace_areaMandal
      - occurrencePlace_cityDistrict
      - complaintStatement: (First-person factual narrative summary of the user's account of the incident, based ONLY on 'User:' lines in '{{{complaintTranscript}}}', in '{{{language}}}'. THIS IS REQUIRED.)
      - translatedEnglishComplaintStatement: (English translation of the user's factual narrative summary from 'User:' lines. THIS IS REQUIRED.)
      - accusedName
      - accusedGender
      - accusedAge
      - accusedAddress_streetVillage
      - victimName
      - victimGender
      - victimAge
      - propertiesInvolvedDetails
      - propertiesTotalValueStolen
      - actsAndSectionsInvolved: (New Indian laws only, e.g., "BNS Section 101: Murder")
      - typeOfInformation: (Written, Oral, Unknown, inferred from user's interaction)

    Ensure your output strictly adheres to the JSON schema, providing non-empty strings for 'complaintStatement' and 'translatedEnglishComplaintStatement'.
  `,
});

const extractFirDetailsFlow = ai.defineFlow(
  {
    name: 'extractFirDetailsFlow',
    inputSchema: ExtractFirDetailsInputSchema,
    outputSchema: ExtractFirDetailsOutputSchema,
  },
  async (input: ExtractFirDetailsInput) => {
    const cleanedTranscript = input.complaintTranscript
      .split('\n')
      .map(line => line.trim()) 
      .filter(line => line !== '') 
      .map(line => {
        if (line.toLowerCase().startsWith('user:')) {
          return 'User:' + line.substring(5).trim();
        } else if (line.toLowerCase().startsWith('ai assistant:')) {
           return 'AI Assistant:' + line.substring(13).trim();
        }
        return line; 
      })
      .join('\n');

    if (!cleanedTranscript.trim()) {
      const defaultStatement = input.language?.startsWith('hi') ? 'उपयोगकर्ता से कोई संवाद उपलब्ध नहीं है जिससे सारांश बनाया जा सके।' : 'No user dialogue available to create a summary.';
      // Since complaintStatement is now required, we must provide a value that satisfies min(1).
      // This path is for when the *entire input transcript* is empty.
      return {
        complaintStatement: defaultStatement,
        translatedEnglishComplaintStatement: 'No user dialogue available to create a summary.',
        // Other fields will be undefined and handled by their optional nature or schema defaults.
      } as ExtractFirDetailsOutput; // Cast as ExtractFirDetailsOutput because other fields are missing
    }

    const {output} = await prompt({ ...input, complaintTranscript: cleanedTranscript });

    // Define a default error statement if the AI fails to produce output satisfying the schema.
    const defaultErrorStatement = "Error: AI could not process the transcript to generate a valid FIR structure.";
    const defaultNarrativeBase = "AI was unable to generate a narrative summary from the provided dialogue."
    const defaultNarrativeHindi = "एआई दिए गए संवाद से कथा सारांश उत्पन्न करने में असमर्थ था।"

    if (!output) {
      // This means the LLM call failed or the output did not match the Zod schema at all.
      return {
        complaintStatement: input.language?.startsWith('hi') ? defaultNarrativeHindi : defaultNarrativeBase,
        translatedEnglishComplaintStatement: defaultNarrativeBase,
      } as ExtractFirDetailsOutput;
    }
    
    // Ensure that even if the output object is returned, the required fields have some content.
    // This is a fallback, ideally the .min(1) in Zod schema + prompt handles this.
    return {
        ...output, // Spread other potentially extracted fields
        complaintStatement: output.complaintStatement?.trim() || (input.language?.startsWith('hi') ? defaultNarrativeHindi : defaultNarrativeBase),
        translatedEnglishComplaintStatement: output.translatedEnglishComplaintStatement?.trim() || defaultNarrativeBase,
    };
  }
);

