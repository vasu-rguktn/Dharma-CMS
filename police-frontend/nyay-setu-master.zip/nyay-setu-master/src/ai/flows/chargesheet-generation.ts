
// Chargesheet-generation flow
'use server';

/**
 * @fileOverview Generates a draft charge sheet for a case using multiple uploaded documents and additional instructions.
 *
 * - generateChargeSheet - A function that generates the charge sheet.
 * - GenerateChargeSheetInput - The input type for the generateChargeSheet function.
 * - GenerateChargeSheetOutput - The return type for the generateChargeSheet function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DocumentSchema = z.object({
  name: z.string().describe("The name of the uploaded file."),
  dataUri: z.string().describe("Document content as a Base64 encoded data URI. Expected format: 'data:<mimetype>;base64,<encoded_data>'."),
  contentType: z.string().describe("MIME type of the document (e.g., 'application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document').")
});

const GenerateChargeSheetInputSchema = z.object({
  documents: z
    .array(DocumentSchema)
    .min(1, { message: "At least one document must be provided."})
    .describe('An array of documents providing case details, FIRs, witness statements, evidence, investigation reports, etc.'),
  additionalInstructions: z
    .string()
    .optional()
    .describe('Any additional instructions or specific points to focus on for the chargesheet generation.'),
  knowledgeBaseContext: z.string().optional().describe("Relevant information retrieved from the knowledge base (e.g., legal templates, standard procedures, relevant case law snippets) to assist in drafting the charge sheet."),
});

export type GenerateChargeSheetInput = z.infer<typeof GenerateChargeSheetInputSchema>;

const GenerateChargeSheetOutputSchema = z.object({
  chargeSheet: z.string().describe('A draft of the charge sheet generated based on the provided documents and instructions, formatted for court submission.'),
});

export type GenerateChargeSheetOutput = z.infer<typeof GenerateChargeSheetOutputSchema>;

export async function generateChargeSheet(input: GenerateChargeSheetInput): Promise<GenerateChargeSheetOutput> {
  return generateChargeSheetFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateChargeSheetPrompt',
  input: {schema: GenerateChargeSheetInputSchema},
  output: {schema: GenerateChargeSheetOutputSchema},
  prompt: `You are a diligent and experienced police/prosecution assistant. Your task is to generate a complete, comprehensive **chargesheet** for submission to the magistrate, following the provided **format** and focusing on presenting a robust case against the accused(s) based on the information from the uploaded documents and any additional instructions.

The chargesheet must:
✅ **Align with the standard format** and include all mandatory sections such as details of the accused, complainant, witnesses, properties seized, final investigation findings, and relevant legal provisions.
✅ **Highlight the factual narrative** of the crime in a logical and structured manner.
✅ **Connect each piece of evidence to the corresponding accused** and explain how the evidence supports the charges.
✅ Clearly specify:
- Which legal provisions are invoked and why.
- How the investigation was conducted and what evidence was gathered.
- The roles of the complainant, witnesses, and investigating officer.
✅ **Avoid assumptions**—include only facts and evidence found within the provided documents.
✅ **Draft with clarity and professionalism** to present a persuasive case before the court.

{{#if knowledgeBaseContext}}
Before formulating your response, consult the following relevant information retrieved from our internal knowledge base. This information (e.g., charge sheet templates, legal standards, common phrasing) should be prioritized and used to ensure your response is accurate, comprehensive, and contextually appropriate:
<knowledge_base_context>
{{{knowledgeBaseContext}}}
</knowledge_base_context>
Always critically evaluate the knowledge base context against the primary request and other provided details. Do not solely rely on it if it seems to contradict clear facts from the main input.
{{/if}}

Here are the documents provided for this case. Synthesize all information from them:
{{#each documents}}
--- Document: {{name}} (Type: {{contentType}}) ---
{{#if (eq contentType "application/pdf")}}
[Content of PDF document: {{name}}. The content is embedded and should be processed.]
{{media url=dataUri contentType=contentType}}
{{else if (eq contentType "application/msword")}}
[Content of Word document (old format): {{name}}. The content is embedded and should be processed.]
{{media url=dataUri contentType=contentType}}
{{else if (eq contentType "application/vnd.openxmlformats-officedocument.wordprocessingml.document")}}
[Content of Word document (docx format): {{name}}. The content is embedded and should be processed.]
{{media url=dataUri contentType=contentType}}
{{else if (eq contentType "text/plain")}}
[Content of Text document: {{name}}]
{{media url=dataUri contentType=contentType}}
{{else}}
[Unsupported document type: {{name}} ({{contentType}}). Try to infer content if possible, or note that it cannot be directly processed.]
{{media url=dataUri contentType=contentType}}
{{/if}}
--- End of Document: {{name}} ---
{{/each}}

{{#if additionalInstructions}}
Additional Instructions from the user:
{{{additionalInstructions}}}
{{/if}}

Now, based on ALL the information from the documents and any additional instructions, generate the chargesheet strictly following this format. If information for a specific field is not found in the provided materials, write "Not available" or leave it blank as appropriate for that field in the format.

---
**A.P.P.M. Order No:** 480-1,480-2,481,482,487 & 609-5 (U/S 173 Cr.P.C)
**IN THE COURT OF HONOURABLE Principal Civil Judge(Jr Dv) Court**
1. District: [Extract from documents or state "Not available"]
2. Final Report / Charge Sheet No: [Extract from documents or state "Not available"]
3. FIR No: [Extract from documents or state "Not available"]
4. Date: [Date of chargesheet generation, or extract if specified in documents. Format: YYYY-MM-DD]
5. P.S: [Extract from documents or state "Not available"]
6. Acts & Sections: [Extract all relevant acts and sections from documents and summarize them. Be specific.]
7. Type of Final Report: [e.g., Charge Sheet, Final Report Referred, etc. Extract or infer from documents, or state "Charge Sheet"]
8. Name of I.O.: [Name of Investigating Officer. Extract from documents or state "Not available"]
9. Name of complainant/informant: [Extract from documents or state "Not available"]
10. Details of properties/articles/documents recovered/seized and relied upon: [List all items with descriptions. Extract from documents or state "Not available"]
11. Particulars of accused charge-sheeted:
   [For each accused, provide:
   - Name:
   - Father’s name:
   - Address:
   - Occupation:
   - Date of birth/Age:
   - Caste:
   - Previous convictions (if any):
   - Date of arrest:
   - Date of forwarding to court:
   - Specific Acts & Sections charged under for this accused:
   Extract all these details from the documents for each accused. If multiple accused, list them sequentially. If any detail is missing, state "Not available" for that specific detail.]
12. Particulars of accused not charge-sheeted (if any): [Extract from documents or state "Not applicable" or "Not available"]
13. Particulars of witnesses to be examined:
   [For each witness, provide:
   - Name:
   - Father’s name:
   - Address:
   - Type of evidence (e.g., eye-witness, circumstantial, medical, expert, police, etc.):
   Extract all these details from the documents for each witness. List them sequentially.]
14. Details of medical examination, chemical analysis reports, and laboratory analysis: [Summarize findings from any relevant reports found in the documents. Include report numbers and dates if available. Or state "Not available" or "Not applicable".]
15. Summary of Investigation:
   - **Detailed factual narrative of the crime**: [Synthesize from all documents a chronological and factual account of what happened.]
   - **How the investigation was conducted**: [Describe the steps taken by the IO as found in the documents.]
   - **What evidence was gathered**: [List and briefly describe all key pieces of evidence.]
   - **How the accused was identified and apprehended**: [Detail the process from the documents.]
   - **Linkage between each piece of evidence and each accused**: [Crucial: Explain how specific evidence points to the involvement of each accused person.]
   - **Analysis of witness statements and corroborating evidence**: [Summarize key witness testimonies and how they support the case or are corroborated.]
   - **Clear legal justification for each charge**: [Explain why the chosen acts and sections are applicable based on the evidence and facts.]
16. Conclusion:
   - **Summarize why the charges are substantiated**: [Provide a concise summary of the overall case against the accused.]
   - **How the evidence forms a chain of events proving the accused’s guilt**: [Explain the linkage if a clear chain exists.]
   - **Mention if any further investigation is pending**: [Extract from documents or state "Investigation complete" or "Further investigation is pending regarding..."]
17. Final recommendation and forwarding for prosecution: [State clearly: "It is therefore prayed that the accused [Name(s) of accused] may be tried for the aforementioned offenses." or similar formal statement.]

---
**CRITICAL INSTRUCTIONS FOR AI:**
- **Use clear, formal, and direct language** suitable for official court submission.
- **Be meticulous**: No missing sections from the format above. If data is unavailable, state "Not available".
- **Ensure consistency**: All details (like names, dates) must match throughout the document and be sourced from the provided materials.
- **Highlight how the investigation upholds the law and protects victims’ rights**.
- **Present the chargesheet as a strong, logical, evidence-backed case** to maximize the chance of conviction.

**Provide the final chargesheet as a structured, formatted text ready for submission to the Hon’ble Court.**
`,
});

const generateChargeSheetFlow = ai.defineFlow(
  {
    name: 'generateChargeSheetFlow',
    inputSchema: GenerateChargeSheetInputSchema,
    outputSchema: GenerateChargeSheetOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

    