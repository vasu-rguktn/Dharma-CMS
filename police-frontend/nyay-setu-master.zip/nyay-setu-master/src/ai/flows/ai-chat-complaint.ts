
'use server';

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import {
  greetingPrompt,
  complaintRecordingPrompt,
  witnessStatementPrompt,
  witnessPreparationPrompt,
  crimeSceneInvestigationPrompt,
  normalChatPrompt,
  AiChatInput,
  AiChatOutput,
  GreetingInput,
} from './prompts/ai-chat-complaint-prompts';

const AiChatComplaintInputSchema = z.object({
  userInput: z.string(),
  document: z.object({
    dataUri: z.string(),
    contentType: z.string(),
  }).optional(),
  chatHistory: z.string().optional(),
  language: z.string().optional().default('en'),
  mode: z.enum(['complaintRecording', 'witnessStatement', 'witnessPreparation', 'normalChat', 'crimeSceneInvestigation']),
  firNumber: z.string().optional(),
  isGreetingRequest: z.boolean().optional(),
  knowledgeBaseContext: z.string().optional(),
});
export type AiChatComplaintInput = z.infer<typeof AiChatComplaintInputSchema>;

const AiChatComplaintOutputSchema = z.object({
  response: z.string(),
});
export type AiChatComplaintOutput = z.infer<typeof AiChatComplaintOutputSchema>;

export async function aiChatComplaint(input: AiChatComplaintInput): Promise<AiChatComplaintOutput> {
  if (input.isGreetingRequest) {
    const greetingInput: GreetingInput = {
      language: input.language || 'en',
      mode: input.mode,
      firNumber: input.firNumber,
    };
    const { output } = await greetingPrompt(greetingInput);
    return output || { response: "Hello! How can I assist you?" };
  }

  const chatInput: AiChatInput = {
    userInput: input.userInput,
    chatHistory: input.chatHistory,
    language: input.language,
    firNumber: input.firNumber,
    document: input.document,
    knowledgeBaseContext: input.knowledgeBaseContext,
  };

  let prompt;
  switch (input.mode) {
    case 'complaintRecording':
      prompt = complaintRecordingPrompt;
      break;
    case 'witnessStatement':
      prompt = witnessStatementPrompt;
      break;
    case 'witnessPreparation':
      prompt = witnessPreparationPrompt;
      break;
    case 'crimeSceneInvestigation':
      prompt = crimeSceneInvestigationPrompt;
      break;
    case 'normalChat':
      prompt = normalChatPrompt;
      break;
    default:
      prompt = normalChatPrompt;
  }

  const { output } = await prompt(chatInput);
  return output || { response: "Sorry, I couldn't process that. Please try again." };
}
