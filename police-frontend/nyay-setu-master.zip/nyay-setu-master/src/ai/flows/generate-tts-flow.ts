
'use server';
/**
 * @fileOverview A Genkit flow for generating Text-to-Speech audio.
 * This flow is currently NOT USED as TTS functionality has been reverted to Web Speech API.
 * It remains as a placeholder in case Genkit TTS is revisited.
 * 
 * - generateSpokenAudio - Generates audio from text.
 * - GenerateSpokenAudioInput - Input type for the flow.
 * - GenerateSpokenAudioOutput - Output type for the flow.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateSpokenAudioInputSchema = z.object({
  text: z.string().describe('The text to be converted to speech.'),
  languageCode: z.string().optional().default('en-US').describe('The language code for the TTS engine (e.g., "te-IN", "en-US").'),
});
export type GenerateSpokenAudioInput = z.infer<typeof GenerateSpokenAudioInputSchema>;

const GenerateSpokenAudioOutputSchema = z.object({
  audioDataUri: z.string().optional().describe("The generated audio as a data URI. Expected format: 'data:audio/<mimetype>;base64,<encoded_data>'."),
  error: z.string().optional().describe('Error message if TTS generation failed.'),
});
export type GenerateSpokenAudioOutput = z.infer<typeof GenerateSpokenAudioOutputSchema>;

export async function generateSpokenAudio(input: GenerateSpokenAudioInput): Promise<GenerateSpokenAudioOutput> {
  // This flow is not actively used. Returning an error or a mock response.
  console.warn("generateSpokenAudio flow was called, but it's currently disabled. Falling back to Web Speech API in client.");
  return { error: "Genkit TTS flow is disabled. Use Web Speech API." };
  
  // Original logic (kept for reference if re-enabled):
  /*
  try {
    const {media, finishReason, usage} = await ai.generate({
      model: 'googleai/gemini-2.5-flash-preview-tts',
      prompt: input.text,
      config: {
        responseModalities: ['AUDIO'],
        // custom: { ttsLanguageCode: input.languageCode } // Hypothetical
      },
    });

    if (finishReason !== 'STOP' && finishReason !== 'MODEL') {
      console.error("TTS generation did not finish successfully:", finishReason, JSON.stringify(usage));
      return { error: `TTS generation failed or was blocked. Reason: ${finishReason}` };
    }
    
    if (!media || !media.url) {
      return { error: 'No audio data received from TTS model.' };
    }

    return { audioDataUri: media.url };

  } catch (error: any) {
    console.error('Error in generateSpokenAudioFlow:', error);
    return { error: `Failed to generate audio: ${error.message || 'Unknown error during TTS generation'}` };
  }
  */
}

// The flow definition can also be commented out or removed if not needed.
const generateSpokenAudioFlow = ai.defineFlow(
  {
    name: 'generateSpokenAudioFlow',
    inputSchema: GenerateSpokenAudioInputSchema,
    outputSchema: GenerateSpokenAudioOutputSchema,
  },
  async (input: GenerateSpokenAudioInput): Promise<GenerateSpokenAudioOutput> => {
    // Delegate to the exported function for consistency, even if it's just returning an error.
    return generateSpokenAudio(input);
  }
);
