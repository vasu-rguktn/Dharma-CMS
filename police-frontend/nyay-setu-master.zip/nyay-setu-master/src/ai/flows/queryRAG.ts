// flows/queryRAG.ts
import { defineFlow } from '@genkit-ai/flow';
import { vertexAI } from '@genkit-ai/vertexai';
import { google } from '@genkit-ai/core/providers';

export const queryRAG = defineFlow({
  name: 'queryRAG',
  inputSchema: {
    text: 'string',
  },
  outputSchema: {
    response: 'string',
  },
  handler: async ({ text }) => {
    const model = vertexAI.chatModel({
      model: 'chat-bison',
      rag: {
        sources: [{
          corpus: 'projects/your-project-id/locations/us-central1/corpora/your-corpus-id',
        }],
      },
    });

    const result = await model.generateContent(text);
    return { response: result.text };
  },
});
