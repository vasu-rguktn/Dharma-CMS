
'use server';
/**
 * @fileOverview An AI flow for analyzing media (images) like a crime scene investigator.
 *
 * - analyzeMedia - A function that handles the media analysis process.
 * - MediaAnalysisInput - The input type for the analyzeMedia function.
 * - MediaAnalysisOutput - The return type for the analyzeMedia function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MediaAnalysisInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "A photo of a scene, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  userContext: z
    .string()
    .optional()
    .describe('Optional context or specific questions provided by the user about the scene or what to look for.'),
});
export type MediaAnalysisInput = z.infer<typeof MediaAnalysisInputSchema>;

const IdentifiedElementSchema = z.object({
  name: z.string().describe("A concise name for the element (e.g., 'kitchen knife', 'sedan car', 'unidentified adult male', 'security camera', 'handwritten note')."),
  category: z.string().describe("Suggested categories: weapon, vehicle, person, document, furniture, electronic device, personal item, clothing, tool, container, structural feature, environmental detail, potential evidence, miscellaneous."),
  description: z.string().describe("Brief description including its apparent location, state (e.g., damaged, open, closed), and any notable characteristics observed in the image."),
  count: z.number().optional().describe("Approximate count if multiple similar items are present.")
});

const MediaAnalysisOutputSchema = z.object({
  identifiedElements: z
    .array(IdentifiedElementSchema)
    .describe('A list of significant objects, people (as a general class), animals, text, or other notable elements visible in the image.'),
  sceneNarrative: z
    .string()
    .describe("A detailed, narrative-style description of the entire scene, as if written by a detective for an initial investigative report. This should cover Scene Overview and Key Observations. Weave together the identified elements, describe their spatial relationships, textures, conditions, and the overall environment. Maintain an objective yet analytical tone. This text will be editable by the user."),
  caseFileSummary: z
    .string()
    .describe("An overall scene summary or 'case file note'. This should cover Logical Inferences, Points for Further Investigation, and a Summary of Key Takeaways. Highlight any particularly suspicious items, unusual placements, or potential connections between elements. Formulate preliminary hypotheses about what might have occurred, what aspects warrant further investigation, or any immediate safety concerns observed. This text will be editable by the user."),
});
export type MediaAnalysisOutput = z.infer<typeof MediaAnalysisOutputSchema>;

export async function analyzeMedia(input: MediaAnalysisInput): Promise<MediaAnalysisOutput> {
  return analyzeMediaFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeMediaPrompt',
  // Using a highly capable multimodal model. If 'gemini-2.5-pro-preview-06-05' becomes available, it can be specified here.
  model: 'googleai/gemini-1.5-pro-latest', 
  input: {schema: MediaAnalysisInputSchema},
  output: {schema: MediaAnalysisOutputSchema},
  prompt: `You are an advanced AI-powered investigative assistant, acting as a professional investigator, forensic expert, and detective combined. Your task is to meticulously analyze the provided image: {{media url=imageDataUri}}.
  {{#if userContext}}
  The user has provided the following specific context or questions to consider during your analysis:
  "{{{userContext}}}"
  Please address this context in your findings.
  {{/if}}

  Strictly adhere to what is visible in the image. Do not hallucinate or infer beyond visual evidence unless making a logical deduction explicitly stated as such.

  Your analysis must be structured and detailed, providing the following three components:

  1.  **Identified Elements**:
      Compile a comprehensive list of all significant objects, people (described as a general class like 'adult male', 'person in red jacket'), animals, discernible text (transcribe if legible), or other notable elements visible in the image.
      For each element, provide:
      *   *name*: A concise and descriptive name (e.g., 'bloodied kitchen knife', 'blue Toyota Camry - partial license plate ABC', 'unidentified adult male - appears injured', 'security camera model X', 'handwritten note - partially legible').
      *   *category*: Assign a category from the following list: weapon, vehicle, person, document, furniture, electronic device, personal item, clothing, tool, container, structural feature (e.g., door, window), environmental detail (e.g., puddle, tree), potential evidence (if distinct), miscellaneous.
      *   *description*: A brief but informative description. Include its apparent location within the scene (e.g., 'on the floor near the doorway', 'on the central coffee table', 'in the subject's right hand', 'mounted on the ceiling corner'), its state (e.g., damaged, open, closed, knocked over), and any other notable visual characteristics (e.g., color, material, specific markings).
      *   *count*: If multiple instances of a very similar item are clearly identifiable and grouped, provide an approximate count.

  2.  **Scene Narrative** (for the 'sceneNarrative' output field):
      Construct a detailed, narrative-style description of the entire scene. Write this as if you are preparing an initial investigative report for a case file.
      *   **Scene Overview**: Begin with an overview of the scene type (e.g., 'interior of a residential living room', 'exterior view of a commercial storefront at night', 'close-up of a cluttered office desk'), environment, lighting, weather, and other relevant conditions.
      *   **Key Observations**: Systematically describe the layout and key areas. Weave in the identified elements from your list, explaining their spatial relationships to each other and to the overall scene. Describe colors, textures, signs of disturbance, or anything that seems out of place.
      *   Based purely on the visual evidence, suggest possible interactions between elements or a plausible sequence of events that might have occurred. For example, "A chair is knocked over near the table, suggesting a struggle might have taken place." or "The open window with pry marks on the frame indicates a possible point of entry."
      *   Maintain a professional, neutral tone focusing on facts and observations. Clearly distinguish between direct observation and inferred possibilities.

  3.  **Case File Summary & Hypotheses** (for the 'caseFileSummary' output field):
      Provide an overall summary that synthesizes your observations into a concise 'case file note'.
      *   **Logical Inferences**: Short deductions or plausible interpretations based on observed evidence and standard crime scene investigation practices (e.g., possible sequence of events, entry/exit points, tampering signs, blood spatter patterns, weapons, personal items).
      *   **Points for Further Investigation**: Additional questions or checks suggested for a thorough follow-up.
      *   **Summary of Key Takeaways**: Concise bullet points summarizing important elements.
      *   Highlight the most critical or suspicious items/observations.
      *   Note any unusual placements of objects or conditions that deviate from normal expectations for such a scene.
      *   Identify potential connections or relationships between different elements you've observed.
      *   Mention any immediate safety concerns evident from the image (e.g., exposed wires, hazardous materials).

  Be meticulous, thorough, and objective. If the image quality is poor, or elements are ambiguous, acknowledge these limitations in your descriptions. Structure your entire response according to the 'MediaAnalysisOutputSchema'.
  `,
});

const analyzeMediaFlow = ai.defineFlow(
  {
    name: 'analyzeMediaFlow',
    inputSchema: MediaAnalysisInputSchema,
    outputSchema: MediaAnalysisOutputSchema,
  },
  async (input: MediaAnalysisInput) => {
    const {output} = await prompt(input);

    if (!output) {
      console.error('AI analysis did not return an output that matches the schema.');
      return {
        identifiedElements: [{ name: "Error", category: "System", description: "AI failed to produce a valid analysis." }],
        sceneNarrative: "An error occurred during media analysis. The AI could not generate a narrative.",
        caseFileSummary: "Analysis incomplete due to an internal error.",
      };
    }
    
    return output;
  }
);
    

    