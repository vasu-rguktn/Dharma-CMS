require('dotenv').config();
const OpenAI = require('openai');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function main() {
  if (!process.env.OPENAI_API_KEY || !process.env.OPENAI_ASSISTANT_ID) {
    console.error('Missing OPENAI_API_KEY or OPENAI_ASSISTANT_ID in .env');
    process.exit(1);
  }
  try {
    const thread = await openai.beta.threads.create();
    await openai.beta.threads.messages.create(thread.id, {
      role: 'user',
      content: 'what is the punishment for murder?'
    });
    const run = await openai.beta.threads.runs.create(thread.id, {
      assistant_id: process.env.OPENAI_ASSISTANT_ID
    });
    let status;
    do {
      await new Promise(r => setTimeout(r, 1000));
      status = await openai.beta.threads.runs.retrieve(thread.id, run.id);
      process.stdout.write('.');
    } while(['queued','in_progress','requires_action'].includes(status.status));
    console.log('\nRun status:', status.status);
    if(status.status==='completed'){
      const messages = await openai.beta.threads.messages.list(thread.id, { limit:1, order:'desc' });
      const reply = messages.data[0]?.content?.[0]?.text?.value || '[No text reply]';
      console.log('OpenAI Assistant reply:', reply);
    } else {
      console.error('Run failed:', status.status, status.last_error);
    }
  } catch (err) {
    console.error('Error:', err);
  }
}

main(); 