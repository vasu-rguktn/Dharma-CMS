# **App Name**: NyayaSahayak

## Core Features:

- AI Chat: AI-powered chat interface for recording complaints and witness statements, converting voice to text and storing transcripts. Supports multi modal, user or officer can add documents, which can be inferred with OCR capabilities etc. Also the AI shall consume police documents to keep itself grounded in a knowledge bank- admin user can update the documents of the knowledge base for all the users.
- FIR Autofill: Extract key fields from complaint transcripts using Google's Gemini API tool, pre-filling relevant FIR fields. Uses LLM tool.
- Legal Suggestion: Provide intelligent suggestions for applicable Bharatiya Nyaya Sanhita (BNS), Bharatiya Nagarik Suraksha Sanhita (BNSS), Bharatiya Sakshya Adhiniyam (BSA) sections and other special acts based on the details of the FIR and incident. Uses LLM reasoning tool.
- Access control: Implement role-based access control to restrict unauthorized information access and editing of secure documents.
- Case Status Indicator: Categorize each case via its FIR card using specific status indicators, enabling color-coded visuals to prioritize urgent cases at a glance.
- Bilingual Support: Support bilingual form fields throughout the application to assist non-English speakers when reporting.
- User Authentication: User authentication with Firebase using Email/ Google SSO
- Document Drafting: Once the witness statements are captured, police may have to generate different drafts for medical officers, forensic experts etc. a document drafting feature which has the context of the entire case data so far to make the drafting easier. Uses LLM tool
- Case Journal: Case journal to be made on what happened on what date, with a time line, IO's case diary
- Charge Sheet Generation: Once the investigation is complete, allow to generate a draft chargesheet for the case with all the content available for that case. Uses LLM tool.
- Chargesheet Vetting: User can upload existing chargesheet which will be vetted by AI and suggest improvements to improve the chances of conviction
- Witness Preparation: In AI chat another mode is required which is witness preparation - witnesses will be given a mock trial experience by AI assistant to prepare them for probable defence questions before hand improving the chances of conviction

## Style Guidelines:

- Primary color: Deep blue (#3F51B5) to convey trust and authority.
- Background color: Light gray (#F5F5F5), a desaturated version of the primary, for a clean interface.
- Accent color: Indigo (#5C6BC0), an analogous color, used to highlight key interactive elements.
- Body and headline font: 'PT Sans', a humanist sans-serif for its readability and modern feel.
- Use consistent and clear icons from Material UI to represent actions and data types.
- Implement a responsive sidebar for navigation with color-coded FIR status indicators.
- Subtle animations for form transitions and data loading to improve user experience.