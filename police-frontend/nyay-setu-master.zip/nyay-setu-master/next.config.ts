
import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
    ],
  },
  webpack: (config, { isServer }) => {
    if (!isServer) {
      // Prevent server-only modules from being bundled on the client
      config.resolve.fallback = {
        ...config.resolve.fallback,
        http2: false, 
        async_hooks: false,
      };
    }
    return config;
  },
};

export default nextConfig;
